import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Ban, E as ArrowDownToLine, S as BookOpen, T as Award, _ as Eraser, a as Snowflake, b as Brush, c as Save, d as Lock, f as Landmark, g as FastForward, h as FlaskConical, i as Sun, l as RotateCcw, m as History, o as ShoppingBag, p as House, r as Trash2, s as ShieldCheck, t as Utensils, u as Palette, v as Circle, w as Backpack, x as Boxes, y as Check } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-lY7LMCW_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatUnits(amount) {
	return new Intl.NumberFormat("en-US").format(amount);
}
function formatWhen(iso) {
	const d = new Date(iso);
	const now = /* @__PURE__ */ new Date();
	const sameDay = d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
	const time = d.toLocaleTimeString("en-US", {
		hour: "numeric",
		minute: "2-digit"
	});
	if (sameDay) return `Today · ${time}`;
	return d.toLocaleDateString("en-US", {
		month: "short",
		day: "numeric"
	}) + " · " + time;
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
function LedgerMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		className: cn("size-8", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "4",
				width: "26",
				height: "24",
				rx: "5",
				fill: "currentColor",
				className: "text-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "10",
				width: "16",
				height: "1.6",
				rx: "0.8",
				fill: "#f7f4ee"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "15",
				width: "12",
				height: "1.6",
				rx: "0.8",
				fill: "#f7f4ee",
				opacity: "0.75"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "20",
				width: "9",
				height: "1.6",
				rx: "0.8",
				fill: "#f7f4ee",
				opacity: "0.5"
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium select-none outline-none focus-visible:ring-2 focus-visible:ring-accent/35 disabled:pointer-events-none disabled:opacity-45 transition-[scale,background-color,color,opacity,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-foreground shadow-[var(--shadow-border)] hover:bg-accent/92",
			secondary: "bg-surface text-ink shadow-[var(--shadow-border)] hover:bg-surface-2",
			outline: "bg-transparent text-ink shadow-[var(--shadow-border)] hover:bg-surface",
			ghost: "bg-transparent text-ink hover:bg-surface-2",
			danger: "bg-danger text-danger-foreground hover:bg-danger/92",
			success: "bg-success text-success-foreground hover:bg-success/92",
			vault: "bg-vault text-vault-foreground hover:bg-vault/92"
		},
		size: {
			default: "h-11 rounded-md px-4 text-sm",
			sm: "h-9 rounded-sm px-3 text-sm",
			lg: "h-12 rounded-md px-5 text-sm",
			icon: "size-11 rounded-md",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card",
		className: cn("rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("font-display text-lg font-semibold leading-snug tracking-tight", className),
		...props
	});
}
function CardHint({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm text-muted", className),
		...props
	});
}
function Badge({ className, tone = "accent", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex min-h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-xs font-semibold tabular-nums leading-none", tone === "accent" && "bg-accent text-accent-foreground", tone === "danger" && "bg-danger text-danger-foreground", tone === "warn" && "bg-warn-soft text-warn", tone === "muted" && "bg-surface-2 text-muted", className),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("h-11 w-full rounded-md bg-surface-2 px-3.5 text-sm text-ink outline-none shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-accent/35 disabled:opacity-50", className),
		...props
	});
}
function FieldLabel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-1.5 block text-sm font-medium text-muted", className),
		...props
	});
}
function NativeSelect({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		"data-slot": "select",
		className: cn("h-11 w-full appearance-none rounded-md bg-surface-2 bg-[length:12px] bg-[right_14px_center] bg-no-repeat px-3.5 pr-10 text-sm text-ink outline-none shadow-[var(--shadow-border)] focus-visible:ring-2 focus-visible:ring-accent/35", className),
		style: { backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236e6a62' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'/></svg>")` },
		...props,
		children
	});
}
function Progress({ value, className, barClassName }) {
	const pct = Math.max(0, Math.min(100, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "progressbar",
		"aria-valuenow": Math.round(pct),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		className: cn("h-2 overflow-hidden rounded-full bg-surface-2", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full rounded-full bg-success transition-[width] duration-300 ease-out", barClassName),
			style: { width: `${pct}%` }
		})
	});
}
var MAP = {
	blocks: Boxes,
	backpack: Backpack,
	book: BookOpen,
	art: Palette,
	ball: Circle,
	science: FlaskConical
};
function ProductIcon({ name, className }) {
	const Icon = MAP[name];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className: cn("size-6", className),
		strokeWidth: 1.6
	});
}
var PRODUCTS = [
	{
		id: "blocks",
		name: "Building Blocks Set",
		price: 18,
		blurb: "120 pieces, wooden finish",
		icon: "blocks"
	},
	{
		id: "pack",
		name: "Kids Backpack",
		price: 22,
		blurb: "Everyday school bag",
		icon: "backpack"
	},
	{
		id: "books",
		name: "Story Book Pack",
		price: 12,
		blurb: "Three illustrated titles",
		icon: "book"
	},
	{
		id: "art",
		name: "Art Supply Kit",
		price: 15,
		blurb: "Pencils, paper, watercolors",
		icon: "art"
	},
	{
		id: "ball",
		name: "Sports Ball",
		price: 10,
		blurb: "Size 3, indoor/outdoor",
		icon: "ball"
	},
	{
		id: "science",
		name: "Science Kit",
		price: 25,
		blurb: "Safe experiments at home",
		icon: "science"
	}
];
var AWARD_REASONS = [
	"Completed homework",
	"Cleaned room",
	"Helped with dishes",
	"Read for 20 minutes",
	"Kindness at school"
];
var CHORES = [
	{
		id: "homework",
		name: "Finish homework",
		amount: 5
	},
	{
		id: "room",
		name: "Clean your room",
		amount: 8
	},
	{
		id: "dishes",
		name: "Help with dishes",
		amount: 4
	}
];
var DAY_MS = 864e5;
var VAULT_TARGET = 70;
var STORAGE_KEY = "kiddo-ledger-v2";
function nowIso() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function openingState() {
	const opened = Date.now() - 10 * DAY_MS;
	return {
		consent: false,
		frozen: false,
		childName: "Alex",
		childAge: 10,
		balance: 42,
		vault: 25,
		vaultTarget: VAULT_TARGET,
		vaultGoal: "College Fund",
		vaultOpenedAt: opened,
		demoDaysAdvanced: 0,
		matchRate: .5,
		pendingPurchases: [],
		pendingChores: [],
		completedChoreIds: [],
		history: [{
			id: uid("evt"),
			kind: "credit",
			amount: 42,
			note: "Opening spendable balance",
			at: nowIso()
		}, {
			id: uid("evt"),
			kind: "transfer",
			amount: 25,
			note: "Opening vault · College Fund",
			at: new Date(opened).toISOString()
		}],
		drawings: []
	};
}
function record(history, kind, amount, note) {
	return [{
		id: uid("evt"),
		kind,
		amount,
		note,
		at: nowIso()
	}, ...history].slice(0, 40);
}
var useLedger = create()(persist((set, get) => ({
	...openingState(),
	role: "parent",
	screen: "home",
	selectedProductId: null,
	hydrated: false,
	setHydrated: (v) => set({ hydrated: v }),
	setRole: (role) => {
		const { consent, frozen } = get();
		if (role === "child" && !consent) {
			set({
				role: "parent",
				screen: "home"
			});
			return;
		}
		set({
			role,
			screen: "home",
			selectedProductId: null
		});
		if (role === "child" && frozen) {}
	},
	setScreen: (screen) => set({ screen }),
	selectProduct: (id) => set({
		selectedProductId: id,
		screen: "confirm"
	}),
	verifyConsent: () => {
		if (get().consent) return "Consent is already verified";
		set((s) => ({
			consent: true,
			history: record(s.history, "event", 0, "Verifiable parental consent completed")
		}));
		return null;
	},
	toggleFreeze: () => {
		const next = !get().frozen;
		set((s) => ({
			frozen: next,
			history: record(s.history, "event", 0, next ? "Child access frozen" : "Child access restored")
		}));
		return next ? "Alex is frozen" : "Alex is unfrozen";
	},
	loadUnits: (amount) => {
		if (!get().consent) return "Verify parental consent first";
		const amt = Math.max(1, Math.floor(amount));
		set((s) => ({
			balance: s.balance + amt,
			history: record(s.history, "credit", amt, "Parent loaded Units (non-refundable)"),
			screen: "home"
		}));
		return null;
	},
	awardUnits: (amount, reason) => {
		if (!get().consent) return "Verify parental consent first";
		const amt = Math.max(1, Math.floor(amount));
		set((s) => ({
			balance: s.balance + amt,
			history: record(s.history, "credit", amt, `Awarded · ${reason}`),
			screen: "home"
		}));
		return null;
	},
	requestPurchase: (productId) => {
		const s = get();
		if (s.frozen) return "Access is frozen by your parent";
		const product = PRODUCTS.find((p) => p.id === productId);
		if (!product) return "Item not found";
		if (product.price > s.balance) return "Not enough Units";
		if (s.pendingPurchases.some((p) => p.productId === productId)) return "This request is already waiting";
		set({
			pendingPurchases: [{
				id: uid("buy"),
				productId: product.id,
				name: product.name,
				price: product.price,
				icon: product.icon
			}, ...s.pendingPurchases],
			screen: "home",
			selectedProductId: null
		});
		return null;
	},
	approvePurchase: (id) => {
		const s = get();
		const item = s.pendingPurchases.find((p) => p.id === id);
		if (!item) return "Request not found";
		if (item.price > s.balance) return "Insufficient Units";
		set({
			balance: s.balance - item.price,
			pendingPurchases: s.pendingPurchases.filter((p) => p.id !== id),
			history: record(s.history, "debit", item.price, `Marketplace · ${item.name}`)
		});
		return null;
	},
	denyPurchase: (id) => {
		const s = get();
		const item = s.pendingPurchases.find((p) => p.id === id);
		set({
			pendingPurchases: s.pendingPurchases.filter((p) => p.id !== id),
			history: record(s.history, "event", 0, item ? `Denied · ${item.name}` : "Purchase denied")
		});
		return null;
	},
	completeChore: (choreId) => {
		const s = get();
		if (s.frozen) return "Access is frozen by your parent";
		const chore = CHORES.find((c) => c.id === choreId);
		if (!chore) return "Goal not found";
		if (s.completedChoreIds.includes(choreId)) return "Already completed";
		if (s.pendingChores.some((c) => c.choreId === choreId)) return "Waiting on parent";
		set({ pendingChores: [{
			id: uid("chore"),
			choreId,
			name: chore.name,
			amount: chore.amount
		}, ...s.pendingChores] });
		return null;
	},
	approveChore: (id) => {
		const s = get();
		const item = s.pendingChores.find((c) => c.id === id);
		if (!item) return "Request not found";
		if (!s.consent) return "Verify parental consent first";
		set({
			balance: s.balance + item.amount,
			pendingChores: s.pendingChores.filter((c) => c.id !== id),
			completedChoreIds: [...s.completedChoreIds, item.choreId],
			history: record(s.history, "credit", item.amount, `Chore approved · ${item.name}`)
		});
		return null;
	},
	denyChore: (id) => {
		const s = get();
		const item = s.pendingChores.find((c) => c.id === id);
		set({
			pendingChores: s.pendingChores.filter((c) => c.id !== id),
			history: record(s.history, "event", 0, item ? `Chore not approved · ${item.name}` : "Chore denied")
		});
		return null;
	},
	lockUnits: (amount) => {
		const s = get();
		if (s.frozen) return "Access is frozen by your parent";
		const amt = Math.max(1, Math.floor(amount));
		if (amt > s.balance) return "Not enough Units";
		const match = Math.floor(amt * s.matchRate);
		set({
			balance: s.balance - amt,
			vault: s.vault + amt + match,
			history: record(s.history, "transfer", amt, match ? `Locked in Vault · parent matched ${match}` : "Locked in Vault"),
			screen: "home"
		});
		return null;
	},
	setMatchRate: (rate) => {
		set({ matchRate: rate });
		return "Matching preference saved";
	},
	advanceVaultDays: (days) => {
		set((s) => ({ demoDaysAdvanced: s.demoDaysAdvanced + days }));
		return `Advanced ${days} days`;
	},
	releaseVault: () => {
		const s = get();
		if (get().daysRemaining() > 0) return "Vault has not matured yet";
		if (s.vault <= 0) return "Vault is empty";
		const amt = s.vault;
		set({
			vault: 0,
			vaultOpenedAt: Date.now(),
			demoDaysAdvanced: 0,
			history: record(s.history, "cashout", amt, "Vault matured · cash payout marked for Alex")
		});
		return null;
	},
	saveDrawing: (dataUrl) => {
		set((s) => ({ drawings: [{
			id: uid("draw"),
			dataUrl,
			at: nowIso()
		}, ...s.drawings].slice(0, 8) }));
		return "Design saved";
	},
	clearDrawings: () => set({ drawings: [] }),
	resetDemo: () => {
		set({
			...openingState(),
			role: "parent",
			screen: "home",
			selectedProductId: null
		});
	},
	daysRemaining: () => {
		const s = get();
		const elapsed = Math.floor((Date.now() - s.vaultOpenedAt) / DAY_MS + s.demoDaysAdvanced);
		return Math.max(0, 28 - elapsed);
	},
	pendingCount: () => {
		const s = get();
		return s.pendingPurchases.length + s.pendingChores.length;
	}
}), {
	name: STORAGE_KEY,
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	skipHydration: true,
	partialize: (state) => ({
		consent: state.consent,
		frozen: state.frozen,
		childName: state.childName,
		childAge: state.childAge,
		balance: state.balance,
		vault: state.vault,
		vaultTarget: state.vaultTarget,
		vaultGoal: state.vaultGoal,
		vaultOpenedAt: state.vaultOpenedAt,
		demoDaysAdvanced: state.demoDaysAdvanced,
		matchRate: state.matchRate,
		pendingPurchases: state.pendingPurchases,
		pendingChores: state.pendingChores,
		completedChoreIds: state.completedChoreIds,
		history: state.history,
		drawings: state.drawings
	})
}));
function BackButton() {
	const setScreen = useLedger((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		className: "w-full",
		onClick: () => setScreen("home"),
		children: "Back"
	});
}
function ParentHome() {
	const childName = useLedger((s) => s.childName);
	const consent = useLedger((s) => s.consent);
	const frozen = useLedger((s) => s.frozen);
	const balance = useLedger((s) => s.balance);
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const pendingPurchases = useLedger((s) => s.pendingPurchases);
	const pendingChores = useLedger((s) => s.pendingChores);
	const pendingCount = useLedger((s) => s.pendingCount());
	const daysRemaining = useLedger((s) => s.daysRemaining());
	const setScreen = useLedger((s) => s.setScreen);
	const verifyConsent = useLedger((s) => s.verifyConsent);
	const toggleFreeze = useLedger((s) => s.toggleFreeze);
	const approvePurchase = useLedger((s) => s.approvePurchase);
	const denyPurchase = useLedger((s) => s.denyPurchase);
	const approveChore = useLedger((s) => s.approveChore);
	const denyChore = useLedger((s) => s.denyChore);
	const vaultPct = vault / vaultTarget * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "stagger-1 screen-enter",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-muted",
						children: "Parent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display text-3xl font-semibold tracking-tight",
						children: [childName, "'s ledger"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Units load in, never cash out — until a vault matures."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "stagger-2 screen-enter space-y-0 p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 rounded-lg px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 items-center justify-center rounded-md bg-accent-soft text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
									className: "size-5",
									strokeWidth: 1.8
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: "Parental consent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: consent ? "Verified" : "Required before loading Units"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: consent ? "secondary" : "default",
							size: "sm",
							disabled: consent,
							onClick: () => {
								const err = verifyConsent();
								if (err) toast.message(err);
								else toast.success("Consent verified");
							},
							children: consent ? "Verified" : "Verify"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-3 h-px bg-border" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 rounded-lg px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 items-center justify-center rounded-md bg-surface-2 text-ink",
								children: frozen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Snowflake, {
									className: "size-5",
									strokeWidth: 1.8
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
									className: "size-5",
									strokeWidth: 1.8
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: "Child access"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: frozen ? "Frozen — spend and chores paused" : "Active"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => toast.message(toggleFreeze()),
							children: frozen ? "Unfreeze" : "Freeze"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-3 screen-enter overflow-hidden rounded-xl bg-ink p-5 text-bg shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-bg/60",
						children: "Spendable balance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-5xl font-semibold tracking-tight tabular-nums",
						children: formatUnits(balance)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-bg/70",
						children: "Kiddo Units"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "stagger-4 screen-enter bg-vault p-5 text-vault-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
							children: "Savings vault"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl font-semibold tabular-nums",
							children: formatUnits(vault)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-vault-foreground/75",
							children: [
								vaultGoal,
								" ·",
								" ",
								daysRemaining === 0 ? "Matured" : `Matures in ${daysRemaining} days`
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {
						className: "size-5 opacity-70",
						strokeWidth: 1.6
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: vaultPct,
					className: "mt-4 bg-white/15",
					barClassName: "bg-vault-foreground"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Pending"
					}), pendingCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "danger",
						children: pendingCount
					}) : null]
				}), pendingCount === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-4 text-center text-sm text-muted",
					children: "No requests right now."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "divide-y divide-border",
					children: [pendingPurchases.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 py-3 first:pt-0 last:pb-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
									name: p.icon,
									className: "size-5"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-medium",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted",
									children: [p.price, " Units · Marketplace"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "success",
									size: "icon-sm",
									"aria-label": "Approve",
									onClick: () => {
										const err = approvePurchase(p.id);
										if (err) toast.error(err);
										else toast.success("Purchase approved");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon-sm",
									"aria-label": "Deny",
									onClick: () => {
										denyPurchase(p.id);
										toast.message("Purchase denied");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" })
								})]
							})
						]
					}, p.id)), pendingChores.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 py-3 first:pt-0 last:pb-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-accent-soft text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, {
									className: "size-5",
									strokeWidth: 1.7
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-medium",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted",
									children: [
										"+",
										c.amount,
										" Units · Goal"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "success",
									size: "icon-sm",
									"aria-label": "Award",
									onClick: () => {
										const err = approveChore(c.id);
										if (err) toast.error(err);
										else toast.success(`+${c.amount} Units awarded`);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon-sm",
									"aria-label": "Deny",
									onClick: () => {
										denyChore(c.id);
										toast.message("Goal not awarded");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" })
								})]
							})
						]
					}, c.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "h-12",
						disabled: !consent,
						onClick: () => setScreen("load"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "size-4" }), "Load Units"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "h-12",
						disabled: !consent,
						onClick: () => setScreen("award"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4" }), "Award"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("vault"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" }), "Vault"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("history"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" }), "History"]
					})
				]
			})
		]
	});
}
function ParentLoad() {
	const [amount, setAmount] = (0, import_react.useState)(20);
	const [ack, setAck] = (0, import_react.useState)(false);
	const loadUnits = useLedger((s) => s.loadUnits);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Add Units"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Units are for spending in the Kiddo Marketplace or locking in the vault."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-warn-soft p-4 text-sm text-warn",
				children: "Once loaded, Units are not refundable as cash. Cash is only available to the child when a vault reaches maturity."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "load-amount",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "load-amount",
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: [
							10,
							20,
							50
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: amount === n ? "default" : "outline",
							size: "sm",
							className: "flex-1",
							onClick: () => setAmount(n),
							children: n
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-start gap-3 rounded-md bg-surface-2 p-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: ack,
							onChange: (e) => setAck(e.target.checked),
							className: "mt-0.5 size-4 accent-accent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I understand these Units cannot be withdrawn as cash until a vault matures." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: !ack || amount < 1,
						onClick: () => {
							const err = loadUnits(amount);
							if (err) toast.error(err);
							else toast.success(`${amount} Units loaded — non-refundable`);
						},
						children: "Confirm and load"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
function ParentAward() {
	const [reason, setReason] = (0, import_react.useState)(AWARD_REASONS[0]);
	const [amount, setAmount] = (0, import_react.useState)(5);
	const awardUnits = useLedger((s) => s.awardUnits);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Award"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Reward a goal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Direct awards skip the child's request queue."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "award-reason",
						children: "Reason"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
						id: "award-reason",
						value: reason,
						onChange: (e) => setReason(e.target.value),
						children: AWARD_REASONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: r,
							children: r
						}, r))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "award-amount",
						children: "Units"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "award-amount",
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => {
							const err = awardUnits(amount, reason);
							if (err) toast.error(err);
							else toast.success(`+${amount} Units awarded`);
						},
						children: "Award Units"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
function ParentVault() {
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const matchRate = useLedger((s) => s.matchRate);
	const daysRemaining = useLedger((s) => s.daysRemaining());
	const setMatchRate = useLedger((s) => s.setMatchRate);
	const advanceVaultDays = useLedger((s) => s.advanceVaultDays);
	const releaseVault = useLedger((s) => s.releaseVault);
	const setScreen = useLedger((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Vault"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Long-term savings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Locked Units become cash only at maturity."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "bg-vault p-5 text-vault-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
						children: "Currently locked"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl font-semibold tabular-nums",
						children: formatUnits(vault)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-vault-foreground/75",
						children: ["Goal: ", vaultGoal]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: vault / vaultTarget * 100,
						className: "mt-4 bg-white/15",
						barClassName: "bg-vault-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-vault-foreground/80",
						children: daysRemaining === 0 ? "Ready to release as cash for Alex." : `${daysRemaining} days until cash can be released.`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Parent matching"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "Optionally match what Alex locks. Matched Units go straight into the vault." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
						value: String(matchRate),
						onChange: (e) => {
							const v = Number(e.target.value);
							toast.success(setMatchRate(v));
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "0",
								children: "No matching"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "0.5",
								children: "Match 50%"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "1",
								children: "Match 100%"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Demo clock"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "Fast-forward maturity so you can try a cash release without waiting 28 days." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "flex-1",
							onClick: () => toast.message(advanceVaultDays(7)),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastForward, { className: "size-4" }), "+7 days"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "vault",
							className: "flex-1",
							disabled: daysRemaining > 0 || vault <= 0,
							onClick: () => {
								const err = releaseVault();
								if (err) toast.error(err);
								else {
									toast.success("Cash payout marked for Alex");
									setScreen("home");
								}
							},
							children: "Release cash"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
function ParentHistory() {
	const history = useLedger((s) => s.history);
	const resetDemo = useLedger((s) => s.resetDemo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Ledger"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "History"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Every load, award, lock, and spend — kept on this device."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "ledger-ruled p-0",
				children: history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted",
					children: "No events yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: history.map((e) => {
					const signed = e.kind === "debit" || e.kind === "transfer" || e.kind === "cashout" ? "out" : e.kind === "event" ? "none" : "in";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 px-4 py-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: e.note
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: formatWhen(e.at)
							})]
						}), signed !== "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `shrink-0 font-mono text-sm tabular-nums ${signed === "in" ? "text-success" : "text-ink"}`,
							children: [signed === "in" ? "+" : "−", e.amount]
						}) : null]
					}, e.id);
				}) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => {
					resetDemo();
					toast.message("Demo reset");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset demo"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
var CHORE_ICON = {
	homework: BookOpen,
	room: House,
	dishes: Utensils
};
function BackHome() {
	const setScreen = useLedger((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		className: "w-full",
		onClick: () => setScreen("home"),
		children: "Back"
	});
}
function FrozenBanner() {
	if (!useLedger((s) => s.frozen)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 rounded-lg bg-warn-soft px-3 py-2.5 text-sm text-warn",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 shrink-0" }), "Your parent paused this ledger. You can look, not spend."]
	});
}
function ChildHome() {
	const childName = useLedger((s) => s.childName);
	const balance = useLedger((s) => s.balance);
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const frozen = useLedger((s) => s.frozen);
	const pendingChores = useLedger((s) => s.pendingChores);
	const completedChoreIds = useLedger((s) => s.completedChoreIds);
	const pendingPurchases = useLedger((s) => s.pendingPurchases);
	const setScreen = useLedger((s) => s.setScreen);
	const completeChore = useLedger((s) => s.completeChore);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium text-muted",
					children: ["Hi ", childName]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Your ledger"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Earn Units. Spend them here. Save the rest."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-xl bg-ink p-5 text-bg shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-bg/60",
						children: "Spendable"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-5xl font-semibold tracking-tight tabular-nums",
						children: formatUnits(balance)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-bg/70",
						children: "Kiddo Units"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "bg-vault p-5 text-vault-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
						children: "Savings vault"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-3xl font-semibold tabular-nums",
						children: formatUnits(vault)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-vault-foreground/75",
						children: [
							vaultGoal,
							" · ",
							Math.round(vault / vaultTarget * 100),
							"% of goal"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: vault / vaultTarget * 100,
						className: "mt-4 bg-white/15",
						barClassName: "bg-vault-foreground"
					})
				]
			}),
			pendingPurchases.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mb-2 text-base",
					children: "Waiting on parent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: pendingPurchases.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
								name: p.icon,
								className: "size-4 text-muted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono tabular-nums text-muted",
								children: p.price
							})
						]
					}, p.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "mb-1 text-base",
						children: "Today's goals"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: "Mark done — your parent awards the Units."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-border",
						children: CHORES.map((c) => {
							const Icon = CHORE_ICON[c.id];
							const pending = pendingChores.some((p) => p.choreId === c.id);
							const done = completedChoreIds.includes(c.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 py-3 first:pt-0 last:pb-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-ink",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5",
											strokeWidth: 1.7
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-medium",
											children: c.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted",
											children: [
												"Earn ",
												c.amount,
												" Units"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: done ? "secondary" : pending ? "outline" : "default",
										disabled: frozen || pending || done,
										onClick: () => {
											const err = completeChore(c.id);
											if (err) toast.error(err);
											else toast.success("Sent to your parent");
										},
										children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), "Done"] }) : pending ? "Waiting" : "Done"
									})
								]
							}, c.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "h-12",
						onClick: () => setScreen("market"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4" }), "Open marketplace"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("vault"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" }), "Savings vault"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("studio"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brush, { className: "size-4" }), "Creative studio"]
					})
				]
			})
		]
	});
}
function ChildMarket() {
	const selectProduct = useLedger((s) => s.selectProduct);
	const setScreen = useLedger((s) => s.setScreen);
	const balance = useLedger((s) => s.balance);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Marketplace"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Spend Units here"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"You have ",
						formatUnits(balance),
						" Units. Parent approval required."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3",
				children: PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => selectProduct(p.id),
					className: "overflow-hidden rounded-xl bg-surface p-0 text-left shadow-[var(--shadow-border)] transition-[scale,box-shadow] duration-150 ease-out active:scale-[0.96]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-24 items-center justify-center bg-surface-2 text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
							name: p.icon,
							className: "size-9"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium leading-snug",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 font-mono text-sm tabular-nums text-accent",
							children: [p.price, " Units"]
						})]
					})]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => setScreen("home"),
				children: "Back"
			})
		]
	});
}
function ChildConfirm() {
	const selectedProductId = useLedger((s) => s.selectedProductId);
	const requestPurchase = useLedger((s) => s.requestPurchase);
	const setScreen = useLedger((s) => s.setScreen);
	const product = PRODUCTS.find((p) => p.id === selectedProductId);
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "No item selected."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "w-full",
			onClick: () => setScreen("market"),
			children: "Browse marketplace"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Confirm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Ask your parent"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "They will approve or deny this request."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col items-center py-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-16 items-center justify-center rounded-lg bg-surface-2 text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
							name: product.icon,
							className: "size-8"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-xl font-semibold",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: product.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-display text-3xl font-semibold tabular-nums text-accent",
						children: [product.price, " Units"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				onClick: () => {
					const err = requestPurchase(product.id);
					if (err) toast.error(err);
					else toast.success("Request sent to your parent");
				},
				children: "Send request"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => setScreen("market"),
				children: "Back"
			})
		]
	});
}
function ChildVault() {
	const [amount, setAmount] = (0, import_react.useState)(5);
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const matchRate = useLedger((s) => s.matchRate);
	const daysRemaining = useLedger((s) => s.daysRemaining());
	const lockUnits = useLedger((s) => s.lockUnits);
	const frozen = useLedger((s) => s.frozen);
	const match = Math.floor(amount * matchRate);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Vault"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Lock for later"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "When it matures, this becomes cash for you."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "bg-vault p-5 text-vault-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
						children: vaultGoal
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl font-semibold tabular-nums",
						children: formatUnits(vault)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-vault-foreground/75",
						children: "Units locked"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: vault / vaultTarget * 100,
						className: "mt-4 bg-white/15",
						barClassName: "bg-vault-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-vault-foreground/80",
						children: daysRemaining === 0 ? "Matured — your parent can release cash." : `${daysRemaining} days until maturity.`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Lock more Units"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "lock-amount",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "lock-amount",
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value))
					}),
					matchRate > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Parent match: +",
							match,
							" Units added to the vault."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: frozen,
						onClick: () => {
							const err = lockUnits(amount);
							if (err) toast.error(err);
							else toast.success(`${amount} Units locked`);
						},
						children: "Lock in vault"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackHome, {})
		]
	});
}
var SWATCHES = [
	"#1c1a16",
	"#1f6b5c",
	"#b5453a",
	"#8a6420",
	"#faf7f1"
];
var SIZES = [
	3,
	6,
	12
];
function StudioScreen() {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const drawing = (0, import_react.useRef)(false);
	const [color, setColor] = (0, import_react.useState)(SWATCHES[0]);
	const [size, setSize] = (0, import_react.useState)(6);
	const saveDrawing = useLedger((s) => s.saveDrawing);
	const drawings = useLedger((s) => s.drawings);
	const setScreen = useLedger((s) => s.setScreen);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const fit = () => {
			const rect = wrap.getBoundingClientRect();
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			canvas.width = Math.floor(rect.width * dpr);
			canvas.height = Math.floor(220 * dpr);
			canvas.style.width = `${rect.width}px`;
			canvas.style.height = "220px";
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.fillStyle = "#ffffff";
			ctx.fillRect(0, 0, rect.width, 220);
			ctx.lineCap = "round";
			ctx.lineJoin = "round";
		};
		fit();
		window.addEventListener("resize", fit);
		return () => window.removeEventListener("resize", fit);
	}, []);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const ctx = canvas?.getContext("2d");
		if (!canvas || !ctx) return;
		const pos = (e) => {
			const r = canvas.getBoundingClientRect();
			const t = "touches" in e ? e.touches[0] : e;
			if (!t) return null;
			return {
				x: t.clientX - r.left,
				y: t.clientY - r.top
			};
		};
		const start = (e) => {
			if ("touches" in e) e.preventDefault();
			const p = pos(e);
			if (!p) return;
			drawing.current = true;
			ctx.beginPath();
			ctx.strokeStyle = color;
			ctx.lineWidth = size;
			ctx.moveTo(p.x, p.y);
		};
		const move = (e) => {
			if (!drawing.current) return;
			if ("touches" in e) e.preventDefault();
			const p = pos(e);
			if (!p) return;
			ctx.lineTo(p.x, p.y);
			ctx.stroke();
		};
		const end = () => {
			drawing.current = false;
		};
		canvas.addEventListener("mousedown", start);
		canvas.addEventListener("mousemove", move);
		window.addEventListener("mouseup", end);
		canvas.addEventListener("touchstart", start, { passive: false });
		canvas.addEventListener("touchmove", move, { passive: false });
		window.addEventListener("touchend", end);
		return () => {
			canvas.removeEventListener("mousedown", start);
			canvas.removeEventListener("mousemove", move);
			window.removeEventListener("mouseup", end);
			canvas.removeEventListener("touchstart", start);
			canvas.removeEventListener("touchmove", move);
			window.removeEventListener("touchend", end);
		};
	}, [color, size]);
	const clear = () => {
		const canvas = canvasRef.current;
		const ctx = canvas?.getContext("2d");
		if (!canvas || !ctx) return;
		const r = canvas.getBoundingClientRect();
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, r.width, 220);
	};
	const save = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		saveDrawing(canvas.toDataURL("image/png"));
		toast.success("Design saved to this device");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Studio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Draw something"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Sketches stay on this device. Nothing is shared."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: wrapRef,
						className: "overflow-hidden rounded-lg bg-paper shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: canvasRef,
							className: "block h-[220px] w-full touch-none",
							"aria-label": "Drawing canvas"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 px-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: SWATCHES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Color ${c}`,
								onClick: () => setColor(c),
								className: "size-8 rounded-full shadow-[var(--shadow-border)] transition-[scale] duration-150 ease-out active:scale-[0.96]",
								style: {
									background: c,
									outline: color === c ? "2px solid var(--color-ink)" : "2px solid transparent",
									outlineOffset: "2px"
								}
							}, c))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1.5",
							children: SIZES.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Brush ${n}`,
								onClick: () => setSize(n),
								className: `flex size-8 items-center justify-center rounded-sm ${size === n ? "bg-ink text-bg" : "bg-surface-2 text-ink"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block rounded-full bg-current",
									style: {
										width: n,
										height: n
									}
								})
							}, n))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "flex-1",
							onClick: clear,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, { className: "size-4" }), "Clear"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "flex-1",
							onClick: save,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Save"]
						})]
					})
				]
			}),
			drawings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Saved"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => useLedger.getState().clearDrawings(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "Clear all"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: drawings.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: d.dataUrl,
					alt: "Saved drawing",
					className: "aspect-square w-full rounded-md object-cover shadow-[var(--shadow-border)] outline outline-1 -outline-offset-1 outline-ink/10"
				}, d.id))
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => setScreen("home"),
				children: "Back"
			})
		]
	});
}
function RoleSwitch() {
	const role = useLedger((s) => s.role);
	const consent = useLedger((s) => s.consent);
	const setRole = useLedger((s) => s.setRole);
	const pick = (next) => {
		if (next === "child" && !consent) {
			toast.message("Verify parental consent before opening the child view");
			return;
		}
		setRole(next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "tablist",
		"aria-label": "Demo as",
		className: "grid grid-cols-2 rounded-md bg-surface-2 p-1 shadow-[var(--shadow-border)]",
		children: ["parent", "child"].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "tab",
			"aria-selected": role === r,
			onClick: () => pick(r),
			className: cn("h-9 rounded-sm text-sm font-medium capitalize transition-[background-color,color] duration-150 ease-out", role === r ? "bg-surface text-ink shadow-[var(--shadow-border)]" : "text-muted"),
			children: r
		}, r))
	});
}
function BottomNav() {
	const role = useLedger((s) => s.role);
	const screen = useLedger((s) => s.screen);
	const setScreen = useLedger((s) => s.setScreen);
	const pending = useLedger((s) => s.pendingCount());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "sticky bottom-0 z-20 -mx-5 mt-6 border-t border-border bg-surface/95 px-2 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-sm",
		"aria-label": "Primary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex",
			children: (role === "parent" ? [
				{
					id: "home",
					label: "Home",
					icon: House
				},
				{
					id: "history",
					label: "History",
					icon: History,
					badge: pending
				},
				{
					id: "vault",
					label: "Vault",
					icon: Landmark
				}
			] : [
				{
					id: "home",
					label: "Home",
					icon: House
				},
				{
					id: "market",
					label: "Market",
					icon: ShoppingBag
				},
				{
					id: "vault",
					label: "Vault",
					icon: Landmark
				}
			]).map((item) => {
				const active = screen === item.id;
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setScreen(item.id),
					className: cn("relative flex h-12 flex-1 flex-col items-center justify-center gap-0.5 text-xs font-medium transition-colors duration-150", active ? "text-accent" : "text-muted"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							strokeWidth: active ? 2 : 1.7
						}),
						item.label,
						"badge" in item && item.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "danger",
							className: "absolute top-0.5 right-[calc(50%-22px)] min-w-4 px-1",
							children: item.badge
						}) : null
					]
				}, item.id);
			})
		})
	});
}
function ScreenBody() {
	const role = useLedger((s) => s.role);
	const screen = useLedger((s) => s.screen);
	if (role === "parent") switch (screen) {
		case "load": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentLoad, {});
		case "award": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentAward, {});
		case "vault": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentVault, {});
		case "history": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentHistory, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentHome, {});
	}
	switch (screen) {
		case "market": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildMarket, {});
		case "confirm": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildConfirm, {});
		case "vault": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildVault, {});
		case "studio": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioScreen, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildHome, {});
	}
}
function AppShell() {
	(0, import_react.useEffect)(() => {
		const done = () => {
			useLedger.setState({
				role: "parent",
				screen: "home",
				selectedProductId: null,
				hydrated: true
			});
		};
		Promise.resolve(useLedger.persist.rehydrate()).then(done, done);
	}, []);
	const hydrated = useLedger((s) => s.hydrated);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "paper-grain min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-[430px] flex-col bg-bg px-5 pt-[max(1rem,env(safe-area-inset-top))] shadow-[var(--shadow-border)] md:min-h-[100dvh] md:border-x md:border-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-5 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-display text-base font-semibold leading-none tracking-tight",
							children: "Kiddo Ledger"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs text-muted",
							children: "Family Units"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-36",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleSwitch, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 pb-2",
					children: hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenBody, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						"aria-hidden": true,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-40 rounded-md bg-surface-2" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-32 rounded-xl bg-surface-2" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 rounded-xl bg-surface-2" })
						]
					})
				}),
				hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			position: "bottom-center",
			theme: "light",
			offset: 88,
			toastOptions: { className: "!bg-ink !text-bg !border-0 !shadow-[var(--shadow-border)] !rounded-lg !font-sans" }
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
