import { useEffect, useRef, useState } from "react";
import { Eraser, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLedger } from "@/store/ledger";

const SWATCHES = ["#1c1a16", "#1f6b5c", "#b5453a", "#8a6420", "#faf7f1"];
const SIZES = [3, 6, 12];

export function StudioScreen() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const drawing = useRef(false);
  const [color, setColor] = useState(SWATCHES[0]);
  const [size, setSize] = useState(6);
  const saveDrawing = useLedger((s) => s.saveDrawing);
  const drawings = useLedger((s) => s.drawings);
  const setScreen = useLedger((s) => s.setScreen);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const fit = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(rect.width * dpr);
      canvas.height = Math.floor(220 * dpr);
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = "220px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, rect.width, 220);
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    const pos = (e: MouseEvent | TouchEvent) => {
      const r = canvas.getBoundingClientRect();
      const t = "touches" in e ? e.touches[0] : e;
      if (!t) return null;
      return { x: t.clientX - r.left, y: t.clientY - r.top };
    };

    const start = (e: MouseEvent | TouchEvent) => {
      if ("touches" in e) e.preventDefault();
      const p = pos(e);
      if (!p) return;
      drawing.current = true;
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = size;
      ctx.moveTo(p.x, p.y);
    };
    const move = (e: MouseEvent | TouchEvent) => {
      if (!drawing.current) return;
      if ("touches" in e) e.preventDefault();
      const p = pos(e);
      if (!p) return;
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
    };
    const end = () => {
      drawing.current = false;
    };

    canvas.addEventListener("mousedown", start);
    canvas.addEventListener("mousemove", move);
    window.addEventListener("mouseup", end);
    canvas.addEventListener("touchstart", start, { passive: false });
    canvas.addEventListener("touchmove", move, { passive: false });
    window.addEventListener("touchend", end);
    return () => {
      canvas.removeEventListener("mousedown", start);
      canvas.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", end);
      canvas.removeEventListener("touchstart", start);
      canvas.removeEventListener("touchmove", move);
      window.removeEventListener("touchend", end);
    };
  }, [color, size]);

  const clear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const r = canvas.getBoundingClientRect();
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, r.width, 220);
  };

  const save = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    saveDrawing(canvas.toDataURL("image/png"));
    toast.success("Design saved to this device");
  };

  return (
    <div className="screen-enter space-y-4">
      <header>
        <p className="text-sm font-medium text-muted">Studio</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          Draw something
        </h1>
        <p className="mt-1 text-sm text-muted">
          Sketches stay on this device. Nothing is shared.
        </p>
      </header>

      <Card className="space-y-3 p-3">
        <div
          ref={wrapRef}
          className="overflow-hidden rounded-lg bg-paper shadow-[var(--shadow-border)]"
        >
          <canvas
            ref={canvasRef}
            className="block h-[220px] w-full touch-none"
            aria-label="Drawing canvas"
          />
        </div>
        <div className="flex items-center justify-between gap-3 px-1">
          <div className="flex gap-2">
            {SWATCHES.map((c) => (
              <button
                key={c}
                type="button"
                aria-label={`Color ${c}`}
                onClick={() => setColor(c)}
                className="size-8 rounded-full shadow-[var(--shadow-border)] transition-[scale] duration-150 ease-out active:scale-[0.96]"
                style={{
                  background: c,
                  outline:
                    color === c
                      ? "2px solid var(--color-ink)"
                      : "2px solid transparent",
                  outlineOffset: "2px",
                }}
              />
            ))}
          </div>
          <div className="flex gap-1.5">
            {SIZES.map((n) => (
              <button
                key={n}
                type="button"
                aria-label={`Brush ${n}`}
                onClick={() => setSize(n)}
                className={`flex size-8 items-center justify-center rounded-sm ${
                  size === n ? "bg-ink text-bg" : "bg-surface-2 text-ink"
                }`}
              >
                <span
                  className="block rounded-full bg-current"
                  style={{ width: n, height: n }}
                />
              </button>
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={clear}>
            <Eraser className="size-4" />
            Clear
          </Button>
          <Button className="flex-1" onClick={save}>
            <Save className="size-4" />
            Save
          </Button>
        </div>
      </Card>

      {drawings.length > 0 ? (
        <section>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Saved</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => useLedger.getState().clearDrawings()}
            >
              <Trash2 className="size-3.5" />
              Clear all
            </Button>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {drawings.map((d) => (
              <img
                key={d.id}
                src={d.dataUrl}
                alt="Saved drawing"
                className="aspect-square w-full rounded-md object-cover shadow-[var(--shadow-border)] outline outline-1 -outline-offset-1 outline-ink/10"
              />
            ))}
          </div>
        </section>
      ) : null}

      <Button variant="outline" className="w-full" onClick={() => setScreen("home")}>
        Back
      </Button>
    </div>
  );
}
