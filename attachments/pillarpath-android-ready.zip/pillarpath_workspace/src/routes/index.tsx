import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, CreditCard, Gift, ShieldCheck, ShoppingBag, Sparkles, Truck, Users, WalletCards, Megaphone } from "lucide-react";
import { SignInGate, SignedOut } from "@/lib/auth/gates";
import { PillarpathApp } from "@/components/pillarpath-app";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { LedgerMark } from "@/components/kiddo/mark";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <>
    <SignedOut><Landing /></SignedOut>
    <SignInGate fallback={null}><PillarpathApp /></SignInGate>
  </>;
}

function Landing() {
  return <main className="min-h-dvh bg-bg text-ink">
    <header className="border-b border-border bg-bg/85 px-5 py-4 backdrop-blur-xl"><div className="mx-auto flex max-w-6xl items-center justify-between"><div className="flex items-center gap-3"><LedgerMark /><div><p className="font-display text-xl font-semibold">Pillarpath</p><p className="text-[11px] text-muted">Family commerce</p></div></div><Link to="/login"><Button variant="outline">Sign in</Button></Link></div></header>
    <section className="px-5 py-14 sm:py-20"><div className="mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[1.15fr_.85fr]"><div><p className="text-sm font-bold uppercase tracking-[0.18em] text-accent">A family operating system</p><h1 className="mt-4 max-w-4xl font-display text-5xl font-semibold leading-[0.98] tracking-tight sm:text-7xl">Earn. Save. Shop. Grow.</h1><p className="mt-6 max-w-2xl text-lg leading-8 text-muted">Pillarpath brings parent controls, child financial learning, a curated store, secure checkout, marketing tools, and supplier fulfillment into one family-first product.</p><div className="mt-8 flex flex-wrap gap-3"><Link to="/login"><Button className="h-12 px-5">Create your family account <ArrowRight className="size-4" /></Button></Link><a href="#features"><Button variant="outline" className="h-12 px-5">Explore the product</Button></a></div><div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-muted"><span className="flex items-center gap-2"><ShieldCheck className="size-4 text-accent" /> Parent controlled</span><span className="flex items-center gap-2"><CreditCard className="size-4 text-accent" /> Secure payments</span><span className="flex items-center gap-2"><Truck className="size-4 text-accent" /> Dropship ready</span></div></div><Card className="overflow-hidden rounded-[2rem] p-0"><div className="border-b border-border bg-surface-2 p-6"><div className="flex items-center justify-between"><div><p className="text-xs font-semibold uppercase tracking-wider text-accent">Live workspace</p><h2 className="mt-1 font-display text-2xl font-semibold">One dashboard. Every path.</h2></div><Sparkles className="size-6 text-accent" /></div></div><div className="grid gap-3 p-5 sm:grid-cols-2">{[[Users,"Parent control","Approvals, family profiles, settings"],[WalletCards,"Child money","Earn, save, learn, ask to shop"],[ShoppingBag,"Marketplace","Curated products + baskets"],[CreditCard,"Checkout","Cards and digital wallets"],[Megaphone,"Marketing","Campaigns, promo, referrals"],[Truck,"Fulfillment","Supplier routing + tracking"]].map(([Icon,title,text]) => <div key={String(title)} className="rounded-2xl border border-border bg-bg p-4"><Icon className="size-5 text-accent" /><p className="mt-3 font-semibold">{String(title)}</p><p className="mt-1 text-xs leading-5 text-muted">{String(text)}</p></div>)}</div></Card></div></section>
    <section id="features" className="border-y border-border bg-surface/70 px-5 py-14"><div className="mx-auto max-w-6xl"><div className="max-w-2xl"><p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Built to scale</p><h2 className="mt-2 font-display text-4xl font-semibold">Commerce infrastructure without losing the family mission.</h2></div><div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4">{[[ShieldCheck,"Controls","Parent approvals, frozen access, profiles"],[Gift,"Savings","Vault goals and matching concepts"],[ShoppingBag,"Store","Curated catalog, basket, orders"],[Megaphone,"Growth","Campaigns, referrals, promotions"]].map(([Icon,title,text]) => <Card key={String(title)}><Icon className="size-6 text-accent" /><h3 className="mt-5 font-display text-xl font-semibold">{String(title)}</h3><p className="mt-2 text-sm text-muted">{String(text)}</p><div className="mt-4 flex items-center gap-2 text-xs text-accent"><CheckCircle2 className="size-3.5" /> Included</div></Card>)}</div></div></section>
    <footer className="px-5 py-10"><div className="mx-auto flex max-w-6xl flex-col gap-4 text-sm text-muted sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-2"><LedgerMark /><span>Pillarpath</span></div><span>Family finance + commerce platform</span></div></footer>
  </main>;
}
