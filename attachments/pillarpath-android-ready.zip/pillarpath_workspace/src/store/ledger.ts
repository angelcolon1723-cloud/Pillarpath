import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { CHORES, PRODUCTS, type Product } from "@/lib/products";
import { uid } from "@/lib/utils";

export type Role = "parent" | "child";

export type Screen =
  | "home"
  | "load"
  | "award"
  | "vault"
  | "history"
  | "market"
  | "confirm"
  | "studio"
  | "learn";

export type HistoryKind =
  | "credit"
  | "debit"
  | "transfer"
  | "event"
  | "cashout";

export type HistoryEvent = {
  id: string;
  kind: HistoryKind;
  amount: number;
  note: string;
  at: string;
};

export type PendingPurchase = {
  id: string;
  productId: string;
  name: string;
  price: number;
  icon: Product["icon"];
};

export type PendingChore = {
  id: string;
  choreId: string;
  name: string;
  amount: number;
};

export type SavedDrawing = {
  id: string;
  dataUrl: string;
  at: string;
};

export type MatchRate = 0 | 0.5 | 1;

const DAY_MS = 86_400_000;
const MATURITY_DAYS = 28;
const VAULT_TARGET = 70;
const STORAGE_KEY = "kiddo-ledger-v2";

function nowIso() {
  return new Date().toISOString();
}

function openingState() {
  const opened = Date.now() - 10 * DAY_MS;
  return {
    consent: false,
    frozen: false,
    childName: "Alex",
    childAge: 10,
    balance: 42,
    vault: 25,
    vaultTarget: VAULT_TARGET,
    vaultGoal: "College Fund",
    vaultOpenedAt: opened,
    demoDaysAdvanced: 0,
    matchRate: 0.5 as MatchRate,
    pendingPurchases: [] as PendingPurchase[],
    pendingChores: [] as PendingChore[],
    completedChoreIds: [] as string[],
    history: [
      {
        id: uid("evt"),
        kind: "credit" as const,
        amount: 42,
        note: "Opening spendable balance",
        at: nowIso(),
      },
      {
        id: uid("evt"),
        kind: "transfer" as const,
        amount: 25,
        note: "Opening vault · College Fund",
        at: new Date(opened).toISOString(),
      },
    ] as HistoryEvent[],
    drawings: [] as SavedDrawing[],
  };
}

type LedgerData = ReturnType<typeof openingState>;

type LedgerState = LedgerData & {
  role: Role;
  screen: Screen;
  selectedProductId: string | null;
  setRole: (role: Role) => void;
  setScreen: (screen: Screen) => void;
  selectProduct: (id: string) => void;
  verifyConsent: () => string | null;
  toggleFreeze: () => string;
  loadUnits: (amount: number) => string | null;
  awardUnits: (amount: number, reason: string) => string | null;
  requestPurchase: (productId: string) => string | null;
  approvePurchase: (id: string) => string | null;
  denyPurchase: (id: string) => string | null;
  completeChore: (choreId: string) => string | null;
  approveChore: (id: string) => string | null;
  denyChore: (id: string) => string | null;
  lockUnits: (amount: number) => string | null;
  setMatchRate: (rate: MatchRate) => string;
  advanceVaultDays: (days: number) => string;
  releaseVault: () => string | null;
  saveDrawing: (dataUrl: string) => string;
  clearDrawings: () => void;
  resetDemo: () => void;
  daysRemaining: () => number;
  pendingCount: () => number;
};

function record(
  history: HistoryEvent[],
  kind: HistoryKind,
  amount: number,
  note: string,
): HistoryEvent[] {
  return [
    { id: uid("evt"), kind, amount, note, at: nowIso() },
    ...history,
  ].slice(0, 40);
}

export const useLedger = create<LedgerState>()(
  persist(
    (set, get) => ({
      ...openingState(),
      role: "parent",
      screen: "home",
      selectedProductId: null,
      setRole: (role) => {
        const { consent, frozen } = get();
        if (role === "child" && !consent) {
          set({ role: "parent", screen: "home" });
          return;
        }
        set({
          role,
          screen: "home",
          selectedProductId: null,
        });
        if (role === "child" && frozen) {
          /* still allow viewing */
        }
      },
      setScreen: (screen) => set({ screen }),
      selectProduct: (id) =>
        set({ selectedProductId: id, screen: "confirm" }),
      verifyConsent: () => {
        if (get().consent) return "Consent is already verified";
        set((s) => ({
          consent: true,
          history: record(
            s.history,
            "event",
            0,
            "Verifiable parental consent completed",
          ),
        }));
        return null;
      },
      toggleFreeze: () => {
        const next = !get().frozen;
        set((s) => ({
          frozen: next,
          history: record(
            s.history,
            "event",
            0,
            next ? "Child access frozen" : "Child access restored",
          ),
        }));
        return next ? "Alex is frozen" : "Alex is unfrozen";
      },
      loadUnits: (amount) => {
        if (!get().consent) return "Verify parental consent first";
        const amt = Math.max(1, Math.floor(amount));
        set((s) => ({
          balance: s.balance + amt,
          history: record(
            s.history,
            "credit",
            amt,
            "Parent loaded Units (non-refundable)",
          ),
          screen: "home",
        }));
        return null;
      },
      awardUnits: (amount, reason) => {
        if (!get().consent) return "Verify parental consent first";
        const amt = Math.max(1, Math.floor(amount));
        set((s) => ({
          balance: s.balance + amt,
          history: record(s.history, "credit", amt, `Awarded · ${reason}`),
          screen: "home",
        }));
        return null;
      },
      requestPurchase: (productId) => {
        const s = get();
        if (s.frozen) return "Access is frozen by your parent";
        const product = PRODUCTS.find((p) => p.id === productId);
        if (!product) return "Item not found";
        const reserved = s.pendingPurchases.reduce((sum, p) => sum + p.price, 0);
        const available = s.balance - reserved;
        if (product.price > available) {
          return available > 0
            ? `Only ${available} Units are available after pending requests`
            : "Your available Units are already reserved";
        }
        if (s.pendingPurchases.some((p) => p.productId === productId)) {
          return "This request is already waiting";
        }
        set({
          pendingPurchases: [
            {
              id: uid("buy"),
              productId: product.id,
              name: product.name,
              price: product.price,
              icon: product.icon,
            },
            ...s.pendingPurchases,
          ],
          screen: "home",
          selectedProductId: null,
        });
        return null;
      },
      approvePurchase: (id) => {
        const s = get();
        const item = s.pendingPurchases.find((p) => p.id === id);
        if (!item) return "Request not found";
        if (item.price > s.balance) return "Insufficient Units";
        set({
          balance: s.balance - item.price,
          pendingPurchases: s.pendingPurchases.filter((p) => p.id !== id),
          history: record(
            s.history,
            "debit",
            item.price,
            `Marketplace · ${item.name}`,
          ),
        });
        return null;
      },
      denyPurchase: (id) => {
        const s = get();
        const item = s.pendingPurchases.find((p) => p.id === id);
        set({
          pendingPurchases: s.pendingPurchases.filter((p) => p.id !== id),
          history: record(
            s.history,
            "event",
            0,
            item ? `Denied · ${item.name}` : "Purchase denied",
          ),
        });
        return null;
      },
      completeChore: (choreId) => {
        const s = get();
        if (s.frozen) return "Access is frozen by your parent";
        const chore = CHORES.find((c) => c.id === choreId);
        if (!chore) return "Goal not found";
        if (s.completedChoreIds.includes(choreId)) return "Already completed";
        if (s.pendingChores.some((c) => c.choreId === choreId)) {
          return "Waiting on parent";
        }
        set({
          pendingChores: [
            {
              id: uid("chore"),
              choreId,
              name: chore.name,
              amount: chore.amount,
            },
            ...s.pendingChores,
          ],
        });
        return null;
      },
      approveChore: (id) => {
        const s = get();
        const item = s.pendingChores.find((c) => c.id === id);
        if (!item) return "Request not found";
        if (!s.consent) return "Verify parental consent first";
        set({
          balance: s.balance + item.amount,
          pendingChores: s.pendingChores.filter((c) => c.id !== id),
          completedChoreIds: [...s.completedChoreIds, item.choreId],
          history: record(
            s.history,
            "credit",
            item.amount,
            `Chore approved · ${item.name}`,
          ),
        });
        return null;
      },
      denyChore: (id) => {
        const s = get();
        const item = s.pendingChores.find((c) => c.id === id);
        set({
          pendingChores: s.pendingChores.filter((c) => c.id !== id),
          history: record(
            s.history,
            "event",
            0,
            item ? `Chore not approved · ${item.name}` : "Chore denied",
          ),
        });
        return null;
      },
      lockUnits: (amount) => {
        const s = get();
        if (s.frozen) return "Access is frozen by your parent";
        const amt = Math.max(1, Math.floor(amount));
        if (amt > s.balance) return "Not enough Units";
        const match = Math.floor(amt * s.matchRate);
        set({
          balance: s.balance - amt,
          vault: s.vault + amt + match,
          history: record(
            s.history,
            "transfer",
            amt,
            match
              ? `Locked in Vault · parent matched ${match}`
              : "Locked in Vault",
          ),
          screen: "home",
        });
        return null;
      },
      setMatchRate: (rate) => {
        set({ matchRate: rate });
        return "Matching preference saved";
      },
      advanceVaultDays: (days) => {
        set((s) => ({ demoDaysAdvanced: s.demoDaysAdvanced + days }));
        return `Advanced ${days} days`;
      },
      releaseVault: () => {
        const s = get();
        if (get().daysRemaining() > 0) return "Vault has not matured yet";
        if (s.vault <= 0) return "Vault is empty";
        const amt = s.vault;
        set({
          vault: 0,
          vaultOpenedAt: Date.now(),
          demoDaysAdvanced: 0,
          history: record(
            s.history,
            "cashout",
            amt,
            "Vault matured · cash payout marked for Alex",
          ),
        });
        return null;
      },
      saveDrawing: (dataUrl) => {
        set((s) => ({
          drawings: [
            { id: uid("draw"), dataUrl, at: nowIso() },
            ...s.drawings,
          ].slice(0, 8),
        }));
        return "Design saved";
      },
      clearDrawings: () => set({ drawings: [] }),
      resetDemo: () => {
        const next = openingState();
        set({
          ...next,
          role: "parent",
          screen: "home",
          selectedProductId: null,
        });
      },
      daysRemaining: () => {
        const s = get();
        const elapsed = Math.floor(
          (Date.now() - s.vaultOpenedAt) / DAY_MS + s.demoDaysAdvanced,
        );
        return Math.max(0, MATURITY_DAYS - elapsed);
      },
      pendingCount: () => {
        const s = get();
        return s.pendingPurchases.length + s.pendingChores.length;
      },
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      skipHydration: true,
      partialize: (state) => ({
        consent: state.consent,
        frozen: state.frozen,
        childName: state.childName,
        childAge: state.childAge,
        balance: state.balance,
        vault: state.vault,
        vaultTarget: state.vaultTarget,
        vaultGoal: state.vaultGoal,
        vaultOpenedAt: state.vaultOpenedAt,
        demoDaysAdvanced: state.demoDaysAdvanced,
        matchRate: state.matchRate,
        pendingPurchases: state.pendingPurchases,
        pendingChores: state.pendingChores,
        completedChoreIds: state.completedChoreIds,
        history: state.history,
        drawings: state.drawings,
      }),
    },
  ),
);

export { MATURITY_DAYS };
