//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DW5eCmrS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/checkout/success",
			"/api/auth/$",
			"/api/webhooks/dropship",
			"/api/webhooks/stripe"
		],
		preloads: [
			"/assets/index-ohKZ3wxA.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/createClientRpc-D-r1MrQe.js",
			"/assets/preload-helper-HvQ5iTcB.js",
			"/assets/createLucideIcon-DtEA2Qgx.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ohKZ3wxA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DKzHNRdp.js",
			"/assets/mark-CvJq63W_.js",
			"/assets/button-O8U1jXLE.js",
			"/assets/package-check-BJp4XPr_.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-C2ajzzd3.js",
			"/assets/mark-CvJq63W_.js",
			"/assets/button-O8U1jXLE.js",
			"/assets/client-C85fcJ4s.js"
		]
	},
	"/checkout/success": {
		filePath: "/workspace/src/routes/checkout/success.tsx",
		children: void 0,
		preloads: [
			"/assets/success-CQgvTqUQ.js",
			"/assets/button-O8U1jXLE.js",
			"/assets/package-check-BJp4XPr_.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
