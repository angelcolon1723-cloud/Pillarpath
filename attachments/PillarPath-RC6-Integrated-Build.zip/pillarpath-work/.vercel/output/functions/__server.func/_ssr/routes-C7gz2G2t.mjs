import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { a as uid, i as formatWhen, n as cn, r as formatUnits, t as Button } from "./button-DqTpIDAm.mjs";
import { a as SignedIn, c as useCurrentUser, i as NativeSelect, l as useCurrentUserState, n as Input, o as SignedOut, r as LedgerMark, s as UserButton, t as FieldLabel } from "./mark-B5Yg-r41.mjs";
import { $ as Backpack, A as Landmark, B as CreditCard, C as PlugZap, D as Lock, E as Megaphone, F as Gamepad2, G as ChevronRight, H as CircleHelp, I as FlaskConical, J as Brush, K as Check, L as FastForward, M as History, N as Handshake, O as LockKeyhole, P as Gift, Q as Ban, R as Eraser, S as Plus, T as PackageCheck, U as CircleDollarSign, V as Circle, W as CircleCheck, X as Boxes, Y as Brain, Z as BookOpen, _ as ShieldCheck, a as Truck, b as RotateCcw, c as Trash2, d as Store, et as Award, f as Star, g as Shirt, h as ShoppingBag, i as Users, j as House, k as LayoutDashboard, l as Target, m as Snowflake, n as WalletCards, nt as ArrowDownToLine, p as Sparkles, q as ChartColumn, r as Utensils, s as TrendingUp, t as X, tt as ArrowRight, u as Sun, v as Settings, w as Palette, x as Printer, y as Save, z as Ellipsis } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as authMiddleware } from "./middleware-B7qn5WXd.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C7gz2G2t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getPillarPathData = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("bfdd6fbb8f8a742699932b57f4217e67c3549a76556158bd443bd338793d36e6"));
var saveProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("ff330610e1e6d7fd67f7d8bee81db913cc2397aeb3a4837703240076f8d17013"));
var createChild = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("bd754c365a6d11db07cd84eab7cb3729665190d9696fde13b7d44a77e6ff5aff"));
var addToCart = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("08603fb9ba5f7898ffd7ba8ea782168778f21397bc6a52e4e3604343ff66d9ae"));
var setCartQuantity = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("5452d353fdc52aaa533022f2491bcf05dfd0406e741264c2b6d0d977d2f7bf74"));
var createCheckout = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("bb6640d77be45bc9648bc20006430c63a99ce2779b63d308a63f9243e2231c95"));
var createCampaign = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("186c619e06bcc3ea0084cf52bde4f48c88356030f85c17462a1dc966387144be"));
var createPromoCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("6423f6dbc97b2dc06a62a50cbecc9ec1848190987bed699555eea129beb1287f"));
var createStudioCheckout = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("073a86d8786e4bcf126ee6ec7fee20d7f41efe3c58eb522532bfe41ff5c60a5d"));
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card",
		className: cn("rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("font-display text-lg font-semibold leading-snug tracking-tight", className),
		...props
	});
}
function CardHint({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm text-muted", className),
		...props
	});
}
function Badge({ className, tone = "accent", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex min-h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-xs font-semibold tabular-nums leading-none", tone === "accent" && "bg-accent text-accent-foreground", tone === "danger" && "bg-danger text-danger-foreground", tone === "warn" && "bg-warn-soft text-warn", tone === "muted" && "bg-surface-2 text-muted", className),
		...props
	});
}
function Progress({ value, className, barClassName }) {
	const pct = Math.max(0, Math.min(100, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "progressbar",
		"aria-valuenow": Math.round(pct),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		className: cn("h-2 overflow-hidden rounded-full bg-surface-2", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full rounded-full bg-success transition-[width] duration-300 ease-out", barClassName),
			style: { width: `${pct}%` }
		})
	});
}
var MAP = {
	blocks: Boxes,
	backpack: Backpack,
	book: BookOpen,
	art: Palette,
	ball: Circle,
	science: FlaskConical
};
function ProductIcon({ name, className }) {
	const Icon = MAP[name];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className: cn("size-6", className),
		strokeWidth: 1.6
	});
}
var PRODUCTS = [
	{
		id: "blocks",
		name: "Building Blocks Set",
		price: 18,
		blurb: "120 pieces, wooden finish",
		icon: "blocks"
	},
	{
		id: "pack",
		name: "Kids Backpack",
		price: 22,
		blurb: "Everyday school bag",
		icon: "backpack"
	},
	{
		id: "books",
		name: "Story Book Pack",
		price: 12,
		blurb: "Three illustrated titles",
		icon: "book"
	},
	{
		id: "art",
		name: "Art Supply Kit",
		price: 15,
		blurb: "Pencils, paper, watercolors",
		icon: "art"
	},
	{
		id: "ball",
		name: "Sports Ball",
		price: 10,
		blurb: "Size 3, indoor/outdoor",
		icon: "ball"
	},
	{
		id: "science",
		name: "Science Kit",
		price: 25,
		blurb: "Safe experiments at home",
		icon: "science"
	}
];
var AWARD_REASONS = [
	"Completed homework",
	"Cleaned room",
	"Helped with dishes",
	"Read for 20 minutes",
	"Kindness at school"
];
var CHORES = [
	{
		id: "homework",
		name: "Finish homework",
		amount: 5
	},
	{
		id: "room",
		name: "Clean your room",
		amount: 8
	},
	{
		id: "dishes",
		name: "Help with dishes",
		amount: 4
	}
];
var DAY_MS = 864e5;
var VAULT_TARGET = 70;
var STORAGE_KEY = "kiddo-ledger-v2";
function nowIso() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function openingState() {
	const opened = Date.now() - 10 * DAY_MS;
	return {
		consent: false,
		frozen: false,
		childName: "Alex",
		childAge: 10,
		balance: 42,
		vault: 25,
		vaultTarget: VAULT_TARGET,
		vaultGoal: "College Fund",
		vaultOpenedAt: opened,
		demoDaysAdvanced: 0,
		matchRate: .5,
		pendingPurchases: [],
		pendingChores: [],
		completedChoreIds: [],
		history: [{
			id: uid("evt"),
			kind: "credit",
			amount: 42,
			note: "Opening spendable balance",
			at: nowIso()
		}, {
			id: uid("evt"),
			kind: "transfer",
			amount: 25,
			note: "Opening vault · College Fund",
			at: new Date(opened).toISOString()
		}],
		drawings: []
	};
}
function record(history, kind, amount, note) {
	return [{
		id: uid("evt"),
		kind,
		amount,
		note,
		at: nowIso()
	}, ...history].slice(0, 40);
}
var useLedger = create()(persist((set, get) => ({
	...openingState(),
	role: "parent",
	screen: "home",
	selectedProductId: null,
	setRole: (role) => {
		const { consent, frozen } = get();
		if (role === "child" && !consent) {
			set({
				role: "parent",
				screen: "home"
			});
			return;
		}
		set({
			role,
			screen: "home",
			selectedProductId: null
		});
		if (role === "child" && frozen) {}
	},
	setScreen: (screen) => set({ screen }),
	selectProduct: (id) => set({
		selectedProductId: id,
		screen: "confirm"
	}),
	verifyConsent: () => {
		if (get().consent) return "Consent is already verified";
		set((s) => ({
			consent: true,
			history: record(s.history, "event", 0, "Verifiable parental consent completed")
		}));
		return null;
	},
	toggleFreeze: () => {
		const next = !get().frozen;
		set((s) => ({
			frozen: next,
			history: record(s.history, "event", 0, next ? "Child access frozen" : "Child access restored")
		}));
		return next ? "Alex is frozen" : "Alex is unfrozen";
	},
	loadUnits: (amount) => {
		if (!get().consent) return "Verify parental consent first";
		const amt = Math.max(1, Math.floor(amount));
		set((s) => ({
			balance: s.balance + amt,
			history: record(s.history, "credit", amt, "Parent loaded Units (non-refundable)"),
			screen: "home"
		}));
		return null;
	},
	awardUnits: (amount, reason) => {
		if (!get().consent) return "Verify parental consent first";
		const amt = Math.max(1, Math.floor(amount));
		set((s) => ({
			balance: s.balance + amt,
			history: record(s.history, "credit", amt, `Awarded · ${reason}`),
			screen: "home"
		}));
		return null;
	},
	requestPurchase: (productId) => {
		const s = get();
		if (s.frozen) return "Access is frozen by your parent";
		const product = PRODUCTS.find((p) => p.id === productId);
		if (!product) return "Item not found";
		const reserved = s.pendingPurchases.reduce((sum, p) => sum + p.price, 0);
		const available = s.balance - reserved;
		if (product.price > available) return available > 0 ? `Only ${available} Units are available after pending requests` : "Your available Units are already reserved";
		if (s.pendingPurchases.some((p) => p.productId === productId)) return "This request is already waiting";
		set({
			pendingPurchases: [{
				id: uid("buy"),
				productId: product.id,
				name: product.name,
				price: product.price,
				icon: product.icon
			}, ...s.pendingPurchases],
			screen: "home",
			selectedProductId: null
		});
		return null;
	},
	approvePurchase: (id) => {
		const s = get();
		const item = s.pendingPurchases.find((p) => p.id === id);
		if (!item) return "Request not found";
		if (item.price > s.balance) return "Insufficient Units";
		set({
			balance: s.balance - item.price,
			pendingPurchases: s.pendingPurchases.filter((p) => p.id !== id),
			history: record(s.history, "debit", item.price, `Marketplace · ${item.name}`)
		});
		return null;
	},
	denyPurchase: (id) => {
		const s = get();
		const item = s.pendingPurchases.find((p) => p.id === id);
		set({
			pendingPurchases: s.pendingPurchases.filter((p) => p.id !== id),
			history: record(s.history, "event", 0, item ? `Denied · ${item.name}` : "Purchase denied")
		});
		return null;
	},
	completeChore: (choreId) => {
		const s = get();
		if (s.frozen) return "Access is frozen by your parent";
		const chore = CHORES.find((c) => c.id === choreId);
		if (!chore) return "Goal not found";
		if (s.completedChoreIds.includes(choreId)) return "Already completed";
		if (s.pendingChores.some((c) => c.choreId === choreId)) return "Waiting on parent";
		set({ pendingChores: [{
			id: uid("chore"),
			choreId,
			name: chore.name,
			amount: chore.amount
		}, ...s.pendingChores] });
		return null;
	},
	approveChore: (id) => {
		const s = get();
		const item = s.pendingChores.find((c) => c.id === id);
		if (!item) return "Request not found";
		if (!s.consent) return "Verify parental consent first";
		set({
			balance: s.balance + item.amount,
			pendingChores: s.pendingChores.filter((c) => c.id !== id),
			completedChoreIds: [...s.completedChoreIds, item.choreId],
			history: record(s.history, "credit", item.amount, `Chore approved · ${item.name}`)
		});
		return null;
	},
	denyChore: (id) => {
		const s = get();
		const item = s.pendingChores.find((c) => c.id === id);
		set({
			pendingChores: s.pendingChores.filter((c) => c.id !== id),
			history: record(s.history, "event", 0, item ? `Chore not approved · ${item.name}` : "Chore denied")
		});
		return null;
	},
	lockUnits: (amount) => {
		const s = get();
		if (s.frozen) return "Access is frozen by your parent";
		const amt = Math.max(1, Math.floor(amount));
		if (amt > s.balance) return "Not enough Units";
		const match = Math.floor(amt * s.matchRate);
		set({
			balance: s.balance - amt,
			vault: s.vault + amt + match,
			history: record(s.history, "transfer", amt, match ? `Locked in Vault · parent matched ${match}` : "Locked in Vault"),
			screen: "home"
		});
		return null;
	},
	setMatchRate: (rate) => {
		set({ matchRate: rate });
		return "Matching preference saved";
	},
	advanceVaultDays: (days) => {
		set((s) => ({ demoDaysAdvanced: s.demoDaysAdvanced + days }));
		return `Advanced ${days} days`;
	},
	releaseVault: () => {
		const s = get();
		if (get().daysRemaining() > 0) return "Vault has not matured yet";
		if (s.vault <= 0) return "Vault is empty";
		const amt = s.vault;
		set({
			vault: 0,
			vaultOpenedAt: Date.now(),
			demoDaysAdvanced: 0,
			history: record(s.history, "cashout", amt, "Vault matured · cash payout marked for Alex")
		});
		return null;
	},
	saveDrawing: (dataUrl) => {
		set((s) => ({ drawings: [{
			id: uid("draw"),
			dataUrl,
			at: nowIso()
		}, ...s.drawings].slice(0, 8) }));
		return "Design saved";
	},
	clearDrawings: () => set({ drawings: [] }),
	resetDemo: () => {
		set({
			...openingState(),
			role: "parent",
			screen: "home",
			selectedProductId: null
		});
	},
	daysRemaining: () => {
		const s = get();
		const elapsed = Math.floor((Date.now() - s.vaultOpenedAt) / DAY_MS + s.demoDaysAdvanced);
		return Math.max(0, 28 - elapsed);
	},
	pendingCount: () => {
		const s = get();
		return s.pendingPurchases.length + s.pendingChores.length;
	}
}), {
	name: STORAGE_KEY,
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	skipHydration: true,
	partialize: (state) => ({
		consent: state.consent,
		frozen: state.frozen,
		childName: state.childName,
		childAge: state.childAge,
		balance: state.balance,
		vault: state.vault,
		vaultTarget: state.vaultTarget,
		vaultGoal: state.vaultGoal,
		vaultOpenedAt: state.vaultOpenedAt,
		demoDaysAdvanced: state.demoDaysAdvanced,
		matchRate: state.matchRate,
		pendingPurchases: state.pendingPurchases,
		pendingChores: state.pendingChores,
		completedChoreIds: state.completedChoreIds,
		history: state.history,
		drawings: state.drawings
	})
}));
function BackButton() {
	const setScreen = useLedger((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		className: "w-full",
		onClick: () => setScreen("home"),
		children: "Back"
	});
}
function ParentHome() {
	const childName = useLedger((s) => s.childName);
	const consent = useLedger((s) => s.consent);
	const frozen = useLedger((s) => s.frozen);
	const balance = useLedger((s) => s.balance);
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const pendingPurchases = useLedger((s) => s.pendingPurchases);
	const pendingChores = useLedger((s) => s.pendingChores);
	const reservedUnits = pendingPurchases.reduce((sum, p) => sum + p.price, 0);
	const availableUnits = Math.max(0, balance - reservedUnits);
	const pendingCount = useLedger((s) => s.pendingCount());
	const daysRemaining = useLedger((s) => s.daysRemaining());
	const setScreen = useLedger((s) => s.setScreen);
	const verifyConsent = useLedger((s) => s.verifyConsent);
	const toggleFreeze = useLedger((s) => s.toggleFreeze);
	const approvePurchase = useLedger((s) => s.approvePurchase);
	const denyPurchase = useLedger((s) => s.denyPurchase);
	const approveChore = useLedger((s) => s.approveChore);
	const denyChore = useLedger((s) => s.denyChore);
	const vaultPct = vault / vaultTarget * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "stagger-1 screen-enter",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-muted",
						children: "Parent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display text-3xl font-semibold tracking-tight",
						children: [childName, "'s ledger"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Units load in, never cash out — until a vault matures."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "stagger-2 screen-enter space-y-0 p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 rounded-lg px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 items-center justify-center rounded-md bg-accent-soft text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
									className: "size-5",
									strokeWidth: 1.8
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: "Parental consent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: consent ? "Verified" : "Required before loading Units"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: consent ? "secondary" : "default",
							size: "sm",
							disabled: consent,
							onClick: () => {
								const err = verifyConsent();
								if (err) toast.message(err);
								else toast.success("Consent verified");
							},
							children: consent ? "Verified" : "Verify"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-3 h-px bg-border" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 rounded-lg px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 items-center justify-center rounded-md bg-surface-2 text-ink",
								children: frozen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Snowflake, {
									className: "size-5",
									strokeWidth: 1.8
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
									className: "size-5",
									strokeWidth: 1.8
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: "Child access"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: frozen ? "Frozen — spend and chores paused" : "Active"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => toast.message(toggleFreeze()),
							children: frozen ? "Unfreeze" : "Freeze"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-3 screen-enter overflow-hidden rounded-xl bg-ink p-5 text-bg shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-bg/60",
						children: "Spendable balance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-5xl font-semibold tracking-tight tabular-nums",
						children: formatUnits(balance)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-bg/70",
						children: [
							"Pillar Units · ",
							availableUnits,
							" available to approve or spend"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "stagger-4 screen-enter bg-vault p-5 text-vault-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
							children: "Savings vault"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl font-semibold tabular-nums",
							children: formatUnits(vault)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-vault-foreground/75",
							children: [
								vaultGoal,
								" ·",
								" ",
								daysRemaining === 0 ? "Matured" : `Matures in ${daysRemaining} days`
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {
						className: "size-5 opacity-70",
						strokeWidth: 1.6
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: vaultPct,
					className: "mt-4 bg-white/15",
					barClassName: "bg-vault-foreground"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Pending"
					}), reservedUnits > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-xs text-muted",
						children: [reservedUnits, " Units reserved by purchase requests"]
					}) : null] }), pendingCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "danger",
						children: pendingCount
					}) : null]
				}), pendingCount === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-4 text-center text-sm text-muted",
					children: "No requests right now."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "divide-y divide-border",
					children: [pendingPurchases.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 py-3 first:pt-0 last:pb-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
									name: p.icon,
									className: "size-5"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-medium",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted",
									children: [p.price, " Units · Marketplace"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "success",
									size: "icon-sm",
									"aria-label": "Approve",
									onClick: () => {
										const err = approvePurchase(p.id);
										if (err) toast.error(err);
										else toast.success("Purchase approved");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon-sm",
									"aria-label": "Deny",
									onClick: () => {
										denyPurchase(p.id);
										toast.message("Purchase denied");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" })
								})]
							})
						]
					}, p.id)), pendingChores.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 py-3 first:pt-0 last:pb-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-accent-soft text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, {
									className: "size-5",
									strokeWidth: 1.7
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-medium",
									children: c.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted",
									children: [
										"+",
										c.amount,
										" Units · Goal"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "success",
									size: "icon-sm",
									"aria-label": "Award",
									onClick: () => {
										const err = approveChore(c.id);
										if (err) toast.error(err);
										else toast.success(`+${c.amount} Units awarded`);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon-sm",
									"aria-label": "Deny",
									onClick: () => {
										denyChore(c.id);
										toast.message("Goal not awarded");
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "size-4" })
								})]
							})
						]
					}, c.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "h-12",
						disabled: !consent,
						onClick: () => setScreen("load"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "size-4" }), "Load Units"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "h-12",
						disabled: !consent,
						onClick: () => setScreen("award"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4" }), "Award"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("vault"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" }), "Vault"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("history"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" }), "History"]
					})
				]
			})
		]
	});
}
function ParentLoad() {
	const [amount, setAmount] = (0, import_react.useState)(20);
	const [ack, setAck] = (0, import_react.useState)(false);
	const loadUnits = useLedger((s) => s.loadUnits);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Add Units"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Units are for spending in the PillarPath Marketplace or locking in the vault."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-warn-soft p-4 text-sm text-warn",
				children: "Once loaded, Units are not refundable as cash. Cash is only available to the child when a vault reaches maturity."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "load-amount",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "load-amount",
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: [
							10,
							20,
							50
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: amount === n ? "default" : "outline",
							size: "sm",
							className: "flex-1",
							onClick: () => setAmount(n),
							children: n
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-start gap-3 rounded-md bg-surface-2 p-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: ack,
							onChange: (e) => setAck(e.target.checked),
							className: "mt-0.5 size-4 accent-accent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I understand these Units cannot be withdrawn as cash until a vault matures." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: !ack || amount < 1,
						onClick: () => {
							const err = loadUnits(amount);
							if (err) toast.error(err);
							else toast.success(`${amount} Units loaded — non-refundable`);
						},
						children: "Confirm and load"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
function ParentAward() {
	const [reason, setReason] = (0, import_react.useState)(AWARD_REASONS[0]);
	const [amount, setAmount] = (0, import_react.useState)(5);
	const awardUnits = useLedger((s) => s.awardUnits);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Award"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Reward a goal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Direct awards skip the child's request queue."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "award-reason",
						children: "Reason"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
						id: "award-reason",
						value: reason,
						onChange: (e) => setReason(e.target.value),
						children: AWARD_REASONS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: r,
							children: r
						}, r))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "award-amount",
						children: "Units"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "award-amount",
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						onClick: () => {
							const err = awardUnits(amount, reason);
							if (err) toast.error(err);
							else toast.success(`+${amount} Units awarded`);
						},
						children: "Award Units"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
function ParentVault() {
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const matchRate = useLedger((s) => s.matchRate);
	const daysRemaining = useLedger((s) => s.daysRemaining());
	const setMatchRate = useLedger((s) => s.setMatchRate);
	const advanceVaultDays = useLedger((s) => s.advanceVaultDays);
	const releaseVault = useLedger((s) => s.releaseVault);
	const setScreen = useLedger((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Vault"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Long-term savings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Locked Units become cash only at maturity."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "bg-vault p-5 text-vault-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
						children: "Currently locked"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl font-semibold tabular-nums",
						children: formatUnits(vault)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-vault-foreground/75",
						children: ["Goal: ", vaultGoal]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: vault / vaultTarget * 100,
						className: "mt-4 bg-white/15",
						barClassName: "bg-vault-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-vault-foreground/80",
						children: daysRemaining === 0 ? "Ready to release as cash for Alex." : `${daysRemaining} days until cash can be released.`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Parent matching"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "Optionally match what Alex locks. Matched Units go straight into the vault." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
						value: String(matchRate),
						onChange: (e) => {
							const v = Number(e.target.value);
							toast.success(setMatchRate(v));
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "0",
								children: "No matching"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "0.5",
								children: "Match 50%"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "1",
								children: "Match 100%"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Demo clock"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, { children: "Fast-forward maturity so you can try a cash release without waiting 28 days." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "flex-1",
							onClick: () => toast.message(advanceVaultDays(7)),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastForward, { className: "size-4" }), "+7 days"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "vault",
							className: "flex-1",
							disabled: daysRemaining > 0 || vault <= 0,
							onClick: () => {
								const err = releaseVault();
								if (err) toast.error(err);
								else {
									toast.success("Cash payout marked for Alex");
									setScreen("home");
								}
							},
							children: "Release cash"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
function ParentHistory() {
	const history = useLedger((s) => s.history);
	const resetDemo = useLedger((s) => s.resetDemo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Ledger"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "History"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Every load, award, lock, and spend — kept on this device."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "ledger-ruled p-0",
				children: history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted",
					children: "No events yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: history.map((e) => {
					const signed = e.kind === "debit" || e.kind === "transfer" || e.kind === "cashout" ? "out" : e.kind === "event" ? "none" : "in";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3 px-4 py-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: e.note
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted",
								children: formatWhen(e.at)
							})]
						}), signed !== "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `shrink-0 font-mono text-sm tabular-nums ${signed === "in" ? "text-success" : "text-ink"}`,
							children: [signed === "in" ? "+" : "−", e.amount]
						}) : null]
					}, e.id);
				}) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => {
					resetDemo();
					toast.message("Demo reset");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset demo"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {})
		]
	});
}
var CHORE_ICON = {
	homework: BookOpen,
	room: House,
	dishes: Utensils
};
function BackHome() {
	const setScreen = useLedger((s) => s.setScreen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		className: "w-full",
		onClick: () => setScreen("home"),
		children: "Back"
	});
}
function FrozenBanner() {
	if (!useLedger((s) => s.frozen)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 rounded-lg bg-warn-soft px-3 py-2.5 text-sm text-warn",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 shrink-0" }), "Your parent paused this ledger. You can look, not spend."]
	});
}
function ChildHome() {
	const childName = useLedger((s) => s.childName);
	const balance = useLedger((s) => s.balance);
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const frozen = useLedger((s) => s.frozen);
	const pendingChores = useLedger((s) => s.pendingChores);
	const completedChoreIds = useLedger((s) => s.completedChoreIds);
	const pendingPurchases = useLedger((s) => s.pendingPurchases);
	const reserved = pendingPurchases.reduce((sum, p) => sum + p.price, 0);
	const available = Math.max(0, balance - reserved);
	const setScreen = useLedger((s) => s.setScreen);
	const completeChore = useLedger((s) => s.completeChore);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium text-muted",
					children: ["Hi ", childName]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Your ledger"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Earn Units. Spend them here. Save the rest."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-xl bg-ink p-5 text-bg shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-bg/60",
						children: "Spendable"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-5xl font-semibold tracking-tight tabular-nums",
						children: formatUnits(balance)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-bg/70",
						children: [
							"Pillar Units · ",
							available,
							" available"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "bg-vault p-5 text-vault-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
						children: "Savings vault"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-3xl font-semibold tabular-nums",
						children: formatUnits(vault)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-vault-foreground/75",
						children: [
							vaultGoal,
							" · ",
							Math.round(vault / vaultTarget * 100),
							"% of goal"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: vault / vaultTarget * 100,
						className: "mt-4 bg-white/15",
						barClassName: "bg-vault-foreground"
					})
				]
			}),
			pendingPurchases.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "mb-2 text-base",
					children: "Waiting on parent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: pendingPurchases.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
								name: p.icon,
								className: "size-4 text-muted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono tabular-nums text-muted",
								children: p.price
							})
						]
					}, p.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "mb-1 text-base",
						children: "Today's goals"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: "Mark done — your parent awards the Units."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-border",
						children: CHORES.map((c) => {
							const Icon = CHORE_ICON[c.id];
							const pending = pendingChores.some((p) => p.choreId === c.id);
							const done = completedChoreIds.includes(c.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 py-3 first:pt-0 last:pb-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-ink",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-5",
											strokeWidth: 1.7
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-medium",
											children: c.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted",
											children: [
												"Earn ",
												c.amount,
												" Units"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: done ? "secondary" : pending ? "outline" : "default",
										disabled: frozen || pending || done,
										onClick: () => {
											const err = completeChore(c.id);
											if (err) toast.error(err);
											else toast.success("Sent to your parent");
										},
										children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), "Done"] }) : pending ? "Waiting" : "Done"
									})
								]
							}, c.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "border-accent/20 bg-accent-soft p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
							className: "text-base",
							children: "Money Lab"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Learn how spending, saving, and matching work before you use your Units."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					className: "mt-3 w-full",
					onClick: () => setScreen("learn"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleDollarSign, { className: "size-4" }), "Learn a money skill"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "h-12",
						onClick: () => setScreen("market"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4" }), "Open marketplace"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("vault"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" }), "Savings vault"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "h-12",
						onClick: () => setScreen("studio"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brush, { className: "size-4" }), "Creative studio"]
					})
				]
			})
		]
	});
}
function ChildMarket() {
	const selectProduct = useLedger((s) => s.selectProduct);
	const setScreen = useLedger((s) => s.setScreen);
	const balance = useLedger((s) => s.balance);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Marketplace"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Spend Units here"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"You have ",
						formatUnits(balance),
						" Units. Parent approval required."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3",
				children: PRODUCTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => selectProduct(p.id),
					className: "overflow-hidden rounded-xl bg-surface p-0 text-left shadow-[var(--shadow-border)] transition-[scale,box-shadow] duration-150 ease-out active:scale-[0.96]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-24 items-center justify-center bg-surface-2 text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
							name: p.icon,
							className: "size-9"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium leading-snug",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 font-mono text-sm tabular-nums text-accent",
							children: [p.price, " Units"]
						})]
					})]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => setScreen("home"),
				children: "Back"
			})
		]
	});
}
function ChildConfirm() {
	const selectedProductId = useLedger((s) => s.selectedProductId);
	const requestPurchase = useLedger((s) => s.requestPurchase);
	const setScreen = useLedger((s) => s.setScreen);
	const product = PRODUCTS.find((p) => p.id === selectedProductId);
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "No item selected."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "w-full",
			onClick: () => setScreen("market"),
			children: "Browse marketplace"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Confirm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Ask your parent"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "They will approve or deny this request."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col items-center py-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-16 items-center justify-center rounded-lg bg-surface-2 text-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
							name: product.icon,
							className: "size-8"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-xl font-semibold",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: product.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-display text-3xl font-semibold tabular-nums text-accent",
						children: [product.price, " Units"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				onClick: () => {
					const err = requestPurchase(product.id);
					if (err) toast.error(err);
					else toast.success("Request sent to your parent");
				},
				children: "Send request"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => setScreen("market"),
				children: "Back"
			})
		]
	});
}
function ChildVault() {
	const [amount, setAmount] = (0, import_react.useState)(5);
	const vault = useLedger((s) => s.vault);
	const vaultTarget = useLedger((s) => s.vaultTarget);
	const vaultGoal = useLedger((s) => s.vaultGoal);
	const matchRate = useLedger((s) => s.matchRate);
	const daysRemaining = useLedger((s) => s.daysRemaining());
	const lockUnits = useLedger((s) => s.lockUnits);
	const frozen = useLedger((s) => s.frozen);
	const match = Math.floor(amount * matchRate);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Vault"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Lock for later"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "When it matures, this becomes cash for you."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrozenBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "bg-vault p-5 text-vault-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
						children: vaultGoal
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-4xl font-semibold tabular-nums",
						children: formatUnits(vault)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-vault-foreground/75",
						children: "Units locked"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: vault / vaultTarget * 100,
						className: "mt-4 bg-white/15",
						barClassName: "bg-vault-foreground"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-vault-foreground/80",
						children: daysRemaining === 0 ? "Matured — your parent can release cash." : `${daysRemaining} days until maturity.`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Lock more Units"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "lock-amount",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "lock-amount",
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value))
					}),
					matchRate > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Parent match: +",
							match,
							" Units added to the vault."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: frozen,
						onClick: () => {
							const err = lockUnits(amount);
							if (err) toast.error(err);
							else toast.success(`${amount} Units locked`);
						},
						children: "Lock in vault"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackHome, {})
		]
	});
}
function ChildLearn() {
	const setScreen = useLedger((s) => s.setScreen);
	const vault = useLedger((s) => s.vault);
	const balance = useLedger((s) => s.balance);
	const matchRate = useLedger((s) => s.matchRate);
	const lessons = [
		{
			icon: Target,
			title: "Give every Unit a job",
			text: "Spend some, save some, and keep a little room for a goal. You do not have to use everything you earn."
		},
		{
			icon: Landmark,
			title: "Saving gets easier with a match",
			text: matchRate > 0 ? `Your parent currently matches ${Math.round(matchRate * 100)}% of what you lock in the Vault.` : "Your parent can choose to match Units you lock in the Vault."
		},
		{
			icon: CircleDollarSign,
			title: "Check before you spend",
			text: `You have ${formatUnits(balance)} Units in your ledger and ${formatUnits(vault)} Units already working toward your savings goal.`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Money Lab"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Build your money skills"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Small lessons now make bigger choices easier later."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "bg-vault p-5 text-vault-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-vault-foreground/60",
						children: "Your rule"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-2xl font-semibold",
						children: "Earn · Choose · Save"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-vault-foreground/75",
						children: "PillarPath lets you practice with Units while a parent stays in control."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: lessons.map((lesson, index) => {
					const Icon = lesson.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-accent-soft text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-medium uppercase tracking-wider text-muted",
									children: ["Skill ", index + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-0.5 text-base font-semibold",
									children: lesson.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: lesson.text
								})
							] })]
						})
					}, lesson.title);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				onClick: () => setScreen("home"),
				children: "Back to my ledger"
			})
		]
	});
}
var SWATCHES = [
	"#1c1a16",
	"#1f6b5c",
	"#b5453a",
	"#8a6420",
	"#6b5bd6",
	"#faf7f1"
];
var SIZES = [
	3,
	6,
	12
];
var COLORING_PAGES = [
	"Rocket Adventure",
	"Ocean Friends",
	"Dinosaur Day",
	"Space Garden"
];
var CRAFTS = [
	"Paper crown",
	"Animal mask",
	"Friendship card",
	"Mini kite"
];
function StudioScreen({ studioPlus = false }) {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const drawing = (0, import_react.useRef)(false);
	const [color, setColor] = (0, import_react.useState)(SWATCHES[0]);
	const [size, setSize] = (0, import_react.useState)(6);
	const [tab, setTab] = (0, import_react.useState)("draw");
	const [shirtColor, setShirtColor] = (0, import_react.useState)("#1f6b5c");
	const [shirtText, setShirtText] = (0, import_react.useState)("PILLAR POWER");
	const [game, setGame] = (0, import_react.useState)({
		score: 0,
		round: 0
	});
	const saveDrawing = useLedger((s) => s.saveDrawing);
	const drawings = useLedger((s) => s.drawings);
	const setScreen = useLedger((s) => s.setScreen);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const fit = () => {
			const rect = wrap.getBoundingClientRect();
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			canvas.width = Math.floor(rect.width * dpr);
			canvas.height = Math.floor(260 * dpr);
			canvas.style.width = `${rect.width}px`;
			canvas.style.height = "260px";
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.fillStyle = "#ffffff";
			ctx.fillRect(0, 0, rect.width, 260);
			ctx.lineCap = "round";
			ctx.lineJoin = "round";
		};
		fit();
		window.addEventListener("resize", fit);
		return () => window.removeEventListener("resize", fit);
	}, []);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const ctx = canvas?.getContext("2d");
		if (!canvas || !ctx) return;
		const pos = (e) => {
			const r = canvas.getBoundingClientRect();
			const t = "touches" in e ? e.touches[0] : e;
			return t ? {
				x: t.clientX - r.left,
				y: t.clientY - r.top
			} : null;
		};
		const start = (e) => {
			if ("touches" in e) e.preventDefault();
			const p = pos(e);
			if (!p) return;
			drawing.current = true;
			ctx.beginPath();
			ctx.strokeStyle = color;
			ctx.lineWidth = size;
			ctx.moveTo(p.x, p.y);
		};
		const move = (e) => {
			if (!drawing.current) return;
			if ("touches" in e) e.preventDefault();
			const p = pos(e);
			if (!p) return;
			ctx.lineTo(p.x, p.y);
			ctx.stroke();
		};
		const end = () => {
			drawing.current = false;
		};
		canvas.addEventListener("mousedown", start);
		canvas.addEventListener("mousemove", move);
		window.addEventListener("mouseup", end);
		canvas.addEventListener("touchstart", start, { passive: false });
		canvas.addEventListener("touchmove", move, { passive: false });
		window.addEventListener("touchend", end);
		return () => {
			canvas.removeEventListener("mousedown", start);
			canvas.removeEventListener("mousemove", move);
			window.removeEventListener("mouseup", end);
			canvas.removeEventListener("touchstart", start);
			canvas.removeEventListener("touchmove", move);
			window.removeEventListener("touchend", end);
		};
	}, [color, size]);
	function clear() {
		const canvas = canvasRef.current;
		const ctx = canvas?.getContext("2d");
		if (!canvas || !ctx) return;
		const r = canvas.getBoundingClientRect();
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, r.width, 260);
	}
	function save() {
		const canvas = canvasRef.current;
		if (!canvas) return;
		saveDrawing(canvas.toDataURL("image/png"));
		toast.success("Design saved");
	}
	function printCreation() {
		window.print();
	}
	function advanceGame(correct) {
		setGame((g) => ({
			score: g.score + (correct ? 1 : 0),
			round: g.round + 1
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "screen-enter space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: "Creative Studio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold tracking-tight",
					children: "Make, play, print, create."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Create art and projects that can become printable keepsakes or custom merchandise."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-5 gap-1 rounded-xl bg-surface-2 p-1",
				children: [
					[
						"draw",
						"Draw",
						Brush
					],
					[
						"coloring",
						"Coloring",
						Palette
					],
					[
						"crafts",
						"Crafts",
						Sparkles
					],
					[
						"shirt",
						"T-shirts",
						Shirt
					],
					[
						"games",
						"Brain + Move",
						Gamepad2
					]
				].map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(id),
					className: `min-h-11 rounded-lg px-1 text-[10px] font-semibold sm:text-xs ${tab === id ? "bg-surface text-ink shadow-[var(--shadow-border)]" : "text-muted"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mx-auto mb-1 size-4" }), label]
				}, id))
			}),
			tab === "draw" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: wrapRef,
						className: "overflow-hidden rounded-lg bg-paper shadow-[var(--shadow-border)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: canvasRef,
							className: "block h-[260px] w-full touch-none",
							"aria-label": "Drawing canvas"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 px-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							children: SWATCHES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Color ${c}`,
								onClick: () => setColor(c),
								className: "size-8 rounded-full shadow-[var(--shadow-border)]",
								style: {
									background: c,
									outline: color === c ? "2px solid var(--color-ink)" : "2px solid transparent",
									outlineOffset: "2px"
								}
							}, c))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1.5",
							children: SIZES.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Brush ${n}`,
								onClick: () => setSize(n),
								className: `flex size-8 items-center justify-center rounded-sm ${size === n ? "bg-ink text-bg" : "bg-surface-2 text-ink"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block rounded-full bg-current",
									style: {
										width: n,
										height: n
									}
								})
							}, n))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "flex-1",
								onClick: clear,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, { className: "size-4" }), "Clear"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "flex-1",
								onClick: printCreation,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Print"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "flex-1",
								onClick: save,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "Save"]
							})
						]
					})
				]
			}) : null,
			tab === "coloring" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGate, {
				studioPlus,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Printable coloring book" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
							className: "mt-1",
							children: "Pick a page, color it in Studio, then print a keepsake."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid grid-cols-2 gap-3",
							children: COLORING_PAGES.map((page, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setTab("draw");
									toast.message(`${page} template loaded — add your own colors`);
								},
								className: "rounded-xl border border-border bg-surface-2 p-4 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-3 grid aspect-square place-items-center rounded-lg bg-surface text-4xl",
									children: [
										"🚀",
										"🐠",
										"🦖",
										"🌙"
									][i]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-semibold",
									children: page
								})]
							}, page))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "mt-4 w-full",
							onClick: printCreation,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Print current creation"]
						})
					]
				})
			}) : null,
			tab === "crafts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGate, {
				studioPlus,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Digital arts & crafts" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
							className: "mt-1",
							children: "Turn an idea into a simple project card with materials and steps."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid gap-3 sm:grid-cols-2",
							children: CRAFTS.map((craft) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-surface-2 p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl",
										children: "✂️"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 font-semibold",
										children: craft
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted",
										children: "Paper · crayons · scissors · imagination"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										size: "sm",
										className: "mt-3",
										onClick: () => toast.success(`${craft} project started`),
										children: "Start project"
									})
								]
							}, craft))
						})
					]
				})
			}) : null,
			tab === "shirt" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGate, {
				studioPlus,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Design your own T-shirt" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
							className: "mt-1",
							children: "Create artwork for a future print-on-demand product. Parent approval is required before any purchase."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-5 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid min-h-64 place-items-center rounded-xl bg-surface-2 p-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative grid h-52 w-44 place-items-center",
									style: { color: shirtColor },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shirt, {
										className: "absolute size-full",
										fill: "currentColor",
										strokeWidth: 1.2
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "relative z-10 max-w-28 text-center text-lg font-black tracking-tight text-white",
										children: shirtText
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm font-semibold",
										children: ["Shirt color", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "color",
											value: shirtColor,
											onChange: (e) => setShirtColor(e.target.value),
											className: "mt-2 h-11 w-full rounded-lg border border-border bg-surface"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm font-semibold",
										children: ["Front text", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: shirtText,
											onChange: (e) => setShirtText(e.target.value.slice(0, 24)),
											className: "mt-2 h-11 w-full rounded-lg border border-border bg-surface px-3"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										className: "w-full",
										onClick: () => toast.success("T-shirt design saved for parent review"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Save design"]
									})
								]
							})]
						})
					]
				})
			}) : null,
			tab === "games" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureGate, {
				studioPlus,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-10 place-items-center rounded-xl bg-accent-soft text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gamepad2, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Brain + Move Lab" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
								className: "mt-1",
								children: "Short logic, memory, focus and movement challenges. This is a skills tracker, not an IQ test or clinical assessment."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 rounded-xl bg-surface-2 p-5 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-subtle",
									children: "Practice progress"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-display text-4xl font-semibold",
									children: [
										game.score,
										"/",
										game.round || 0
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
									value: game.round ? game.score / game.round * 100 : 0,
									className: "mt-3"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm text-muted",
									children: [
										"Round ",
										Math.min(game.round + 1, 10),
										" of 10"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => advanceGame(true),
								children: "Pattern ✓"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => advanceGame(false),
								children: "Try movement"
							})]
						}),
						game.round >= 10 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-xl bg-accent-soft p-4 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "inline size-4 text-accent" }), " Great practice session. Track improvement over time with your parent."]
						}) : null
					]
				})
			}) : null,
			drawings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Saved creations"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => useLedger.getState().clearDrawings(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "Clear all"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				children: drawings.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: d.dataUrl,
					alt: "Saved creation",
					className: "aspect-square w-full rounded-md object-cover shadow-[var(--shadow-border)] outline outline-1 -outline-offset-1 outline-ink/10"
				}, d.id))
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => setScreen("home"),
				children: "Back"
			})
		]
	});
}
function FeatureGate({ studioPlus, children }) {
	if (studioPlus) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "border-accent/20 bg-accent-soft p-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, { className: "mx-auto size-8 text-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 font-display text-xl font-semibold",
				children: "Studio Plus required"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-md text-sm text-muted",
				children: "Your parent can activate the $4.99 Creative Studio Plus pass in the Unit Market. Advanced features are parent-controlled."
			})
		]
	});
}
var MARKET_POINTS = [
	42,
	45,
	44,
	49,
	52,
	50,
	56,
	61,
	59,
	64,
	67,
	71
];
function UnitMarketView({ data, onRefresh }) {
	const balance = useLedger((s) => s.balance);
	const vault = useLedger((s) => s.vault);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const studioPlus = Boolean(data.profile.studio_plus);
	const peak = Math.max(...MARKET_POINTS);
	const current = MARKET_POINTS.at(-1) ?? 0;
	const velocity = Math.round((balance + vault) / 10);
	const savingsRate = Math.round(vault / Math.max(1, balance + vault) * 100);
	const path = (0, import_react.useMemo)(() => MARKET_POINTS.map((value, i) => `${i / (MARKET_POINTS.length - 1) * 100},${100 - value / peak * 78}`).join(" "), [peak]);
	async function unlockStudio() {
		setLoading(true);
		try {
			const result = await createStudioCheckout({ data: {} });
			if (result.checkoutUrl) window.location.href = result.checkoutUrl;
			else {
				await onRefresh();
				toast.success("Studio Plus preview activated");
			}
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not open Studio Plus checkout");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold uppercase tracking-[0.16em] text-accent",
					children: "Parent workspace"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "PillarPath Unit Market"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: "A family-account activity dashboard for Pillar Units. It is a simulation/analytics view — Units are closed-loop, non-refundable credits and are not stocks or tradable securities."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-subtle",
								children: "Activity index"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-3xl font-semibold",
								children: current
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Illustrative family activity"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-subtle",
								children: "Unit velocity"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-3xl font-semibold",
								children: velocity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Spend + save activity"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-subtle",
								children: "Savings rate"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-display text-3xl font-semibold",
								children: [savingsRate, "%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Vault share of family Units"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-subtle",
								children: "Children"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-3xl font-semibold",
								children: data.children.length
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Supervised profiles"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Unit activity chart" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
						className: "mt-1",
						children: "Demo index for product analytics; not a market price."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-5 text-accent" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 h-56 rounded-xl bg-surface-2 p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 100 100",
						className: "h-full w-full",
						preserveAspectRatio: "none",
						role: "img",
						"aria-label": "Illustrative Pillar Unit activity chart",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
							points: path,
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "2",
							vectorEffect: "non-scaling-stroke",
							className: "text-accent"
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "border-accent/20 bg-accent-soft p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-10 place-items-center rounded-xl bg-surface text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Creative Studio Plus" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
									className: "mt-1",
									children: "Unlock printable coloring books, custom apparel designs, advanced crafts, and cognitive-skill games for the child profile."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: "$4.99"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-2 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-lg bg-surface p-3 text-sm",
								children: "Printable creations"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-lg bg-surface p-3 text-sm",
								children: "T-shirt designer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-lg bg-surface p-3 text-sm",
								children: "Skill progress games"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4 w-full sm:w-auto",
						disabled: studioPlus || loading,
						onClick: unlockStudio,
						children: studioPlus ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), " Active"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { className: "size-4" }), " Activate for $4.99"] })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Family ecosystem signals" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-lg bg-surface-2 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-accent" }), " Parent approvals"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-lg bg-surface-2 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-4 text-accent" }), " Store activity"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-lg bg-surface-2 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4 text-accent" }), " Savings behavior"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
						value: savingsRate,
						className: "mt-4"
					})
				]
			})
		]
	});
}
/**
* Connector catalog for PillarPath's family-commerce ecosystem.
* These are integration targets, not claims that PillarPath currently has
* a commercial affiliation with every provider listed here.
*/
var PARTNER_INTEGRATIONS = [
	{
		id: "stripe",
		name: "Stripe",
		kind: "commerce",
		description: "Parent checkout and paid Studio upgrades.",
		envKey: "STRIPE_SECRET_KEY",
		status: "ready"
	},
	{
		id: "shopify",
		name: "Shopify",
		kind: "commerce",
		description: "Optional catalog/order sync for a PillarPath-owned storefront.",
		envKey: "SHOPIFY_ACCESS_TOKEN",
		status: "configure"
	},
	{
		id: "printful",
		name: "Printful",
		kind: "dropshipping",
		description: "Print-on-demand apparel and creative merchandise.",
		envKey: "PRINTFUL_API_KEY",
		status: "configure"
	},
	{
		id: "printify",
		name: "Printify",
		kind: "dropshipping",
		description: "Print-on-demand products and custom designs.",
		envKey: "PRINTIFY_API_TOKEN",
		status: "configure"
	},
	{
		id: "cjdropshipping",
		name: "CJdropshipping",
		kind: "dropshipping",
		description: "Product sourcing and supplier fulfillment.",
		envKey: "CJ_API_KEY",
		status: "configure"
	},
	{
		id: "spocket",
		name: "Spocket",
		kind: "dropshipping",
		description: "Supplier discovery and curated fulfillment.",
		envKey: "SPOCKET_API_KEY",
		status: "configure"
	},
	{
		id: "impact",
		name: "impact.com",
		kind: "marketing",
		description: "Partner and affiliate program management.",
		envKey: "IMPACT_API_KEY",
		status: "configure"
	},
	{
		id: "awin",
		name: "Awin",
		kind: "marketing",
		description: "Affiliate network connectivity and publisher tracking.",
		envKey: "AWIN_API_TOKEN",
		status: "configure"
	},
	{
		id: "klaviyo",
		name: "Klaviyo",
		kind: "marketing",
		description: "Parent-approved lifecycle email and commerce messaging.",
		envKey: "KLAVIYO_API_KEY",
		status: "configure"
	},
	{
		id: "mailchimp",
		name: "Mailchimp",
		kind: "marketing",
		description: "Optional email audience and campaign sync.",
		envKey: "MAILCHIMP_API_KEY",
		status: "configure"
	},
	{
		id: "meta",
		name: "Meta",
		kind: "marketing",
		description: "Optional campaign measurement and audience tooling.",
		envKey: "META_ACCESS_TOKEN",
		status: "configure"
	},
	{
		id: "google-ads",
		name: "Google Ads",
		kind: "marketing",
		description: "Optional acquisition campaign measurement.",
		envKey: "GOOGLE_ADS_TOKEN",
		status: "configure"
	},
	{
		id: "tiktok",
		name: "TikTok for Business",
		kind: "marketing",
		description: "Optional campaign measurement and creative distribution.",
		envKey: "TIKTOK_ACCESS_TOKEN",
		status: "configure"
	}
];
var icons = {
	marketing: Megaphone,
	dropshipping: Truck,
	commerce: Store,
	creative: Palette
};
function PartnerHubView() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold uppercase tracking-[0.16em] text-accent",
					children: "PillarPath ecosystem"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
					children: "Marketing & fulfillment partners"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-3xl text-sm text-muted",
					children: "A centralized connector catalog for the companies and services that can support PillarPath's family-commerce mission. Providers shown here are integration targets; a provider is not represented as an existing affiliate unless its connection is actually configured."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2 xl:grid-cols-3",
				children: PARTNER_INTEGRATIONS.map((partner) => {
					const Icon = icons[partner.kind];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-10 place-items-center rounded-xl bg-accent-soft text-accent",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
										className: "text-base",
										children: partner.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
										className: "mt-1",
										children: partner.description
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: partner.status === "ready" ? "accent" : "muted",
									children: partner.status === "ready" ? "Ready" : "Configure"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center gap-2 text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlugZap, { className: "size-3.5" }),
								" Server secret: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: partner.envKey })
							]
						})]
					}, partner.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "border-accent/20 bg-accent-soft p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Handshake, { className: "mt-0.5 size-5 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: "Safe integration rule"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
						className: "mt-1",
						children: "Keep provider keys server-side. Parent-facing marketing must be consent-aware, and child experiences should never expose supplier credentials, affiliate IDs, or ad-platform tokens."
					})] })]
				})
			})
		]
	});
}
function money(cents) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD"
	}).format(cents / 100);
}
var PRODUCT_ICONS = {
	"pp-backpack": "backpack",
	"pp-art-kit": "art",
	"pp-science": "science",
	"pp-blocks": "blocks",
	"pp-story-pack": "book",
	"pp-sports-ball": "ball"
};
function productIcon(id) {
	return PRODUCT_ICONS[id] ?? "blocks";
}
function SectionIntro({ eyebrow, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-bold uppercase tracking-[0.16em] text-accent",
			children: eyebrow
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-display text-3xl font-semibold tracking-tight sm:text-4xl",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm text-muted",
			children: text
		})
	] });
}
function Metric({ title, value, delta, icon: Icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-wider text-subtle",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-display text-3xl font-semibold tracking-tight tabular-nums",
					children: value
				}),
				delta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: delta
				}) : null
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-10 place-items-center rounded-xl bg-accent-soft text-accent",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
			})]
		})
	});
}
function EmptyState({ icon: Icon, title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-48 place-items-center p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-8 text-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-xl font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-sm text-sm text-muted",
				children: text
			})
		]
	});
}
function ProductArt({ productId, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid aspect-[1.4] place-items-center bg-surface-2 text-accent", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductIcon, {
			name: productIcon(productId),
			className: "size-12"
		})
	});
}
function Dashboard({ data, onNavigate }) {
	const revenue = data.orders.filter((o) => o.status === "paid" || o.status === "preview_payment").reduce((sum, o) => sum + o.total_cents, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between gap-4 md:flex-row md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
					eyebrow: "Parent workspace",
					title: `Welcome, ${data.profile.display_name.split(" ")[0]}`,
					text: "Family ledger, store, marketing, and fulfillment in one place."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => onNavigate("store"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4" }), "Open store"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Store revenue",
						value: money(revenue),
						delta: "Paid and preview orders",
						icon: CircleDollarSign
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Orders",
						value: String(data.orders.length),
						delta: "Latest 20",
						icon: PackageCheck
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Children",
						value: String(data.children.length),
						delta: "Supervised profiles",
						icon: Users
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Campaigns",
						value: String(data.campaigns.length),
						delta: "Growth programs",
						icon: ChartColumn
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 xl:grid-cols-[1.35fr_0.65fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "overflow-hidden p-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Commerce activity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHint, {
							className: "mt-1",
							children: "Orders and payment status"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onNavigate("orders"),
							className: "text-sm font-semibold text-accent",
							children: "View all"
						})]
					}), data.orders.length ? data.orders.slice(0, 6).map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 border-b border-border px-5 py-4 last:border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-10 place-items-center rounded-xl bg-surface-2 text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageCheck, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium",
								children: ["Order #", order.id]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									new Date(order.created_at).toLocaleDateString(),
									" ·",
									" ",
									order.payment_provider
								]
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold tabular-nums",
								children: money(order.total_cents)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: order.status === "paid" || order.status === "preview_payment" ? "accent" : "muted",
								children: order.status.replaceAll("_", " ")
							})]
						})]
					}, order.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						icon: PackageCheck,
						title: "No orders yet",
						text: "Open the store and create your first basket."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-wider text-accent",
							children: "Family pulse"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-xl font-semibold",
							children: "Children at a glance"
						})] }),
						data.children.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-surface-2 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold",
										children: child.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: ["Age ", child.age ?? "—"]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-sm text-accent tabular-nums",
										children: [child.units, " U"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 h-2 rounded-full bg-bg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full bg-accent",
										style: { width: `${Math.min(100, child.vault_units / 70 * 100)}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted",
									children: [child.vault_units, " Units in Vault"]
								})
							]
						}, child.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate("family"),
							className: "flex min-h-11 w-full items-center justify-between rounded-xl border border-border px-4 py-3 text-sm font-semibold hover:bg-surface-2",
							children: ["Manage family", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickAction, {
						icon: Megaphone,
						title: "Build a campaign",
						text: "Create a growth program",
						onClick: () => onNavigate("marketing")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickAction, {
						icon: Truck,
						title: "Review fulfillment",
						text: "Check supplier queues",
						onClick: () => onNavigate("fulfillment")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickAction, {
						icon: Settings,
						title: "Account settings",
						text: "Profile and payment controls",
						onClick: () => onNavigate("settings")
					})
				]
			})
		]
	});
}
function QuickAction({ icon: Icon, title, text, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "rounded-2xl border border-border bg-surface p-5 text-left transition-[transform,border-color,box-shadow] duration-150 hover:-translate-y-0.5 hover:border-accent/40 hover:shadow-[var(--shadow-border-hover)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: text
			})
		]
	});
}
function StoreGrid({ products, onAdded }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
			eyebrow: "PillarPath Marketplace",
			title: "Curated family store",
			text: "Buy with secure checkout, or let kids request items with Units."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
			children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col overflow-hidden p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductArt, { productId: product.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 flex-col p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: product.category
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-xl font-semibold",
								children: product.name
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-sm text-accent tabular-nums",
								children: [product.unit_price, " U"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 flex-1 text-sm text-muted",
							children: product.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold tabular-nums",
								children: money(product.retail_price_cents)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: async () => {
									await addToCart({ data: {
										productId: product.id,
										quantity: 1
									} });
									await onAdded();
									toast.success("Added to basket");
								},
								children: "Add to basket"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-subtle",
							children: [
								"Supplier: ",
								product.supplier_name,
								" · ",
								product.inventory,
								" available"
							]
						})
					]
				})]
			}, product.id))
		})]
	});
}
function OrdersView({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
			eyebrow: "Commerce",
			title: "Orders",
			text: "Payment, fulfillment, and family order history."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "overflow-hidden p-0",
			children: data.orders.length ? data.orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 border-b border-border px-5 py-4 last:border-0 sm:grid-cols-[1fr_auto_auto] sm:items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-semibold",
						children: ["Order #", order.id]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: new Date(order.created_at).toLocaleString()
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: order.status === "paid" || order.status === "preview_payment" ? "accent" : "muted",
						children: order.status.replaceAll("_", " ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold tabular-nums",
						children: money(order.total_cents)
					})
				]
			}, order.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: PackageCheck,
				title: "No orders",
				text: "Orders appear here after checkout."
			})
		})]
	});
}
function MarketingView({ data, onRefresh }) {
	const [campaignName, setCampaignName] = (0, import_react.useState)("");
	const [channel, setChannel] = (0, import_react.useState)("Social");
	const [promo, setPromo] = (0, import_react.useState)("");
	const [discount, setDiscount] = (0, import_react.useState)(10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
				eyebrow: "Growth engine",
				title: "Marketing that compounds",
				text: "Campaigns, referrals, and promo codes live beside the store."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 xl:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Campaigns",
						value: String(data.campaigns.length),
						icon: Megaphone
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Referral code",
						value: data.referral?.code ?? "Ready",
						icon: Gift
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Supplier-ready orders",
						value: String(data.fulfillments.length),
						icon: Truck
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 xl:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Launch campaign" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Campaign name",
								value: campaignName,
								onChange: (e) => setCampaignName(e.target.value)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
								value: channel,
								onChange: (e) => setChannel(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Social" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Email" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Search" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Affiliate" })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: async () => {
								if (!campaignName.trim()) return;
								await createCampaign({ data: {
									name: campaignName,
									channel,
									budgetCents: 25e3
								} });
								setCampaignName("");
								await onRefresh();
								toast.success("Campaign created");
							},
							children: ["Create campaign ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "divide-y divide-border",
							children: data.campaigns.map((campaign) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: campaign.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										campaign.channel,
										" · ",
										campaign.clicks,
										" clicks ·",
										" ",
										campaign.conversions,
										" conversions"
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: campaign.status === "active" ? "accent" : "muted",
									children: campaign.status
								})]
							}, campaign.id))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Promotions" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-[1fr_100px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "WELCOME10",
								value: promo,
								onChange: (e) => setPromo(e.target.value)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: discount,
								onChange: (e) => setDiscount(Number(e.target.value))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: async () => {
								if (!promo.trim()) return;
								await createPromoCode({ data: {
									code: promo,
									discountPercent: discount
								} });
								setPromo("");
								toast.success("Promo code saved");
							},
							children: "Save promo code"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-accent-soft p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-accent",
								children: "Referral program"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									"Share",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-ink",
										children: data.referral?.code
									}),
									" ",
									"when you invite another family."
								]
							})]
						})
					]
				})]
			})
		]
	});
}
function FulfillmentView({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
				eyebrow: "Dropshipping",
				title: "Supplier fulfillment center",
				text: "Every paid store order is prepared for supplier routing and tracking."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Queued",
						value: String(data.fulfillments.filter((f) => f.status === "queued").length),
						icon: Boxes
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "In transit",
						value: String(data.fulfillments.filter((f) => f.status === "shipped").length),
						icon: Truck
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						title: "Tracked",
						value: String(data.fulfillments.filter((f) => f.tracking_number).length),
						icon: PackageCheck
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-hidden p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_1fr_120px] gap-4 border-b border-border px-5 py-3 text-xs font-semibold uppercase tracking-wider text-subtle",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Order" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Supplier" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Status" })
					]
				}), data.fulfillments.length ? data.fulfillments.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_1fr_120px] gap-4 border-b border-border px-5 py-4 text-sm last:border-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["#", item.order_id] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.supplier_name }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: item.status === "shipped" ? "accent" : "muted",
							children: item.status
						})
					]
				}, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Truck,
					title: "No fulfillment records yet",
					text: "Complete a store checkout to queue a supplier order."
				})]
			})
		]
	});
}
function FamilyProfiles({ data, onRefresh }) {
	const [childName, setChildName] = (0, import_react.useState)("");
	const [childAge, setChildAge] = (0, import_react.useState)(10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-3",
		children: [data.children.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "relative overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-12 place-items-center rounded-2xl bg-accent-soft text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: child.frozen ? "danger" : "accent",
						children: child.frozen ? "Frozen" : "Active"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-5 font-display text-2xl font-semibold",
					children: child.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Age ",
						child.age ?? "—",
						" · ",
						child.units,
						" Units · ",
						child.vault_units,
						" Vault"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 h-2 rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-accent",
						style: { width: `${Math.min(100, child.vault_units / 70 * 100)}%` }
					})
				})
			]
		}, child.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "border border-dashed border-border bg-transparent shadow-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-11 place-items-center rounded-2xl bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Add a child"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Create another supervised profile."
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Child name",
						value: childName,
						onChange: (e) => setChildName(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 3,
						max: 18,
						value: childAge,
						onChange: (e) => setChildAge(Number(e.target.value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: async () => {
							if (!childName.trim()) return;
							await createChild({ data: {
								name: childName,
								age: childAge,
								avatar: "star"
							} });
							setChildName("");
							await onRefresh();
							toast.success("Child profile created");
						},
						children: "Create profile"
					})
				]
			})]
		})]
	});
}
function SettingsView({ data, onRefresh }) {
	const [displayName, setDisplayName] = (0, import_react.useState)(data.profile.display_name);
	const [phone, setPhone] = (0, import_react.useState)(data.profile.phone ?? "");
	const [optIn, setOptIn] = (0, import_react.useState)(data.profile.marketing_opt_in);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
				eyebrow: "Account",
				title: "Settings and profile",
				text: "Manage the parent account, communication preferences, and commerce defaults."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "max-w-2xl space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Display name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: displayName,
							onChange: (e) => setDisplayName(e.target.value)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: phone,
							onChange: (e) => setPhone(e.target.value)
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-start gap-3 rounded-2xl bg-surface-2 p-4 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-1 size-4 accent-accent",
							checked: optIn,
							onChange: (e) => setOptIn(e.target.checked)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Growth communications" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-muted",
							children: "Product, marketing, and family commerce updates."
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: async () => {
							await saveProfile({ data: {
								displayName,
								phone,
								marketingOptIn: optIn
							} });
							await onRefresh();
							toast.success("Settings saved");
						},
						children: "Save changes"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-semibold",
						children: "Payments"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "PillarPath never stores raw card numbers. Stripe Checkout collects cards and wallets when connected."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: "Cards"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: "Apple Pay"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: "Google Pay"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: "Stripe Link"
							})
						]
					})
				]
			})
		]
	});
}
var parentNav = [
	[
		"dashboard",
		"Overview",
		LayoutDashboard
	],
	[
		"store",
		"Store",
		Store
	],
	[
		"orders",
		"Orders",
		PackageCheck
	],
	[
		"family",
		"Family",
		Users
	],
	[
		"marketing",
		"Marketing",
		Megaphone
	],
	[
		"unit-market",
		"Unit Market",
		ChartColumn
	],
	[
		"partners",
		"Partners",
		Handshake
	],
	[
		"fulfillment",
		"Dropship",
		Truck
	],
	[
		"settings",
		"Settings",
		Settings
	]
];
var childNav = [
	[
		"home",
		"Home",
		House
	],
	[
		"market",
		"Shop",
		ShoppingBag
	],
	[
		"vault",
		"Vault",
		Gift
	],
	[
		"studio",
		"Studio",
		Sparkles
	]
];
function PillarPathApp() {
	const user = useCurrentUser();
	const [data, setData] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [loadError, setLoadError] = (0, import_react.useState)(null);
	const [role, setRole] = (0, import_react.useState)("parent");
	const [parentSection, setParentSection] = (0, import_react.useState)("dashboard");
	const [familyTab, setFamilyTab] = (0, import_react.useState)("profiles");
	const [basketOpen, setBasketOpen] = (0, import_react.useState)(false);
	const [checkoutOpen, setCheckoutOpen] = (0, import_react.useState)(false);
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const consent = useLedger((s) => s.consent);
	const ledgerScreen = useLedger((s) => s.screen);
	const setLedgerRole = useLedger((s) => s.setRole);
	const setLedgerScreen = useLedger((s) => s.setScreen);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useLedger.persist.rehydrate());
	}, []);
	const refresh = (0, import_react.useCallback)(async () => {
		setLoading(true);
		setLoadError(null);
		try {
			setData(await getPillarPathData());
		} catch (error) {
			const message = error instanceof Error ? error.message : "Could not load PillarPath";
			setLoadError(message);
			toast.error(message);
		} finally {
			setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		refresh();
	}, [refresh]);
	const cartMap = (0, import_react.useMemo)(() => new Map((data?.cart ?? []).map((item) => [item.productId, item.quantity])), [data]);
	const cartLines = (0, import_react.useMemo)(() => (data?.products ?? []).filter((product) => cartMap.has(product.id)).map((product) => ({
		product,
		quantity: cartMap.get(product.id) ?? 0
	})), [data, cartMap]);
	const cartTotal = cartLines.reduce((sum, line) => sum + line.product.retail_price_cents * line.quantity, 0);
	if (loadError && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg px-5 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, { className: "size-14" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold",
					children: "Couldn’t load PillarPath"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: loadError
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-5",
					onClick: () => void refresh(),
					children: "Try again"
				})
			]
		})
	});
	if (loading || !data || !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, { className: "size-14" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold",
					children: "Loading PillarPath"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Preparing your family workspace…"
				})
			]
		})
	});
	async function qty(productId, quantity) {
		try {
			await setCartQuantity({ data: {
				productId,
				quantity
			} });
			await refresh();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not update basket");
		}
	}
	function pickRole(next) {
		if (next === "child" && !consent) {
			toast.message("Verify parental consent in Family before opening the child view");
			setRole("parent");
			setParentSection("family");
			setFamilyTab("ledger");
			setLedgerRole("parent");
			setLedgerScreen("home");
			return;
		}
		setRole(next);
		setLedgerRole(next);
		setLedgerScreen("home");
		setMoreOpen(false);
	}
	const title = role === "parent" ? parentNav.find((item) => item[0] === parentSection)?.[1] : childNav.find((item) => item[0] === ledgerScreen)?.[1] ?? "Home";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("min-h-dvh bg-bg text-ink", role === "child" ? "app-child" : "app-parent"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto min-h-dvh max-w-[1500px] lg:grid lg:grid-cols-[240px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "hidden border-r border-border bg-surface/80 p-4 lg:flex lg:flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-8 flex items-center gap-3 px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl font-semibold",
								children: "PillarPath"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Family commerce"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-5 rounded-2xl border border-border bg-surface-2 p-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => pickRole("parent"),
									className: cn("min-h-11 rounded-xl px-2 py-2 text-xs font-semibold", role === "parent" ? "bg-bg text-ink" : "text-muted"),
									children: "Parent"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => pickRole("child"),
									className: cn("min-h-11 rounded-xl px-2 py-2 text-xs font-semibold", role === "child" ? "bg-accent text-accent-foreground" : "text-muted"),
									children: "Child"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "space-y-1",
							children: (role === "parent" ? parentNav : childNav).map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									if (role === "parent") setParentSection(id);
									else setLedgerScreen(id);
								},
								className: cn("flex min-h-11 w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors duration-150", (role === "parent" ? parentSection : ledgerScreen) === id ? "bg-accent-soft text-accent" : "text-muted hover:bg-surface-2 hover:text-ink"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
									label,
									label === "Shop" && cartLines.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto rounded-full bg-accent px-2 py-0.5 text-xs text-accent-foreground",
										children: cartLines.length
									}) : null
								]
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-auto rounded-2xl border border-border bg-bg p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-subtle",
								children: "Commerce stack"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 space-y-2 text-xs text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-3.5" }), " Stripe Checkout ready"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-3.5" }), " Supplier fulfillment ready"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-3.5" }), " Growth tools included"]
									})
								]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
						className: "sticky top-0 z-30 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-xl sm:px-6 lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 lg:hidden",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-xl font-semibold",
										children: "PillarPath"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hidden lg:block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-semibold uppercase tracking-[0.16em] text-accent",
										children: role === "parent" ? "Parent workspace" : "Child space"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "font-display text-xl font-semibold",
										children: title
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setBasketOpen(true),
										className: "relative grid size-11 place-items-center rounded-xl border border-border bg-surface text-muted hover:text-ink",
										"aria-label": "Open basket",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-5" }), cartLines.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-accent px-1 text-[10px] font-bold text-accent-foreground",
											children: cartLines.length
										}) : null]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "rounded-xl border border-border bg-surface px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
									})]
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "px-4 py-5 pb-28 sm:px-6 lg:px-8 lg:py-8",
						children: role === "parent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentWorkspace, {
							data,
							section: parentSection,
							familyTab,
							onFamilyTab: setFamilyTab,
							onNavigate: setParentSection,
							onRefresh: refresh
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildWorkspace, { studioPlus: Boolean(data.profile.studio_plus) })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-surface/95 p-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-xl lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mx-auto grid max-w-3xl gap-1", role === "parent" ? "grid-cols-5" : "grid-cols-4"),
					children: [(role === "parent" ? parentNav.slice(0, 4) : childNav).map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							if (role === "parent") setParentSection(id);
							else setLedgerScreen(id);
						},
						className: cn("flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl text-[10px] font-semibold", (role === "parent" ? parentSection : ledgerScreen) === id ? "bg-accent-soft text-accent" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
					}, id)), role === "parent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMoreOpen(true),
						className: cn("flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl text-[10px] font-semibold", moreOpen || [
							"marketing",
							"unit-market",
							"partners",
							"fulfillment",
							"settings"
						].includes(parentSection) ? "bg-accent-soft text-accent" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" }), "More"]
					}) : null]
				})
			}),
			moreOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close menu",
					className: "absolute inset-0 bg-black/70",
					onClick: () => setMoreOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 rounded-t-[1.75rem] border-t border-border bg-surface p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-semibold",
							children: "More"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMoreOpen(false),
							className: "grid size-11 place-items-center rounded-xl border border-border",
							"aria-label": "Close menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [parentNav.slice(4).map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setParentSection(id);
								setMoreOpen(false);
							},
							className: "flex min-h-14 items-center gap-3 rounded-2xl border border-border bg-bg px-4 text-left text-sm font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-accent" }), label]
						}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => pickRole(role === "parent" ? "child" : "parent"),
							className: "flex min-h-14 items-center gap-3 rounded-2xl border border-border bg-bg px-4 text-left text-sm font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-accent" }),
								"Switch to ",
								role === "parent" ? "child" : "parent"
							]
						})]
					})]
				})]
			}) : null,
			basketOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasketPanel, {
				lines: cartLines,
				total: cartTotal,
				onClose: () => setBasketOpen(false),
				onQty: qty,
				onCheckout: () => {
					if (role === "child") {
						setBasketOpen(false);
						toast.message("Your parent reviews purchases before checkout");
						return;
					}
					setBasketOpen(false);
					setCheckoutOpen(true);
				}
			}) : null,
			checkoutOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutPanel, {
				email: user.primaryEmail ?? "",
				total: cartTotal,
				onClose: () => setCheckoutOpen(false),
				onSuccess: async (url) => {
					if (url) window.location.href = url;
					else {
						setCheckoutOpen(false);
						await refresh();
						toast.success("Preview order created");
					}
				}
			}) : null
		]
	});
}
function ParentWorkspace({ data, section, familyTab, onFamilyTab, onNavigate, onRefresh }) {
	const ledgerScreen = useLedger((s) => s.screen);
	if (section === "store") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreGrid, {
		products: data.products,
		onAdded: onRefresh
	});
	if (section === "orders") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersView, { data });
	if (section === "marketing") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketingView, {
		data,
		onRefresh
	});
	if (section === "unit-market") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitMarketView, {
		data,
		onRefresh
	});
	if (section === "partners") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartnerHubView, {});
	if (section === "fulfillment") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FulfillmentView, { data });
	if (section === "settings") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {
		data,
		onRefresh
	});
	if (section === "family") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
				eyebrow: "Family",
				title: "Profiles and Units ledger",
				text: "Keep each child's earning, saving, and store experience supervised."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "tablist",
				className: "grid max-w-md grid-cols-2 rounded-xl bg-surface-2 p-1",
				children: [["profiles", "Profiles"], ["ledger", "Units ledger"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": familyTab === id,
					onClick: () => onFamilyTab(id),
					className: cn("min-h-11 rounded-lg text-sm font-semibold", familyTab === id ? "bg-surface text-ink shadow-[var(--shadow-border)]" : "text-muted"),
					children: label
				}, id))
			}),
			familyTab === "profiles" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyProfiles, {
				data,
				onRefresh
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-w-xl",
				children: ledgerScreen === "load" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentLoad, {}) : ledgerScreen === "award" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentAward, {}) : ledgerScreen === "vault" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentVault, {}) : ledgerScreen === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentHistory, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentHome, {})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {
		data,
		onNavigate
	});
}
function ChildWorkspace({ studioPlus }) {
	const screen = useLedger((s) => s.screen);
	if (screen === "market") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildMarket, {});
	if (screen === "confirm") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildConfirm, {});
	if (screen === "vault") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildVault, {});
	if (screen === "studio") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioScreen, { studioPlus });
	if (screen === "learn") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildLearn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildHome, {});
}
function BasketPanel({ lines, total, onClose, onQty, onCheckout }) {
	const shipping = total >= 7500 ? 0 : 799;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Close basket",
			className: "absolute inset-0 bg-black/70",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "absolute right-0 top-0 h-full w-full max-w-md overflow-y-auto border-l border-border bg-surface p-5 shadow-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-wider text-accent",
					children: "Basket"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: "Your order"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "grid size-11 place-items-center rounded-xl border border-border",
					"aria-label": "Close basket",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), lines.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 divide-y divide-border",
				children: lines.map(({ product, quantity }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-12 shrink-0 overflow-hidden rounded-xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductArt, {
								productId: product.id,
								className: "aspect-square size-12"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: product.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: money(product.retail_price_cents)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => void onQty(product.id, quantity - 1),
											className: "grid size-8 place-items-center rounded-lg border border-border",
											children: "−"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-5 text-center text-sm tabular-nums",
											children: quantity
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => void onQty(product.id, quantity + 1),
											className: "grid size-8 place-items-center rounded-lg border border-border",
											children: "+"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold tabular-nums",
							children: money(product.retail_price_cents * quantity)
						})
					]
				}, product.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl bg-bg p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Subtotal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Shipping"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: shipping === 0 ? "Free" : money(shipping) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-between border-t border-border pt-4 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(total + shipping)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-4 h-12 w-full",
						onClick: onCheckout,
						children: ["Secure checkout ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-xs text-subtle",
						children: "Card and wallet payments are collected by Stripe Checkout when connected."
					})
				]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: ShoppingBag,
				title: "Basket is empty",
				text: "Add something from the store."
			})]
		})]
	});
}
function CheckoutPanel({ email, total, onClose, onSuccess }) {
	const [shippingName, setShippingName] = (0, import_react.useState)("");
	const [checkoutEmail, setCheckoutEmail] = (0, import_react.useState)(email);
	const [line1, setLine1] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [state, setState] = (0, import_react.useState)("");
	const [postalCode, setPostalCode] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-center bg-black/75 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[92dvh] w-full max-w-xl overflow-y-auto rounded-[2rem] border border-border bg-surface p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-wider text-accent",
						children: "Secure checkout"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-semibold",
						children: "Delivery details"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "grid size-11 place-items-center rounded-xl border border-border",
						"aria-label": "Close checkout",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Full name",
							value: shippingName,
							onChange: (e) => setShippingName(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Email",
							type: "email",
							value: checkoutEmail,
							onChange: (e) => setCheckoutEmail(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Street address",
							value: line1,
							onChange: (e) => setLine1(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "City",
									value: city,
									onChange: (e) => setCity(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "State",
									value: state,
									onChange: (e) => setState(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "ZIP",
									value: postalCode,
									onChange: (e) => setPostalCode(e.target.value)
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 rounded-2xl bg-surface-2 p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-5 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "Payment methods"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Cards · Apple Pay · Google Pay · Stripe Link"
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-5 h-12 w-full",
					disabled: busy || !shippingName || !checkoutEmail || !line1 || !city || !state || !postalCode,
					onClick: async () => {
						setBusy(true);
						try {
							await onSuccess((await createCheckout({ data: {
								email: checkoutEmail,
								shippingName,
								shippingAddress: {
									line1,
									city,
									state,
									postalCode
								}
							} })).checkoutUrl);
						} catch (error) {
							toast.error(error instanceof Error ? error.message : "Checkout failed");
						} finally {
							setBusy(false);
						}
					},
					children: busy ? "Creating secure checkout…" : `Continue to payment · ${money(total + (total >= 7500 ? 0 : 799))}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-xs leading-5 text-subtle",
					children: "PillarPath does not collect or store raw card information."
				})
			]
		})
	});
}
function Home() {
	const { isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PillarPathApp, {}) })] });
}
function BootScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-dvh place-items-center bg-bg text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, { className: "size-14" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold",
					children: "PillarPath"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Preparing your family workspace…"
				})
			]
		})
	});
}
function Landing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border bg-bg/85 px-5 py-4 backdrop-blur-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl font-semibold",
							children: "PillarPath"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Family commerce"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							children: "Sign in"
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-5 py-14 sm:py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl items-center gap-12 lg:grid-cols-[1.15fr_0.85fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold uppercase tracking-[0.18em] text-accent",
							children: "A family operating system"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-4xl font-display text-5xl font-semibold leading-[0.98] tracking-tight sm:text-7xl",
							children: "Earn. Save. Shop. Grow."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-lg leading-8 text-muted",
							children: "Parent controls, child financial learning, a curated store, secure checkout, marketing tools, and supplier fulfillment — in one family-first product."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									className: "h-12 px-5",
									children: ["Create your family account", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#features",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									className: "h-12 px-5",
									children: "Explore the product"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-accent" }), " Parent controlled"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4 text-accent" }), " Secure payments"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "size-4 text-accent" }), " Dropship ready"]
								})
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "overflow-hidden rounded-[2rem] p-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-border bg-surface-2 p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-wider text-accent",
								children: "Live workspace"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-2xl font-semibold",
								children: "One dashboard. Every path."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 p-5 sm:grid-cols-2",
							children: [
								[
									Users,
									"Parent control",
									"Approvals, family profiles, settings"
								],
								[
									WalletCards,
									"Child money",
									"Earn, save, learn, ask to shop"
								],
								[
									ShoppingBag,
									"Marketplace",
									"Curated products and baskets"
								],
								[
									CreditCard,
									"Checkout",
									"Cards and digital wallets"
								],
								[
									Megaphone,
									"Marketing",
									"Campaigns, promo, referrals"
								],
								[
									Truck,
									"Fulfillment",
									"Supplier routing and tracking"
								]
							].map(([Icon, title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border bg-bg p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-accent" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 font-semibold",
										children: title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs leading-5 text-muted",
										children: text
									})
								]
							}, title))
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "features",
				className: "border-y border-border bg-surface/70 px-5 py-14",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-2xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[0.16em] text-accent",
							children: "Built to scale"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-4xl font-semibold",
							children: "Commerce infrastructure without losing the family mission."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4",
						children: [
							[
								ShieldCheck,
								"Controls",
								"Parent approvals, frozen access, profiles"
							],
							[
								Gift,
								"Savings",
								"Vault goals and matching"
							],
							[
								ShoppingBag,
								"Store",
								"Curated catalog, basket, orders"
							],
							[
								Megaphone,
								"Growth",
								"Campaigns, referrals, promotions"
							]
						].map(([Icon, title, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6 text-accent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-display text-xl font-semibold",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-center gap-2 text-xs text-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }), " Included"]
							})
						] }, title))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "px-5 py-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 text-sm text-muted sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "PillarPath" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Family finance + commerce platform" })]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
