import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatUnits(amount) {
	return new Intl.NumberFormat("en-US").format(amount);
}
function formatWhen(iso) {
	const d = new Date(iso);
	const now = /* @__PURE__ */ new Date();
	const sameDay = d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
	const time = d.toLocaleTimeString("en-US", {
		hour: "numeric",
		minute: "2-digit"
	});
	if (sameDay) return `Today · ${time}`;
	return d.toLocaleDateString("en-US", {
		month: "short",
		day: "numeric"
	}) + " · " + time;
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium select-none outline-none focus-visible:ring-2 focus-visible:ring-accent/35 disabled:pointer-events-none disabled:opacity-45 transition-[scale,background-color,color,opacity,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-foreground shadow-[var(--shadow-border)] hover:bg-accent/92",
			secondary: "bg-surface text-ink shadow-[var(--shadow-border)] hover:bg-surface-2",
			outline: "bg-transparent text-ink shadow-[var(--shadow-border)] hover:bg-surface",
			ghost: "bg-transparent text-ink hover:bg-surface-2",
			danger: "bg-danger text-danger-foreground hover:bg-danger/92",
			success: "bg-success text-success-foreground hover:bg-success/92",
			vault: "bg-vault text-vault-foreground hover:bg-vault/92"
		},
		size: {
			default: "h-11 rounded-md px-4 text-sm",
			sm: "h-9 rounded-sm px-3 text-sm",
			lg: "h-12 rounded-md px-5 text-sm",
			icon: "size-11 rounded-md",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { uid as a, formatWhen as i, cn as n, formatUnits as r, Button as t };
