import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-CWgwa1e8.mjs";
import { t as authMiddleware } from "./middleware-B7qn5WXd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pillarpath-server-DEy06CZU.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var DEFAULT_CAMPAIGNS = [{
	name: "Welcome sequence",
	channel: "Email",
	budget: 0
}, {
	name: "Back-to-school social",
	channel: "Social",
	budget: 5e4
}];
async function ensureUserSeed(userId) {
	const sql = await getSql();
	await sql`
    insert into profiles (user_id, display_name)
    values (${userId}, ${((await sql`select name from "user" where id = ${userId} limit 1`)[0]?.name ?? "").trim() || "PillarPath Parent"})
    on conflict (user_id) do nothing
  `;
	if (((await sql`select count(*)::int as count from children where user_id = ${userId}`)[0]?.count ?? 0) === 0) await sql`
      insert into children (user_id, name, age, avatar, units, vault_units)
      values (${userId}, 'Alex', 10, 'star', 42, 25)
    `;
	if (((await sql`select count(*)::int as count from marketing_campaigns where user_id = ${userId}`)[0]?.count ?? 0) === 0) for (const campaign of DEFAULT_CAMPAIGNS) await sql`
        insert into marketing_campaigns (user_id, name, channel, status, budget_cents)
        values (${userId}, ${campaign.name}, ${campaign.channel}, 'draft', ${campaign.budget})
      `;
	await sql`
    insert into referrals (user_id, code)
    values (${userId}, ${"PILLAR-" + userId.slice(0, 6).toUpperCase()})
    on conflict (code) do nothing
  `;
}
var getPillarPathData_createServerFn_handler = createServerRpc({
	id: "bfdd6fbb8f8a742699932b57f4217e67c3549a76556158bd443bd338793d36e6",
	name: "getPillarPathData",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => getPillarPathData.__executeServer(opts));
var getPillarPathData = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getPillarPathData_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureUserSeed(context.userId);
	const [profiles, children, products, cartItems, orders, campaigns, referral, fulfillments] = await Promise.all([
		sql`select display_name, phone, marketing_opt_in, currency, studio_plus from profiles where user_id = ${context.userId}`,
		sql`select id, name, age, avatar, units, vault_units, frozen from children where user_id = ${context.userId} order by id`,
		sql`select id, name, description, category, unit_price, retail_price_cents, supplier_name, supplier_sku, inventory from store_products where active = true order by category, name`,
		sql`select ci.product_id, ci.quantity from cart_items ci join carts c on c.id = ci.cart_id where c.user_id = ${context.userId} and c.status = 'open'`,
		sql`select id, status, total_cents, created_at, payment_provider, payment_reference from orders where user_id = ${context.userId} order by id desc limit 20`,
		sql`select id, name, channel, status, budget_cents, clicks, conversions from marketing_campaigns where user_id = ${context.userId} order by id desc`,
		sql`select code, reward_cents, referrals from referrals where user_id = ${context.userId} limit 1`,
		sql`select id, order_id, supplier_name, status, tracking_number from fulfillments where order_id in (select id from orders where user_id = ${context.userId}) order by id desc limit 30`
	]);
	return {
		profile: profiles[0] ?? {
			display_name: "PillarPath Parent",
			phone: null,
			marketing_opt_in: false,
			currency: "USD",
			studio_plus: false
		},
		children,
		products,
		cart: cartItems.map((item) => ({
			productId: item.product_id,
			quantity: item.quantity
		})),
		orders,
		campaigns,
		referral: referral[0] ?? null,
		fulfillments
	};
});
var saveProfile_createServerFn_handler = createServerRpc({
	id: "ff330610e1e6d7fd67f7d8bee81db913cc2397aeb3a4837703240076f8d17013",
	name: "saveProfile",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => saveProfile.__executeServer(opts));
var saveProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveProfile_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      insert into profiles (user_id, display_name, phone, marketing_opt_in, updated_at)
      values (${context.userId}, ${data.displayName.trim() || "PillarPath Parent"}, ${data.phone.trim() || null}, ${data.marketingOptIn}, now())
      on conflict (user_id) do update set display_name = excluded.display_name, phone = excluded.phone, marketing_opt_in = excluded.marketing_opt_in, updated_at = now()
    `;
	return { ok: true };
});
var createChild_createServerFn_handler = createServerRpc({
	id: "bd754c365a6d11db07cd84eab7cb3729665190d9696fde13b7d44a77e6ff5aff",
	name: "createChild",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => createChild.__executeServer(opts));
var createChild = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createChild_createServerFn_handler, async ({ context, data }) => {
	return { id: (await (await getSql())`insert into children (user_id, name, age, avatar) values (${context.userId}, ${data.name.trim()}, ${data.age}, ${data.avatar}) returning id`)[0]?.id };
});
async function getOrCreateCart(userId) {
	const sql = await getSql();
	const existing = await sql`select id from carts where user_id = ${userId} and status = 'open' limit 1`;
	if (existing[0]) return existing[0].id;
	return (await sql`insert into carts (user_id) values (${userId}) returning id`)[0].id;
}
var addToCart_createServerFn_handler = createServerRpc({
	id: "08603fb9ba5f7898ffd7ba8ea782168778f21397bc6a52e4e3604343ff66d9ae",
	name: "addToCart",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => addToCart.__executeServer(opts));
var addToCart = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(addToCart_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const cartId = await getOrCreateCart(context.userId);
	await sql`
      insert into cart_items (cart_id, product_id, quantity)
      values (${cartId}, ${data.productId}, ${Math.max(1, Math.floor(data.quantity))})
      on conflict (cart_id, product_id) do update set quantity = cart_items.quantity + excluded.quantity
    `;
	await sql`update carts set updated_at = now() where id = ${cartId}`;
	return { ok: true };
});
var setCartQuantity_createServerFn_handler = createServerRpc({
	id: "5452d353fdc52aaa533022f2491bcf05dfd0406e741264c2b6d0d977d2f7bf74",
	name: "setCartQuantity",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => setCartQuantity.__executeServer(opts));
var setCartQuantity = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setCartQuantity_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (data.quantity <= 0) await sql`delete from cart_items ci using carts c where ci.cart_id = c.id and c.user_id = ${context.userId} and c.status = 'open' and ci.product_id = ${data.productId}`;
	else await sql`update cart_items ci set quantity = ${Math.floor(data.quantity)} from carts c where ci.cart_id = c.id and c.user_id = ${context.userId} and c.status = 'open' and ci.product_id = ${data.productId}`;
	return { ok: true };
});
var createCheckout_createServerFn_handler = createServerRpc({
	id: "bb6640d77be45bc9648bc20006430c63a99ce2779b63d308a63f9243e2231c95",
	name: "createCheckout",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => createCheckout.__executeServer(opts));
var createCheckout = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createCheckout_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const items = await sql`
      select ci.product_id, ci.quantity, p.name, p.retail_price_cents, p.supplier_name, p.supplier_sku
      from cart_items ci join carts c on c.id = ci.cart_id join store_products p on p.id = ci.product_id
      where c.user_id = ${context.userId} and c.status = 'open' and p.active = true
    `;
	if (!items.length) throw new Error("Your basket is empty.");
	const subtotal = items.reduce((sum, item) => sum + item.retail_price_cents * item.quantity, 0);
	const shipping = subtotal >= 7500 ? 0 : 799;
	const total = subtotal + shipping;
	const addressJson = JSON.stringify(data.shippingAddress);
	const orderId = (await sql`
      insert into orders (user_id, status, payment_provider, subtotal_cents, shipping_cents, total_cents, shipping_name, shipping_email, shipping_address)
      values (${context.userId}, 'pending_payment', 'stripe', ${subtotal}, ${shipping}, ${total}, ${data.shippingName}, ${data.email}, ${addressJson}::jsonb)
      returning id
    `)[0].id;
	for (const item of items) {
		await sql`
        insert into order_items (order_id, product_id, product_name, supplier_name, supplier_sku, quantity, unit_price_cents)
        values (${orderId}, ${item.product_id}, ${item.name}, ${item.supplier_name}, ${item.supplier_sku}, ${item.quantity}, ${item.retail_price_cents})
      `;
		await sql`insert into fulfillments (order_id, supplier_name) values (${orderId}, ${item.supplier_name})`;
	}
	const stripeKey = process.env.STRIPE_SECRET_KEY?.trim();
	if (!stripeKey) {
		await sql`update orders set status = 'preview_payment' where id = ${orderId}`;
		await sql`update carts set status = 'checked_out', updated_at = now() where user_id = ${context.userId} and status = 'open'`;
		return {
			mode: "preview",
			orderId,
			checkoutUrl: null
		};
	}
	const baseUrl = process.env.BETTER_AUTH_URL?.trim() || "http://localhost:8080";
	const form = new URLSearchParams();
	form.set("mode", "payment");
	form.set("success_url", `${baseUrl}/checkout/success?order=${orderId}`);
	form.set("cancel_url", `${baseUrl}/?checkout=cancelled`);
	form.set("customer_email", data.email);
	form.set("shipping_address_collection[allowed_countries][0]", "US");
	if (shipping > 0) form.set("shipping_options[0][shipping_rate_data][display_name]", "Standard shipping");
	if (shipping > 0) form.set("shipping_options[0][shipping_rate_data][type]", "fixed_amount");
	if (shipping > 0) form.set("shipping_options[0][shipping_rate_data][fixed_amount][amount]", String(shipping));
	if (shipping > 0) form.set("shipping_options[0][shipping_rate_data][fixed_amount][currency]", "usd");
	items.forEach((item, index) => {
		form.set(`line_items[${index}][quantity]`, String(item.quantity));
		form.set(`line_items[${index}][price_data][currency]`, "usd");
		form.set(`line_items[${index}][price_data][unit_amount]`, String(item.retail_price_cents));
		form.set(`line_items[${index}][price_data][product_data][name]`, item.name);
	});
	form.set("metadata[order_id]", String(orderId));
	const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${stripeKey}`,
			"Content-Type": "application/x-www-form-urlencoded"
		},
		body: form
	});
	if (!response.ok) {
		const message = await response.text();
		throw new Error(`Payment setup failed: ${message.slice(0, 220)}`);
	}
	const session = await response.json();
	await sql`update orders set payment_reference = ${session.id} where id = ${orderId}`;
	return {
		mode: "stripe",
		orderId,
		checkoutUrl: session.url
	};
});
var createCampaign_createServerFn_handler = createServerRpc({
	id: "186c619e06bcc3ea0084cf52bde4f48c88356030f85c17462a1dc966387144be",
	name: "createCampaign",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => createCampaign.__executeServer(opts));
var createCampaign = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createCampaign_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`insert into marketing_campaigns (user_id, name, channel, budget_cents) values (${context.userId}, ${data.name.trim()}, ${data.channel}, ${Math.max(0, Math.floor(data.budgetCents))})`;
	return { ok: true };
});
var createPromoCode_createServerFn_handler = createServerRpc({
	id: "6423f6dbc97b2dc06a62a50cbecc9ec1848190987bed699555eea129beb1287f",
	name: "createPromoCode",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => createPromoCode.__executeServer(opts));
var createPromoCode = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createPromoCode_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`insert into promo_codes (user_id, code, discount_percent) values (${context.userId}, ${data.code.trim().toUpperCase()}, ${Math.min(90, Math.max(1, Math.floor(data.discountPercent)))}) on conflict (user_id, code) do update set discount_percent = excluded.discount_percent, active = true`;
	return { ok: true };
});
var createStudioCheckout_createServerFn_handler = createServerRpc({
	id: "073a86d8786e4bcf126ee6ec7fee20d7f41efe3c58eb522532bfe41ff5c60a5d",
	name: "createStudioCheckout",
	filename: "src/lib/pillarpath-server.ts"
}, (opts) => createStudioCheckout.__executeServer(opts));
var createStudioCheckout = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createStudioCheckout_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	if ((await sql`select studio_plus from profiles where user_id = ${context.userId}`)[0]?.studio_plus) return {
		mode: "active",
		checkoutUrl: null
	};
	const price = Math.max(99, Number(process.env.STUDIO_PLUS_PRICE_CENTS ?? 499));
	const stripeKey = process.env.STRIPE_SECRET_KEY?.trim();
	if (!stripeKey) {
		await sql`update profiles set studio_plus = true, updated_at = now() where user_id = ${context.userId}`;
		return {
			mode: "preview",
			checkoutUrl: null
		};
	}
	const baseUrl = process.env.BETTER_AUTH_URL?.trim() || "http://localhost:8080";
	const form = new URLSearchParams();
	form.set("mode", "payment");
	form.set("success_url", `${baseUrl}/?studio=activated`);
	form.set("cancel_url", `${baseUrl}/?studio=cancelled`);
	form.set("line_items[0][quantity]", "1");
	form.set("line_items[0][price_data][currency]", "usd");
	form.set("line_items[0][price_data][unit_amount]", String(price));
	form.set("line_items[0][price_data][product_data][name]", "PillarPath Creative Studio Plus");
	form.set("line_items[0][price_data][product_data][description]", "Advanced creative, printable and skill-game features");
	form.set("metadata[studio_plus]", "1");
	form.set("metadata[user_id]", context.userId);
	const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${stripeKey}`,
			"Content-Type": "application/x-www-form-urlencoded"
		},
		body: form
	});
	if (!response.ok) throw new Error(`Studio checkout setup failed: ${(await response.text()).slice(0, 220)}`);
	return {
		mode: "stripe",
		checkoutUrl: (await response.json()).url
	};
});
//#endregion
export { addToCart_createServerFn_handler, createCampaign_createServerFn_handler, createCheckout_createServerFn_handler, createChild_createServerFn_handler, createPromoCode_createServerFn_handler, createStudioCheckout_createServerFn_handler, getPillarPathData_createServerFn_handler, saveProfile_createServerFn_handler, setCartQuantity_createServerFn_handler };
