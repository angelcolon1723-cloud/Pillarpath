import { S as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-DqTpIDAm.mjs";
import { T as PackageCheck, W as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as Route$3 } from "./router-B1c1sOud.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/success-GSzyzSGI.js
var import_jsx_runtime = require_jsx_runtime();
function CheckoutSuccess() {
	const search = Route$3.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-bg px-5 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "w-full max-w-md rounded-[2rem] border border-border bg-surface p-8 text-center shadow-[var(--shadow-border-hover)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-5 grid size-16 place-items-center rounded-full bg-accent-soft text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-8" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold",
					children: "Order received"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"Your PillarPath order ",
						search.order ? `#${search.order}` : "",
						" has been created. Payment confirmation and supplier fulfillment will update the order status."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-6 flex items-center justify-center gap-2 text-sm text-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageCheck, { className: "size-4" }), " Fulfillment pipeline ready"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						children: "Return to PillarPath"
					})
				})
			]
		})
	});
}
//#endregion
export { CheckoutSuccess as component };
