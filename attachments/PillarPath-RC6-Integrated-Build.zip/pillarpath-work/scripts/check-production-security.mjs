import fs from "node:fs";

const checks = [
  {
    name: "No demo child/balance seeding",
    file: "src/lib/pillarpath-server.ts",
    forbidden: ["'Alex', 10, 'star', 42, 25", '"Alex", 10, "star", 42, 25'],
  },
  {
    name: "Corporate campaign mutation is role-gated",
    file: "src/lib/pillarpath-server.ts",
    required: ["requireCorporateRole(context.userId, [\"executive\", \"commerce_admin\"])", "corporate.campaign_created"],
  },
  {
    name: "Customer navigation excludes corporate partner surfaces",
    file: "src/components/pillarpath-app.tsx",
    forbidden: ['["partners",', '["marketing",', '["fulfillment",'],
  },
  {
    name: "Production checkout fails closed without Stripe",
    file: "src/lib/pillarpath-server.ts",
    required: ["!stripeKey && !isWorkspacePreview()", "Payments are not configured for production yet."],
  },
  {
    name: "Financial client persistence is limited to UI/drafts",
    file: "src/store/ledger.ts",
    required: ["partialize: (state) => ({ role: state.role, screen: state.screen, selectedProductId: state.selectedProductId, drawings: state.drawings })"],
  },
  {
    name: "Future Units cash trading remains disabled",
    file: "src/lib/pillarpath-server.ts",
    required: ["Closed-loop family reward reserve", "funding_mode", "'active', 'units'"],
  },
];

let failed = false;
for (const check of checks) {
  const text = fs.readFileSync(check.file, "utf8");
  const missing = (check.required ?? []).filter((needle) => !text.includes(needle));
  const foundForbidden = (check.forbidden ?? []).filter((needle) => text.includes(needle));
  if (missing.length || foundForbidden.length) {
    failed = true;
    console.error(`FAIL: ${check.name}`);
    if (missing.length) console.error(`  missing: ${missing.join(" | ")}`);
    if (foundForbidden.length) console.error(`  forbidden: ${foundForbidden.join(" | ")}`);
  } else {
    console.log(`PASS: ${check.name}`);
  }
}
if (failed) process.exit(1);
console.log("Production security source checks passed.");
