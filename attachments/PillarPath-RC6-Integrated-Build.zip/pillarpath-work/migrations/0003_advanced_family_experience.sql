-- Advanced family experience + corporate isolation.
-- Customer-facing screens never receive corporate partner/marketing data.

create table if not exists corporate_memberships (
  user_id text primary key references "user"("id") on delete cascade,
  role text not null check (role in ('executive','finance','support','safety','school_admin','commerce_admin','system_admin')),
  active boolean not null default true,
  granted_at timestamptz not null default now(),
  granted_by text
);

create table if not exists audit_events (
  id bigserial primary key,
  user_id text references "user"("id") on delete set null,
  actor_user_id text references "user"("id") on delete set null,
  action text not null,
  resource_type text not null,
  resource_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_events_actor_idx on audit_events(actor_user_id, created_at desc);
create index if not exists audit_events_resource_idx on audit_events(resource_type, resource_id, created_at desc);

create table if not exists future_unit_plans (
  id text primary key,
  user_id text not null references "user"("id") on delete cascade,
  child_id bigint references children(id) on delete cascade,
  plan_code text not null check (plan_code in ('sprout','builder','pathfinder','creator')),
  committed_units integer not null check (committed_units > 0),
  bonus_units integer not null default 0 check (bonus_units >= 0),
  maturity_at timestamptz not null,
  status text not null default 'active' check (status in ('active','matured','cancelled','simulation')),
  funding_mode text not null default 'units' check (funding_mode in ('units','simulation')),
  created_at timestamptz not null default now()
);
create index if not exists future_unit_plans_user_idx on future_unit_plans(user_id, created_at desc);

create table if not exists studio_projects (
  id text primary key,
  user_id text not null references "user"("id") on delete cascade,
  child_id bigint references children(id) on delete set null,
  title text not null,
  category text not null check (category in ('drawing','coloring','craft','story','shirt','music','game','puzzle')),
  age_band text not null check (age_band in ('sprout','explorer','pathfinder','creator')),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists studio_projects_user_idx on studio_projects(user_id, updated_at desc);

create table if not exists learning_progress (
  id bigserial primary key,
  user_id text not null references "user"("id") on delete cascade,
  child_id bigint references children(id) on delete cascade,
  activity_key text not null,
  age_band text not null,
  level text not null,
  score integer not null default 0,
  completions integer not null default 0,
  last_completed_at timestamptz,
  unique(user_id, child_id, activity_key)
);
create index if not exists learning_progress_user_idx on learning_progress(user_id, child_id);

-- Safe defaults: future-unit "market" remains a closed-loop family reward feature.
-- Cash-funded trading/investment is intentionally disabled until legal/compliance approval.

alter table profiles add column if not exists parent_consent_verified boolean not null default false;
alter table children add column if not exists vault_goal text not null default 'Future Goal';
alter table children add column if not exists match_rate numeric(4,3) not null default 0.5 check (match_rate >= 0 and match_rate <= 1);
alter table children add column if not exists vault_maturity_at timestamptz;

create table if not exists unit_transactions (
  id text primary key,
  user_id text not null references "user"("id") on delete cascade,
  child_id bigint references children(id) on delete cascade,
  kind text not null check (kind in ('credit','debit','transfer','event','cashout')),
  amount integer not null check (amount >= 0),
  note text not null,
  idempotency_key text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(user_id, idempotency_key)
);
create index if not exists unit_transactions_user_idx on unit_transactions(user_id, child_id, created_at desc);

create table if not exists child_purchase_requests (
  id text primary key,
  user_id text not null references "user"("id") on delete cascade,
  child_id bigint not null references children(id) on delete cascade,
  product_id text not null references store_products(id),
  requested_units integer not null check (requested_units > 0),
  status text not null default 'pending' check (status in ('pending','approved','denied')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);
create index if not exists child_purchase_requests_user_idx on child_purchase_requests(user_id, child_id, status);

create table if not exists child_chore_requests (
  id text primary key,
  user_id text not null references "user"("id") on delete cascade,
  child_id bigint not null references children(id) on delete cascade,
  chore_id text not null,
  amount integer not null check (amount > 0),
  status text not null default 'pending' check (status in ('pending','approved','denied')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);
create index if not exists child_chore_requests_user_idx on child_chore_requests(user_id, child_id, status);
alter table children add column if not exists future_reserved_units integer not null default 0 check (future_reserved_units >= 0);

create table if not exists child_access_grants (
  id text primary key,
  user_id text not null references "user"("id") on delete cascade,
  child_id bigint not null references children(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  revoked_at timestamptz
);
create index if not exists child_access_grants_user_idx on child_access_grants(user_id, child_id, expires_at);
