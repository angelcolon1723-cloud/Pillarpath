# PillarPath Advanced Production Security Review

## Customer boundary

- Customer parent navigation contains family, store, orders, Future Units, and account settings only.
- Affiliate/marketing/dropship partner catalogs are not returned by the customer data loader and are not rendered in customer navigation.
- Corporate operations require an authenticated session plus an active `corporate_memberships` role on the server.
- Partner credentials remain server-only environment variables.

## Identity and authorization

- Every per-user server function uses `authMiddleware` and the verified `context.userId`.
- Child IDs supplied by the client are checked against the authenticated parent's children before mutation.
- Corporate mutations require a corporate role; UI hiding is not the security boundary.
- Cross-site requests continue through the existing same-site middleware.

## Pillar Units ledger

- Financial mutations are server-authoritative.
- Client persistence is limited to navigation state and creative drafts.
- Unit mutations use database updates plus immutable transaction records.
- Idempotency keys protect loads, awards, approvals, vault transfers, and maturity payouts.
- Debits require a sufficient server-side balance.
- Future Units are closed-loop, non-transferable reward reserves; no securities, resale, yield, or cash-funded trading is enabled.

## Payments and fulfillment

- Production checkout fails closed when Stripe is not configured.
- Orders are not sent to supplier fulfillment before payment confirmation.
- Supplier fulfillment remains a corporate/backend concern.
- Stripe webhooks must be the authoritative source for paid status before a production fulfillment adapter is enabled.

## Child safety and privacy

- No synthetic child account or synthetic Unit balance is created during real-account bootstrap.
- Child profiles are owned by the authenticated parent account.
- Freeze state is server-side.
- Creative and learning records are scoped to the authenticated parent account.
- Before public launch, PillarPath still needs formal privacy/children's-privacy review, retention/deletion policy, consent verification, moderation policy, and school/teacher legal review.

## Launch gate

This release is a hardened candidate, not a claim that regulatory/legal requirements are complete. Real production launch still requires:

1. production database and backups;
2. production authentication configuration;
3. Stripe production account + signed webhooks;
4. fulfillment provider contract and paid-order webhook flow;
5. legal/privacy/children's privacy approval;
6. security testing and authorization testing;
7. Apple/Google release credentials and privacy declarations;
8. monitoring, incident response, rollback, and disaster recovery.
