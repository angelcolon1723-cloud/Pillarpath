# PillarPath production connections

The app is structured for a real deployment. No secrets are stored in the repository.

## Required production services

- Better Auth + Postgres: enabled in `.grok/app-env.json` and migrations. Supabase Postgres can be used by supplying its production `DATABASE_URL`; the application keeps database access server-side.
- Stripe Checkout: set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` as server secrets. Checkout is created server-side; raw card data never touches PillarPath. Stripe Checkout supports hosted one-time payments and shipping collection. See the official Stripe Checkout API documentation.
- Dropshipping supplier: set `DROPSHIP_API_URL` and `DROPSHIP_API_KEY` for a supplier endpoint that accepts the normalized order payload from `src/lib/dropship.ts`.
- Public app URL: set `BETTER_AUTH_URL` so payment redirects return to the deployed app.

## Commerce flow

1. Parent signs in.
2. Parent or child adds curated catalog items to the basket.
3. Child cannot complete checkout; parent must review.
4. Parent enters delivery details.
5. With Stripe configured, PillarPath creates a hosted Checkout Session and redirects to Stripe.
6. Stripe webhook marks the order paid.
7. The generic supplier adapter submits the paid order if a dropship provider is configured; otherwise fulfillment remains queued for manual/provider sync.
8. Orders and fulfillment statuses are visible in the parent workspace.

## Marketing flow

Marketing includes campaign records, budgets, promo codes, referral codes, and basic conversion counters. The data model is ready for a future email/ads provider connector without exposing provider credentials to the browser.

## Important launch work

Before taking real customer payments, connect Stripe, configure the webhook endpoint `/api/webhooks/stripe`, connect a supplier API, configure taxes/shipping policies, add legal/privacy/terms pages, and run end-to-end payment and fulfillment tests in Stripe test mode.

## Ecosystem connector catalog

The parent Partner Hub now organizes integration targets across commerce, dropshipping, creative fulfillment, and marketing/affiliate operations. Current targets include Stripe, Shopify, Printful, Printify, CJdropshipping, Spocket, impact.com, Awin, Klaviyo, Mailchimp, Meta, Google Ads, and TikTok for Business.

These are connector targets, not assertions of an existing commercial affiliation. Each provider requires its own approved account, credentials, terms, and API implementation before it can be marked connected. Secrets remain server-side.

## Creative Studio Plus

Parent-controlled Studio Plus is priced at $4.99 by default and can be overridden with `STUDIO_PLUS_PRICE_CENTS`. Stripe Checkout activates the entitlement through the existing signed webhook. Without Stripe configured, development/preview mode activates the entitlement locally.

Studio Plus includes printable coloring projects, digital arts and crafts, a custom T-shirt designer, and short cognitive/movement practice games. The progress feature is explicitly a skills tracker and not an IQ test or clinical assessment.

## PillarPath Unit Market

The parent Future Units Market is a closed-loop family reward reserve. Parents can lock existing Pillar Units for a defined term and receive a predefined Unit bonus at maturity. It does not create shares, securities, a cash market, resale rights, yield claims, or tradable Units. Cash-funded investment/trading is disabled until separate legal, financial-regulatory, and payment approvals are completed.
