# PillarPath RC6 — Phone-only Android build

This project includes `codemagic.yaml` at the repository root.

1. Upload/commit this project to the private `Pillarpath-mobile` repository.
2. In Codemagic, connect that private GitHub repository.
3. Use the workflow named **PillarPath RC6 Android Debug APK**.
4. Start the build.
5. When the build finishes, download the `app-debug.apk` artifact to the Android phone.

The workflow is intentionally a debug/staging build. Production signing keys, Stripe secrets, supplier credentials, and other private values are not stored in this project.
