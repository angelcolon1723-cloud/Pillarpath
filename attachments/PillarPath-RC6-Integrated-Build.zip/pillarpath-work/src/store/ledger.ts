import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { CHORES, PRODUCTS, type Product } from "@/lib/products";
import { uid } from "@/lib/utils";
import {
  awardChildUnits,
  getFamilyLedger,
  loadChildUnits,
  lockChildUnits,
  requestChildChore,
  requestChildPurchase,
  setChildMatchRate,
  resolveChildChore,
  resolveChildPurchase,
  toggleChildFreeze,
  verifyParentConsent,
} from "@/lib/pillarpath-server";

export type Role = "parent" | "child";

export type Screen =
  | "home"
  | "load"
  | "award"
  | "vault"
  | "history"
  | "market"
  | "confirm"
  | "studio"
  | "learn";

export type HistoryKind =
  | "credit"
  | "debit"
  | "transfer"
  | "event"
  | "cashout";

export type HistoryEvent = {
  id: string;
  kind: HistoryKind;
  amount: number;
  note: string;
  at: string;
};

export type PendingPurchase = {
  id: string;
  productId: string;
  name: string;
  price: number;
  icon: Product["icon"];
};

export type PendingChore = {
  id: string;
  choreId: string;
  name: string;
  amount: number;
};

export type SavedDrawing = {
  id: string;
  dataUrl: string;
  at: string;
};

export type MatchRate = 0 | 0.5 | 1;

const DAY_MS = 86_400_000;
const MATURITY_DAYS = 28;
const VAULT_TARGET = 70;
const STORAGE_KEY = "kiddo-ledger-v2";

function nowIso() {
  return new Date().toISOString();
}

function openingState() {
  return {
    consent: false,
    frozen: false,
    childName: "Your child",
    childAge: 10,
    balance: 0,
    vault: 0,
    vaultTarget: VAULT_TARGET,
    vaultGoal: "Future Goal",
    vaultOpenedAt: Date.now(),
    demoDaysAdvanced: 0,
    matchRate: 0.5 as MatchRate,
    pendingPurchases: [] as PendingPurchase[],
    pendingChores: [] as PendingChore[],
    completedChoreIds: [] as string[],
    history: [] as HistoryEvent[],
    drawings: [] as SavedDrawing[],
  };
}

type LedgerData = ReturnType<typeof openingState>;

type LedgerState = LedgerData & {
  role: Role;
  screen: Screen;
  selectedProductId: string | null;
  childGrant: string | null;
  setChildGrant: (token: string | null) => void;
  setRole: (role: Role) => void;
  syncFromServer: () => Promise<void>;
  setScreen: (screen: Screen) => void;
  selectProduct: (id: string) => void;
  verifyConsent: () => string | null;
  toggleFreeze: () => string;
  loadUnits: (amount: number) => string | null;
  awardUnits: (amount: number, reason: string) => string | null;
  requestPurchase: (productId: string) => string | null;
  approvePurchase: (id: string) => string | null;
  denyPurchase: (id: string) => string | null;
  completeChore: (choreId: string) => string | null;
  approveChore: (id: string) => string | null;
  denyChore: (id: string) => string | null;
  lockUnits: (amount: number) => string | null;
  setMatchRate: (rate: MatchRate) => string;
  advanceVaultDays: (days: number) => string;
  releaseVault: () => string | null;
  saveDrawing: (dataUrl: string) => string;
  clearDrawings: () => void;
  resetDemo: () => void;
  daysRemaining: () => number;
  pendingCount: () => number;
};

function record(
  history: HistoryEvent[],
  kind: HistoryKind,
  amount: number,
  note: string,
): HistoryEvent[] {
  return [
    { id: uid("evt"), kind, amount, note, at: nowIso() },
    ...history,
  ].slice(0, 40);
}

export const useLedger = create<LedgerState>()(
  persist(
    (set, get) => ({
      ...openingState(),
      role: "parent",
      screen: "home",
      selectedProductId: null,
      childGrant: null,
      setChildGrant: (token) => set({ childGrant: token }),
      setRole: (role) => {
        const { consent, frozen, childGrant } = get();
        if (role === "child" && (!consent || !childGrant)) {
          set({ role: "parent", screen: "home" });
          return;
        }
        set({
          role,
          screen: "home",
          selectedProductId: null,
        });
        if (role === "child" && frozen) {
          /* still allow viewing */
        }
      },
      setScreen: (screen) => set({ screen }),
      selectProduct: (id) =>
        set({ selectedProductId: id, screen: "confirm" }),
      syncFromServer: async () => {
        try {
          const remote = await getFamilyLedger();
          const child = remote.child;
          if (!child) {
            set({ consent: remote.consent, childName: "Your child", balance: 0, vault: 0, pendingPurchases: [], pendingChores: [], history: [] });
            return;
          }
          const maturity = child.vault_maturity_at ? new Date(child.vault_maturity_at).getTime() : Date.now();
          const remaining = Math.max(0, Math.ceil((maturity - Date.now()) / DAY_MS));
          set({
            consent: remote.consent,
            frozen: child.frozen,
            childName: child.name,
            childAge: child.age ?? 10,
            balance: child.units,
            vault: child.vault_units,
            vaultGoal: child.vault_goal,
            matchRate: Number(child.match_rate) as MatchRate,
            vaultOpenedAt: Date.now() - Math.max(0, MATURITY_DAYS - remaining) * DAY_MS,
            pendingPurchases: remote.pendingPurchases.map((p) => { const product = PRODUCTS.find((x) => x.id === p.product_id); return { id: p.id, productId: p.product_id, name: product?.name ?? p.product_id, price: p.requested_units, icon: product?.icon ?? "blocks" }; }),
            pendingChores: remote.pendingChores.map((c) => { const chore = CHORES.find((x) => x.id === c.chore_id); return { id: c.id, choreId: c.chore_id, name: chore?.name ?? c.chore_id, amount: c.amount }; }),
            completedChoreIds: remote.completedChoreIds,
            history: remote.history.map((h) => ({ id: h.id, kind: h.kind as HistoryKind, amount: h.amount, note: h.note, at: h.created_at })),
          });
        } catch {
          // Staging can render while the server connector is warming up.
        }
      },
      verifyConsent: () => {
        if (get().consent) return "Consent is already verified";
        void verifyParentConsent().then(() => get().syncFromServer());
        set({ consent: true });
        return null;
      },
      toggleFreeze: () => {
        const next = !get().frozen;
        void toggleChildFreeze({ data: {} }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        set({ frozen: next });
        return next ? "Child access is frozen" : "Child access is restored";
      },
      loadUnits: (amount) => {
        if (!get().consent) return "Verify parental consent first";
        const amt = Math.max(1, Math.floor(amount));
        const key = uid("load");
        void loadChildUnits({ data: { amount: amt, idempotencyKey: key } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        set((s) => ({ balance: s.balance + amt, screen: "home" }));
        return null;
      },
      awardUnits: (amount, reason) => {
        if (!get().consent) return "Verify parental consent first";
        const amt = Math.max(1, Math.floor(amount));
        const key = uid("award");
        void awardChildUnits({ data: { amount: amt, reason, idempotencyKey: key } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        set((s) => ({ balance: s.balance + amt, screen: "home" }));
        return null;
      },
      requestPurchase: (productId) => {
        const s = get();
        if (s.frozen) return "Access is frozen by your parent";
        const product = PRODUCTS.find((p) => p.id === productId);
        if (!product) return "Item not found";
        void requestChildPurchase({ data: { productId, childToken: get().childGrant ?? "" } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        set({ selectedProductId: null, screen: "home" });
        return null;
      },
      approvePurchase: (id) => {
        void resolveChildPurchase({ data: { requestId: id, approve: true, idempotencyKey: uid("approve-buy") } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        return null;
      },
      denyPurchase: (id) => {
        void resolveChildPurchase({ data: { requestId: id, approve: false, idempotencyKey: uid("deny-buy") } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        return null;
      },
      completeChore: (choreId) => {
        const chore = CHORES.find((c) => c.id === choreId);
        if (!chore) return "Goal not found";
        if (get().frozen) return "Access is frozen by your parent";
        void requestChildChore({ data: { choreId, amount: chore.amount, childToken: get().childGrant ?? "" } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        return null;
      },
      approveChore: (id) => {
        void resolveChildChore({ data: { requestId: id, approve: true, idempotencyKey: uid("approve-chore") } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        return null;
      },
      denyChore: (id) => {
        void resolveChildChore({ data: { requestId: id, approve: false, idempotencyKey: uid("deny-chore") } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        return null;
      },
      lockUnits: (amount) => {
        const s = get();
        if (s.frozen) return "Access is frozen by your parent";
        const amt = Math.max(1, Math.floor(amount));
        if (amt > s.balance) return "Not enough Units";
        void lockChildUnits({ data: { amount: amt, idempotencyKey: uid("vault"), childToken: get().childGrant ?? "" } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        set((state) => ({ balance: Math.max(0, state.balance - amt), vault: state.vault + amt + Math.floor(amt * state.matchRate), screen: "home" }));
        return null;
      },
      setMatchRate: (rate) => {
        void setChildMatchRate({ data: { rate } }).then(() => get().syncFromServer()).catch(() => get().syncFromServer());
        set({ matchRate: rate });
        return "Matching preference saved";
      },
      advanceVaultDays: (days) => {
        set((s) => ({ demoDaysAdvanced: s.demoDaysAdvanced + days }));
        return `Advanced ${days} days`;
      },
      releaseVault: () => {
        const s = get();
        if (get().daysRemaining() > 0) return "Vault has not matured yet";
        if (s.vault <= 0) return "Vault is empty";
        const amt = s.vault;
        set({
          vault: 0,
          vaultOpenedAt: Date.now(),
          demoDaysAdvanced: 0,
          history: record(
            s.history,
            "cashout",
            amt,
            "Vault matured · cash payout marked for Alex",
          ),
        });
        return null;
      },
      saveDrawing: (dataUrl) => {
        set((s) => ({
          drawings: [
            { id: uid("draw"), dataUrl, at: nowIso() },
            ...s.drawings,
          ].slice(0, 8),
        }));
        return "Design saved";
      },
      clearDrawings: () => set({ drawings: [] }),
      resetDemo: () => {
        const next = openingState();
        set({
          ...next,
          role: "parent",
          screen: "home",
          selectedProductId: null,
        });
      },
      daysRemaining: () => {
        const s = get();
        const elapsed = Math.floor(
          (Date.now() - s.vaultOpenedAt) / DAY_MS + s.demoDaysAdvanced,
        );
        return Math.max(0, MATURITY_DAYS - elapsed);
      },
      pendingCount: () => {
        const s = get();
        return s.pendingPurchases.length + s.pendingChores.length;
      },
    }),
    {
      name: STORAGE_KEY,
      version: 3,
      migrate: () => ({ ...openingState(), role: "parent" as Role, screen: "home" as Screen, selectedProductId: null, childGrant: null, drawings: [] }),
      partialize: (state) => ({ role: state.role, screen: state.screen, selectedProductId: state.selectedProductId, drawings: state.drawings }),
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      skipHydration: true,
      partialize: (state) => ({
        consent: state.consent,
        frozen: state.frozen,
        childName: state.childName,
        childAge: state.childAge,
        balance: state.balance,
        vault: state.vault,
        vaultTarget: state.vaultTarget,
        vaultGoal: state.vaultGoal,
        vaultOpenedAt: state.vaultOpenedAt,
        demoDaysAdvanced: state.demoDaysAdvanced,
        matchRate: state.matchRate,
        pendingPurchases: state.pendingPurchases,
        pendingChores: state.pendingChores,
        completedChoreIds: state.completedChoreIds,
        history: state.history,
        drawings: state.drawings,
      }),
    },
  ),
);

export { MATURITY_DAYS };
