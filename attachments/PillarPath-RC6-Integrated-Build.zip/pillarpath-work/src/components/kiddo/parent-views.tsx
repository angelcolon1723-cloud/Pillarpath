import { useState } from "react";
import {
  ArrowDownToLine,
  Award,
  Check,
  Landmark,
  ShieldCheck,
  Snowflake,
  Sun,
  History as HistoryIcon,
  Ban,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input, FieldLabel, NativeSelect } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { ProductIcon } from "@/components/kiddo/product-icon";
import { AWARD_REASONS } from "@/lib/products";
import { formatUnits, formatWhen } from "@/lib/utils";
import { useLedger, type MatchRate } from "@/store/ledger";

function BackButton() {
  const setScreen = useLedger((s) => s.setScreen);
  return (
    <Button variant="outline" className="w-full" onClick={() => setScreen("home")}>
      Back
    </Button>
  );
}

export function ParentHome() {
  const childName = useLedger((s) => s.childName);
  const consent = useLedger((s) => s.consent);
  const frozen = useLedger((s) => s.frozen);
  const balance = useLedger((s) => s.balance);
  const vault = useLedger((s) => s.vault);
  const vaultTarget = useLedger((s) => s.vaultTarget);
  const vaultGoal = useLedger((s) => s.vaultGoal);
  const pendingPurchases = useLedger((s) => s.pendingPurchases);
  const pendingChores = useLedger((s) => s.pendingChores);
  const reservedUnits = pendingPurchases.reduce((sum, p) => sum + p.price, 0);
  const availableUnits = Math.max(0, balance - reservedUnits);
  const pendingCount = useLedger((s) => s.pendingCount());
  const daysRemaining = useLedger((s) => s.daysRemaining());
  const setScreen = useLedger((s) => s.setScreen);
  const verifyConsent = useLedger((s) => s.verifyConsent);
  const toggleFreeze = useLedger((s) => s.toggleFreeze);
  const approvePurchase = useLedger((s) => s.approvePurchase);
  const denyPurchase = useLedger((s) => s.denyPurchase);
  const approveChore = useLedger((s) => s.approveChore);
  const denyChore = useLedger((s) => s.denyChore);

  const vaultPct = (vault / vaultTarget) * 100;

  return (
    <div className="screen-enter space-y-4">
      <header className="stagger-1 screen-enter">
        <p className="text-sm font-medium text-muted">Parent</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          {childName}'s ledger
        </h1>
        <p className="mt-1 text-sm text-muted">
          Units load in, never cash out — until a vault matures.
        </p>
      </header>

      <Card className="stagger-2 screen-enter space-y-0 p-2">
        <div className="flex items-center justify-between gap-3 rounded-lg px-3 py-3">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-md bg-accent-soft text-accent">
              <ShieldCheck className="size-5" strokeWidth={1.8} />
            </span>
            <div>
              <div className="text-sm font-medium">Parental consent</div>
              <div className="text-xs text-muted">
                {consent ? "Verified" : "Required before loading Units"}
              </div>
            </div>
          </div>
          <Button
            variant={consent ? "secondary" : "default"}
            size="sm"
            disabled={consent}
            onClick={() => {
              const err = verifyConsent();
              if (err) toast.message(err);
              else toast.success("Consent verified");
            }}
          >
            {consent ? "Verified" : "Verify"}
          </Button>
        </div>
        <div className="mx-3 h-px bg-border" />
        <div className="flex items-center justify-between gap-3 rounded-lg px-3 py-3">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-md bg-surface-2 text-ink">
              {frozen ? (
                <Snowflake className="size-5" strokeWidth={1.8} />
              ) : (
                <Sun className="size-5" strokeWidth={1.8} />
              )}
            </span>
            <div>
              <div className="text-sm font-medium">Child access</div>
              <div className="text-xs text-muted">
                {frozen ? "Frozen — spend and chores paused" : "Active"}
              </div>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => toast.message(toggleFreeze())}
          >
            {frozen ? "Unfreeze" : "Freeze"}
          </Button>
        </div>
      </Card>

      <div className="stagger-3 screen-enter overflow-hidden rounded-xl bg-ink p-5 text-bg shadow-[var(--shadow-border)]">
        <p className="text-xs font-medium uppercase tracking-wider text-bg/60">
          Spendable balance
        </p>
        <p className="mt-1 font-display text-5xl font-semibold tracking-tight tabular-nums">
          {formatUnits(balance)}
        </p>
        <p className="mt-1 text-sm text-bg/70">
          Pillar Units · {availableUnits} available to approve or spend
        </p>
      </div>

      <Card className="stagger-4 screen-enter bg-vault p-5 text-vault-foreground">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wider text-vault-foreground/60">
              Savings vault
            </p>
            <p className="mt-1 font-display text-3xl font-semibold tabular-nums">
              {formatUnits(vault)}
            </p>
            <p className="mt-1 text-sm text-vault-foreground/75">
              {vaultGoal} ·{" "}
              {daysRemaining === 0
                ? "Matured"
                : `Matures in ${daysRemaining} days`}
            </p>
          </div>
          <Landmark className="size-5 opacity-70" strokeWidth={1.6} />
        </div>
        <Progress
          value={vaultPct}
          className="mt-4 bg-white/15"
          barClassName="bg-vault-foreground"
        />
      </Card>

      <Card className="p-4">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <CardTitle className="text-base">Pending</CardTitle>
            {reservedUnits > 0 ? (
              <p className="mt-0.5 text-xs text-muted">{reservedUnits} Units reserved by purchase requests</p>
            ) : null}
          </div>
          {pendingCount > 0 ? <Badge tone="danger">{pendingCount}</Badge> : null}
        </div>
        {pendingCount === 0 ? (
          <p className="py-4 text-center text-sm text-muted">
            No requests right now.
          </p>
        ) : (
          <div className="divide-y divide-border">
            {pendingPurchases.map((p) => (
              <div key={p.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-ink">
                  <ProductIcon name={p.icon} className="size-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{p.name}</div>
                  <div className="text-xs text-muted">
                    {p.price} Units · Marketplace
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <Button
                    variant="success"
                    size="icon-sm"
                    aria-label="Approve"
                    onClick={() => {
                      const err = approvePurchase(p.id);
                      if (err) toast.error(err);
                      else toast.success("Purchase approved");
                    }}
                  >
                    <Check className="size-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon-sm"
                    aria-label="Deny"
                    onClick={() => {
                      denyPurchase(p.id);
                      toast.message("Purchase denied");
                    }}
                  >
                    <Ban className="size-4" />
                  </Button>
                </div>
              </div>
            ))}
            {pendingChores.map((c) => (
              <div key={c.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-accent-soft text-accent">
                  <Award className="size-5" strokeWidth={1.7} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{c.name}</div>
                  <div className="text-xs text-muted">
                    +{c.amount} Units · Goal
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <Button
                    variant="success"
                    size="icon-sm"
                    aria-label="Award"
                    onClick={() => {
                      const err = approveChore(c.id);
                      if (err) toast.error(err);
                      else toast.success(`+${c.amount} Units awarded`);
                    }}
                  >
                    <Check className="size-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon-sm"
                    aria-label="Deny"
                    onClick={() => {
                      denyChore(c.id);
                      toast.message("Goal not awarded");
                    }}
                  >
                    <Ban className="size-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div className="grid grid-cols-2 gap-2">
        <Button
          className="h-12"
          disabled={!consent}
          onClick={() => setScreen("load")}
        >
          <ArrowDownToLine className="size-4" />
          Load Units
        </Button>
        <Button
          variant="secondary"
          className="h-12"
          disabled={!consent}
          onClick={() => setScreen("award")}
        >
          <Award className="size-4" />
          Award
        </Button>
        <Button variant="outline" className="h-12" onClick={() => setScreen("vault")}>
          <Landmark className="size-4" />
          Vault
        </Button>
        <Button variant="outline" className="h-12" onClick={() => setScreen("history")}>
          <HistoryIcon className="size-4" />
          History
        </Button>
      </div>
    </div>
  );
}

export function ParentLoad() {
  const [amount, setAmount] = useState(20);
  const [ack, setAck] = useState(false);
  const loadUnits = useLedger((s) => s.loadUnits);

  return (
    <div className="screen-enter space-y-4">
      <header>
        <p className="text-sm font-medium text-muted">Load</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          Add Units
        </h1>
        <p className="mt-1 text-sm text-muted">
          Units are for spending in the PillarPath Marketplace or locking in the vault.
        </p>
      </header>

      <div className="rounded-lg bg-warn-soft p-4 text-sm text-warn">
        Once loaded, Units are not refundable as cash. Cash is only available
        to the child when a vault reaches maturity.
      </div>

      <Card className="space-y-3">
        <FieldLabel htmlFor="load-amount">Amount</FieldLabel>
        <Input
          id="load-amount"
          type="number"
          min={1}
          value={amount}
          onChange={(e) => setAmount(Number(e.target.value))}
        />
        <div className="flex gap-2">
          {[10, 20, 50].map((n) => (
            <Button
              key={n}
              type="button"
              variant={amount === n ? "default" : "outline"}
              size="sm"
              className="flex-1"
              onClick={() => setAmount(n)}
            >
              {n}
            </Button>
          ))}
        </div>
        <label className="flex items-start gap-3 rounded-md bg-surface-2 p-3 text-sm">
          <input
            type="checkbox"
            checked={ack}
            onChange={(e) => setAck(e.target.checked)}
            className="mt-0.5 size-4 accent-accent"
          />
          <span>
            I understand these Units cannot be withdrawn as cash until a vault
            matures.
          </span>
        </label>
        <Button
          className="w-full"
          disabled={!ack || amount < 1}
          onClick={() => {
            const err = loadUnits(amount);
            if (err) toast.error(err);
            else toast.success(`${amount} Units loaded — non-refundable`);
          }}
        >
          Confirm and load
        </Button>
      </Card>
      <BackButton />
    </div>
  );
}

export function ParentAward() {
  const [reason, setReason] = useState<string>(AWARD_REASONS[0]);
  const [amount, setAmount] = useState(5);
  const awardUnits = useLedger((s) => s.awardUnits);

  return (
    <div className="screen-enter space-y-4">
      <header>
        <p className="text-sm font-medium text-muted">Award</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          Reward a goal
        </h1>
        <p className="mt-1 text-sm text-muted">
          Direct awards skip the child's request queue.
        </p>
      </header>
      <Card className="space-y-3">
        <FieldLabel htmlFor="award-reason">Reason</FieldLabel>
        <NativeSelect
          id="award-reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
        >
          {AWARD_REASONS.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </NativeSelect>
        <FieldLabel htmlFor="award-amount">Units</FieldLabel>
        <Input
          id="award-amount"
          type="number"
          min={1}
          value={amount}
          onChange={(e) => setAmount(Number(e.target.value))}
        />
        <Button
          className="w-full"
          onClick={() => {
            const err = awardUnits(amount, reason);
            if (err) toast.error(err);
            else toast.success(`+${amount} Units awarded`);
          }}
        >
          Award Units
        </Button>
      </Card>
      <BackButton />
    </div>
  );
}

export function ParentVault() {
  const vault = useLedger((s) => s.vault);
  const vaultTarget = useLedger((s) => s.vaultTarget);
  const vaultGoal = useLedger((s) => s.vaultGoal);
  const matchRate = useLedger((s) => s.matchRate);
  const daysRemaining = useLedger((s) => s.daysRemaining());
  const setMatchRate = useLedger((s) => s.setMatchRate);
  const setScreen = useLedger((s) => s.setScreen);

  return (
    <div className="screen-enter space-y-4">
      <header>
        <p className="text-sm font-medium text-muted">Vault</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          Long-term savings
        </h1>
        <p className="mt-1 text-sm text-muted">
          Locked Units remain closed-loop Pillar Units and unlock into the family goal at maturity.
        </p>
      </header>

      <Card className="bg-vault p-5 text-vault-foreground">
        <p className="text-xs font-medium uppercase tracking-wider text-vault-foreground/60">
          Currently locked
        </p>
        <p className="mt-1 font-display text-4xl font-semibold tabular-nums">
          {formatUnits(vault)}
        </p>
        <p className="mt-1 text-sm text-vault-foreground/75">
          Goal: {vaultGoal}
        </p>
        <Progress
          value={(vault / vaultTarget) * 100}
          className="mt-4 bg-white/15"
          barClassName="bg-vault-foreground"
        />
        <p className="mt-3 text-sm text-vault-foreground/80">
          {daysRemaining === 0
            ? "Matured — the family goal is unlocked."
            : `${daysRemaining} days until maturity.`}
        </p>
      </Card>

      <Card className="space-y-3">
        <CardTitle className="text-base">Parent matching</CardTitle>
        <CardHint>
          Optionally match what Alex locks. Matched Units go straight into the
          vault.
        </CardHint>
        <NativeSelect
          value={String(matchRate)}
          onChange={(e) => {
            const v = Number(e.target.value) as MatchRate;
            toast.success(setMatchRate(v));
          }}
        >
          <option value="0">No matching</option>
          <option value="0.5">Match 50%</option>
          <option value="1">Match 100%</option>
        </NativeSelect>
      </Card>

      <BackButton />
    </div>
  );
}

export function ParentHistory() {
  const history = useLedger((s) => s.history);

  return (
    <div className="screen-enter space-y-4">
      <header>
        <p className="text-sm font-medium text-muted">Ledger</p>
        <h1 className="font-display text-3xl font-semibold tracking-tight">
          History
        </h1>
        <p className="mt-1 text-sm text-muted">
          Every load, award, lock, and spend — synchronized to the secured family ledger.
        </p>
      </header>

      <Card className="ledger-ruled p-0">
        {history.length === 0 ? (
          <p className="p-6 text-center text-sm text-muted">No events yet.</p>
        ) : (
          <ul>
            {history.map((e) => {
              const signed =
                e.kind === "debit" || e.kind === "transfer" || e.kind === "cashout"
                  ? "out"
                  : e.kind === "event"
                    ? "none"
                    : "in";
              return (
                <li
                  key={e.id}
                  className="flex items-start justify-between gap-3 px-4 py-3.5"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-medium">{e.note}</div>
                    <div className="text-xs text-muted">{formatWhen(e.at)}</div>
                  </div>
                  {signed !== "none" ? (
                    <span
                      className={`shrink-0 font-mono text-sm tabular-nums ${
                        signed === "in" ? "text-success" : "text-ink"
                      }`}
                    >
                      {signed === "in" ? "+" : "−"}
                      {e.amount}
                    </span>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </Card>

      <BackButton />
    </div>
  );
}
