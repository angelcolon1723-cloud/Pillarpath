import { useEffect, useMemo, useRef, useState, type Dispatch, type ReactNode, type SetStateAction } from "react";
import {
  BookOpen, Brain, Brush, Check, Code2, Eraser, Gamepad2, Grid3X3,
  Headphones, Lightbulb, Music2, Palette, Printer, Save, Shirt, Sparkles,
  Trophy, Wand2, Zap, Rocket, Waves, Search, Shapes, Building2, Bot,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardHint, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { saveStudioProject, recordLearningActivity } from "@/lib/pillarpath-server";
import { useLedger } from "@/store/ledger";

const SWATCHES = ["#111111", "#1f6b5c", "#b5453a", "#8a6420", "#6b5bd6", "#d46b2c", "#2f75b5", "#faf7f1"];
const BRUSHES = [
  { id: "pencil", label: "Pencil", size: 3 },
  { id: "marker", label: "Marker", size: 8 },
  { id: "bold", label: "Bold", size: 16 },
  { id: "dot", label: "Stamp", size: 24 },
] as const;

const AGE_BANDS = {
  sprout: { label: "Sprout", ages: "4–6", level: "Foundations", description: "Letters, colors, counting, stories and simple patterns." },
  explorer: { label: "Explorer", ages: "7–9", level: "Builder", description: "Reading, multiplication, logic, design and creative storytelling." },
  pathfinder: { label: "Pathfinder", ages: "10–12", level: "Challenger", description: "Research, coding logic, strategy, writing and STEM projects." },
  creator: { label: "Creator", ages: "13–17", level: "Mastery", description: "Advanced design, entrepreneurship, media, code and portfolio work." },
} as const;

type AgeBand = keyof typeof AGE_BANDS;
type StudioTab = "canvas" | "coloring" | "maker" | "reading" | "puzzles" | "code" | "music" | "design" | "portfolio";

const LIBRARY = [
  ["Rocket Rescue", "coloring", "rocket", "Space, sequencing, and visual storytelling"],
  ["Ocean Architect", "coloring", "waves", "Patterns, ecosystems, and shape composition"],
  ["Dino Detective", "puzzle", "search", "Clues, sorting, memory, and logic"],
  ["Garden Geometry", "puzzle", "shapes", "Fractions, symmetry, and measurement"],
  ["Comic Quest", "story", "book", "Build a beginning, middle, and ending"],
  ["Future City", "craft", "building", "Design a sustainable neighborhood"],
  ["Code Critter", "game", "bot", "Sequences, loops, and debugging"],
  ["Soundscape", "music", "music", "Rhythm, pattern, and audio storytelling"],
] as const;

function bandForAge(age: number): AgeBand {
  if (age <= 6) return "sprout";
  if (age <= 9) return "explorer";
  if (age <= 12) return "pathfinder";
  return "creator";
}

export function StudioScreen({ studioPlus = false, childAge = 10, childId }: { studioPlus?: boolean; childAge?: number | null; childId?: number }) {
  const age = childAge ?? 10;
  const ageBand = bandForAge(age);
  const band = AGE_BANDS[ageBand];
  const [tab, setTab] = useState<StudioTab>("canvas");
  const [filterBand, setFilterBand] = useState<AgeBand>(ageBand);
  const [color, setColor] = useState(SWATCHES[0]);
  const [brush, setBrush] = useState<(typeof BRUSHES)[number]["id"]>("marker");
  const [canvasTitle, setCanvasTitle] = useState("My PillarPath masterpiece");
  const [shirtColor, setShirtColor] = useState("#1f6b5c");
  const [shirtText, setShirtText] = useState("PILLAR POWER");
  const [game, setGame] = useState({ round: 0, score: 0, sequence: [2, 4, 6, 8], answer: "10" });
  const [story, setStory] = useState("");
  const [music, setMusic] = useState({ tempo: 90, beat: 4 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const drawing = useRef(false);
  const saveDrawing = useLedger((s) => s.saveDrawing);

  const templates = useMemo(() => LIBRARY.filter((item) => item[1] !== "game" || studioPlus), [studioPlus]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const fit = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(rect.width * dpr);
      canvas.height = Math.floor(380 * dpr);
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = "380px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, rect.width, 380);
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
    };
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const pos = (e: MouseEvent | TouchEvent) => {
      const r = canvas.getBoundingClientRect();
      const t = "touches" in e ? e.touches[0] : e;
      return t ? { x: t.clientX - r.left, y: t.clientY - r.top } : null;
    };
    const start = (e: MouseEvent | TouchEvent) => { if ("touches" in e) e.preventDefault(); const p = pos(e); if (!p) return; drawing.current = true; ctx.beginPath(); ctx.strokeStyle = color; ctx.fillStyle = color; const b = BRUSHES.find((x) => x.id === brush) ?? BRUSHES[1]; ctx.lineWidth = b.size; if (brush === "dot") { ctx.arc(p.x, p.y, b.size / 2, 0, Math.PI * 2); ctx.fill(); } else ctx.moveTo(p.x, p.y); };
    const move = (e: MouseEvent | TouchEvent) => { if (!drawing.current) return; if ("touches" in e) e.preventDefault(); const p = pos(e); if (!p || brush === "dot") return; ctx.lineTo(p.x, p.y); ctx.stroke(); };
    const end = () => { drawing.current = false; };
    canvas.addEventListener("mousedown", start); canvas.addEventListener("mousemove", move); window.addEventListener("mouseup", end);
    canvas.addEventListener("touchstart", start, { passive: false }); canvas.addEventListener("touchmove", move, { passive: false }); window.addEventListener("touchend", end);
    return () => { canvas.removeEventListener("mousedown", start); canvas.removeEventListener("mousemove", move); window.removeEventListener("mouseup", end); canvas.removeEventListener("touchstart", start); canvas.removeEventListener("touchmove", move); window.removeEventListener("touchend", end); };
  }, [color, brush]);

  function clearCanvas() {
    const canvas = canvasRef.current; const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const r = canvas.getBoundingClientRect(); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, r.width, 380);
  }

  async function saveProject(category: "drawing" | "coloring" | "craft" | "story" | "shirt" | "music" | "game" | "puzzle", payload: Record<string, unknown>) {
    try {
      if (category === "drawing") {
        const canvas = canvasRef.current;
        if (canvas) saveDrawing(canvas.toDataURL("image/png"));
      }
      await saveStudioProject({ data: { childId, title: canvasTitle, category, ageBand, payload } });
      toast.success("Project saved to your PillarPath portfolio");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save project");
    }
  }

  async function completeActivity(activityKey: string, score: number) {
    try {
      await recordLearningActivity({ data: { childId, activityKey, ageBand, level: band.level, score } });
    } catch {
      // Learning progress should never block the creative experience.
    }
  }

  const tabs: Array<[StudioTab, string, typeof Brush]> = [
    ["canvas", "Create Lab", Brush], ["coloring", "Coloring", Palette], ["maker", "Maker Lab", Wand2],
    ["reading", "Story + Books", BookOpen], ["puzzles", "Puzzle Arcade", Brain], ["code", "Code + Logic", Code2],
    ["music", "Music + Motion", Music2], ["design", "Design Lab", Shirt], ["portfolio", "My Portfolio", Trophy],
  ];

  return (
    <div className="screen-enter space-y-5">
      <header>
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Creative Campus</p>
          <BadgeLike>{band.label} · Ages {band.ages}</BadgeLike>
          {studioPlus ? <BadgeLike>Studio Plus</BadgeLike> : <BadgeLike>Core Studio</BadgeLike>}
        </div>
        <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight sm:text-4xl">A whole world to make, learn, play, and share.</h1>
        <p className="mt-2 max-w-3xl text-sm text-muted">{band.description} PillarPath adapts the studio to the child's age band and advancement level while keeping the parent in control.</p>
      </header>

      <Card className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div><CardTitle className="text-base">Learning path</CardTitle><CardHint className="mt-1">Age is used to organize activities, not to label ability.</CardHint></div>
          <div className="flex gap-1 overflow-x-auto rounded-xl bg-surface-2 p-1">
            {(Object.entries(AGE_BANDS) as Array<[AgeBand, typeof AGE_BANDS[AgeBand]]>).map(([key, value]) => (
              <button key={key} type="button" onClick={() => setFilterBand(key)} className={`whitespace-nowrap rounded-lg px-3 py-2 text-xs font-semibold ${filterBand === key ? "bg-surface text-ink shadow-[var(--shadow-border)]" : "text-muted"}`}>{value.label}</button>
            ))}
          </div>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-4">
          {Object.values(AGE_BANDS).map((value, i) => <div key={value.label} className="rounded-xl bg-surface-2 p-3"><p className="text-xs text-muted">Level {i + 1}</p><p className="mt-1 font-semibold">{value.level}</p><p className="mt-1 text-xs text-muted">{value.description}</p></div>)}
        </div>
      </Card>

      <div className="grid grid-cols-3 gap-1 overflow-x-auto rounded-xl bg-surface-2 p-1 sm:grid-cols-5 lg:grid-cols-9">
        {tabs.map(([id, label, Icon]) => <button key={id} type="button" onClick={() => setTab(id)} className={`min-h-12 rounded-lg px-2 text-[10px] font-semibold sm:text-xs ${tab === id ? "bg-surface text-ink shadow-[var(--shadow-border)]" : "text-muted"}`}><Icon className="mx-auto mb-1 size-4" />{label}</button>)}
      </div>

      {tab === "canvas" && <CreateLab canvasTitle={canvasTitle} setCanvasTitle={setCanvasTitle} canvasRef={canvasRef} wrapRef={wrapRef} color={color} setColor={setColor} brush={brush} setBrush={setBrush} clear={clearCanvas} save={() => void saveProject("drawing", { title: canvasTitle })} print={() => window.print()} />}
      {tab === "coloring" && <LibrarySection title="Coloring Universe" hint="Collections rotate by age band and skill level. Pick a world, then remix it in Create Lab." items={templates.filter((x) => x[1] === "coloring")} onStart={(item) => { setCanvasTitle(item[0]); setTab("canvas"); toast.success(`${item[0]} loaded into Create Lab`); }} />}
      {tab === "maker" && <MakerLab onSave={(title, payload) => void saveProject("craft", { title, ...payload })} />}
      {tab === "reading" && <ReadingLab ageBand={filterBand} story={story} setStory={setStory} onSave={() => void saveProject("story", { text: story })} />}
      {tab === "puzzles" && <PuzzleArcade game={game} setGame={setGame} onScore={(score) => void completeActivity("pattern-puzzle", score)} />}
      {tab === "code" && <CodeLab onComplete={(score) => void completeActivity("code-sequencer", score)} />}
      {tab === "music" && <MusicLab music={music} setMusic={setMusic} onSave={() => void saveProject("music", music)} />}
      {tab === "design" && <DesignLab shirtColor={shirtColor} setShirtColor={setShirtColor} shirtText={shirtText} setShirtText={setShirtText} onSave={() => void saveProject("shirt", { shirtColor, shirtText })} />}
      {tab === "portfolio" && <PortfolioPanel />}
    </div>
  );
}

function BadgeLike({ children }: { children: ReactNode }) { return <span className="rounded-full border border-border bg-surface px-2.5 py-1 text-[11px] font-semibold text-muted">{children}</span>; }

function CreateLab({ canvasTitle, setCanvasTitle, canvasRef, wrapRef, color, setColor, brush, setBrush, clear, save, print }: any) {
  return <Card className="space-y-4 p-3"><div className="flex flex-col gap-3 sm:flex-row sm:items-center"><Input value={canvasTitle} onChange={(e) => setCanvasTitle(e.target.value.slice(0, 80))} placeholder="Project title" /><div className="flex gap-2"><Button variant="outline" onClick={clear}><Eraser className="size-4" />Clear</Button><Button variant="outline" onClick={print}><Printer className="size-4" />Print</Button><Button onClick={save}><Save className="size-4" />Save</Button></div></div><div ref={wrapRef} className="overflow-hidden rounded-2xl bg-white shadow-[var(--shadow-border)]"><canvas ref={canvasRef} className="block h-[380px] w-full touch-none" aria-label="Creative Studio drawing canvas" /></div><div className="flex flex-col gap-4 rounded-2xl bg-surface-2 p-4"><div className="flex flex-wrap gap-2">{SWATCHES.map((c) => <button key={c} type="button" aria-label={`Color ${c}`} onClick={() => setColor(c)} className="size-9 rounded-full border-2" style={{ background: c, borderColor: color === c ? "var(--color-ink)" : "transparent" }} />)}</div><div className="flex flex-wrap gap-2">{BRUSHES.map((b) => <Button key={b.id} variant={brush === b.id ? "default" : "outline"} size="sm" onClick={() => setBrush(b.id)}><Brush className="size-3.5" />{b.label}</Button>)}</div></div><div className="grid gap-3 sm:grid-cols-3"><ToolCard icon={Grid3X3} title="Guides" text="Grid, symmetry and trace-friendly practice can be layered into templates." /><ToolCard icon={Sparkles} title="Remix" text="Turn a coloring page into your own scene instead of copying a finished picture." /><ToolCard icon={Printer} title="Make it real" text="Print at home or prepare a parent-approved merchandise design." /></div></Card>;
}

function LibraryIcon({ kind }: { kind: string }) {
  const icons: Record<string, typeof Rocket> = { rocket: Rocket, waves: Waves, search: Search, shapes: Shapes, book: BookOpen, building: Building2, bot: Bot, music: Music2 };
  const Icon = icons[kind] ?? Sparkles;
  return <Icon className="size-14" strokeWidth={1.5} />;
}

function LibrarySection({ title, hint, items, onStart }: { title: string; hint: string; items: readonly (readonly [string, string, string, string])[]; onStart: (item: readonly [string, string, string, string]) => void }) {
  return <section className="space-y-4"><div><CardTitle>{title}</CardTitle><CardHint className="mt-1">{hint}</CardHint></div><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{items.map((item) => <Card key={item[0]} className="overflow-hidden p-0"><div className="grid aspect-[1.15] place-items-center bg-surface-2 text-accent"><LibraryIcon kind={item[2]} /></div><div className="p-4"><BadgeLike>{item[1]}</BadgeLike><h3 className="mt-3 font-display text-xl font-semibold">{item[0]}</h3><p className="mt-1 text-sm text-muted">{item[3]}</p><Button className="mt-4 w-full" onClick={() => onStart(item)}>Open activity</Button></div></Card>)}</div></section>;
}

function MakerLab({ onSave }: { onSave: (title: string, payload: Record<string, unknown>) => void }) {
  const [idea, setIdea] = useState("A tiny eco-friendly city");
  const [materials, setMaterials] = useState("paper, recycled box, markers");
  return <Card className="space-y-4 p-5"><div className="flex items-start gap-3"><Wand2 className="mt-1 size-6 text-accent" /><div><CardTitle>Maker Lab</CardTitle><CardHint className="mt-1">Plan a real-world build with materials, steps, and a reflection.</CardHint></div></div><Input value={idea} onChange={(e) => setIdea(e.target.value)} /><Input value={materials} onChange={(e) => setMaterials(e.target.value)} /><div className="grid gap-3 sm:grid-cols-3">{["Plan", "Build", "Reflect"].map((step, i) => <div key={step} className="rounded-xl bg-surface-2 p-4"><p className="text-xs text-muted">Step {i + 1}</p><p className="mt-1 font-semibold">{step}</p><p className="mt-1 text-xs text-muted">{i === 0 ? "Sketch the idea." : i === 1 ? "Make a prototype." : "Explain what you would change."}</p></div>)}</div><Button onClick={() => onSave(idea, { materials, steps: ["plan", "build", "reflect"] })}><Save className="size-4" />Save maker project</Button></Card>;
}

function ReadingLab({ ageBand, story, setStory, onSave }: { ageBand: AgeBand; story: string; setStory: (v: string) => void; onSave: () => void }) {
  const prompts = ageBand === "sprout" ? ["Find 5 words that rhyme", "Draw the setting"] : ageBand === "explorer" ? ["Write a strong opening", "Find the main problem"] : ageBand === "pathfinder" ? ["Add a plot twist", "Write a character goal"] : ["Write a one-page scene", "Edit for voice and pacing"];
  return <Card className="space-y-4 p-5"><div className="flex items-start gap-3"><BookOpen className="mt-1 size-6 text-accent" /><div><CardTitle>Story + Reading Lab</CardTitle><CardHint className="mt-1">Interactive reading practice, creative writing, vocabulary and book projects.</CardHint></div></div><div className="grid gap-3 sm:grid-cols-2">{prompts.map((p) => <button key={p} type="button" onClick={() => setStory((story ? story + "\n\n" : "") + p + ": ")} className="rounded-xl bg-surface-2 p-4 text-left font-semibold hover:bg-accent-soft">{p}</button>)}</div><textarea value={story} onChange={(e) => setStory(e.target.value.slice(0, 5000))} className="min-h-56 w-full rounded-2xl border border-border bg-surface p-4 text-sm outline-none focus:border-accent" placeholder="Write, sketch, summarize, or answer a prompt…" /><Button onClick={onSave}><Save className="size-4" />Save reading project</Button></Card>;
}

function PuzzleArcade({ game, setGame, onScore }: { game: { round: number; score: number; sequence: number[]; answer: string }; setGame: Dispatch<SetStateAction<{ round: number; score: number; sequence: number[]; answer: string }>>; onScore: (score: number) => void }) {
  const choices = ["9", "10", "11", "12"];
  const correct = game.answer;
  return <Card className="space-y-5 p-5"><div className="flex items-start justify-between gap-3"><div><CardTitle>Puzzle Arcade</CardTitle><CardHint className="mt-1">Pattern recognition, memory, spatial reasoning and speed challenges. Scores are practice signals, not intelligence tests.</CardHint></div><div className="rounded-xl bg-accent-soft px-3 py-2 text-sm font-semibold">{game.score} pts</div></div><div className="rounded-2xl bg-ink p-8 text-center text-bg"><p className="text-xs uppercase tracking-wider text-bg/60">Pattern challenge</p><p className="mt-4 font-mono text-4xl">{game.sequence.join(" · ")} · ?</p></div><div className="grid grid-cols-2 gap-3">{choices.map((choice) => <Button key={choice} variant="outline" className="h-14 text-lg" onClick={() => { const ok = choice === correct; const nextScore = game.score + (ok ? 10 : 0); setGame((g) => ({ ...g, round: g.round + 1, score: nextScore, sequence: [g.round + 3, g.round + 5, g.round + 7, g.round + 9], answer: String(g.round + 11) })); if (ok) toast.success("Great pattern! +10"); else toast.message("Keep exploring the pattern."); onScore(nextScore); }}>{choice}</Button>)}</div><Progress value={Math.min(100, (game.round % 10) * 10)} /></Card>;
}

function CodeLab({ onComplete }: { onComplete: (score: number) => void }) {
  const [steps, setSteps] = useState(["MOVE", "MOVE", "TURN"]);
  const [target, setTarget] = useState(3);
  const [message, setMessage] = useState("Build a sequence that reaches the star.");
  return <Card className="space-y-4 p-5"><div className="flex items-start gap-3"><Code2 className="mt-1 size-6 text-accent" /><div><CardTitle>Code + Logic Lab</CardTitle><CardHint className="mt-1">Learn sequencing, conditions, debugging and systems thinking without needing a coding environment.</CardHint></div></div><div className="grid gap-3 sm:grid-cols-[1fr_0.7fr]"><div className="rounded-2xl bg-surface-2 p-5"><div className="grid grid-cols-3 gap-2">{steps.map((step, i) => <button key={`${step}-${i}`} type="button" onClick={() => setSteps((v) => v.map((x, j) => j === i ? x === "MOVE" ? "TURN" : "MOVE" : x))} className="rounded-xl bg-surface p-3 text-xs font-bold">{step}</button>)}</div><Button className="mt-4 w-full" onClick={() => { const score = steps.filter((x) => x === "MOVE").length === target ? 100 : 60; setMessage(score === 100 ? "Solved! Now try changing one instruction." : "Not quite. Debug the sequence and try again."); onComplete(score); }}>Run sequence</Button></div><div className="rounded-2xl bg-ink p-5 text-bg"><p className="text-xs text-bg/60">Robot mission</p><p className="mt-3 text-3xl">🤖 → ⭐</p><p className="mt-3 text-sm text-bg/70">{message}</p></div></div></Card>;
}

function MusicLab({ music, setMusic, onSave }: { music: { tempo: number; beat: number }; setMusic: Dispatch<SetStateAction<{ tempo: number; beat: number }>>; onSave: () => void }) {
  return <Card className="space-y-5 p-5"><div className="flex items-start gap-3"><Headphones className="mt-1 size-6 text-accent" /><div><CardTitle>Music + Motion Lab</CardTitle><CardHint className="mt-1">Explore rhythm, tempo, pattern, movement and sound storytelling.</CardHint></div></div><div className="grid gap-4 sm:grid-cols-2"><label className="text-sm font-semibold">Tempo<input type="range" min="50" max="160" value={music.tempo} onChange={(e) => setMusic({ ...music, tempo: Number(e.target.value) })} className="mt-3 w-full" /><span className="mt-1 block text-xs text-muted">{music.tempo} BPM</span></label><label className="text-sm font-semibold">Beat pattern<input type="range" min="2" max="8" value={music.beat} onChange={(e) => setMusic({ ...music, beat: Number(e.target.value) })} className="mt-3 w-full" /><span className="mt-1 block text-xs text-muted">{music.beat}/8 pattern</span></label></div><div className="flex items-end gap-2 rounded-2xl bg-surface-2 p-5 h-32">{Array.from({ length: music.beat }).map((_, i) => <div key={i} className={`flex-1 rounded-t-xl ${i % 2 ? "bg-accent/40" : "bg-accent"}`} style={{ height: `${30 + ((i * 17 + music.tempo) % 60)}%` }} />)}</div><Button onClick={onSave}><Save className="size-4" />Save soundscape</Button></Card>;
}

function DesignLab({ shirtColor, setShirtColor, shirtText, setShirtText, onSave }: { shirtColor: string; setShirtColor: (v: string) => void; shirtText: string; setShirtText: (v: string) => void; onSave: () => void }) {
  return <Card className="p-5"><div className="flex items-start gap-3"><Shirt className="mt-1 size-6 text-accent" /><div><CardTitle>Design Lab</CardTitle><CardHint className="mt-1">Create apparel, posters, badges, stickers and parent-approved merchandise concepts.</CardHint></div></div><div className="mt-5 grid gap-5 md:grid-cols-2"><div className="grid min-h-72 place-items-center rounded-2xl bg-surface-2 p-6"><div className="relative grid h-60 w-52 place-items-center" style={{ color: shirtColor }}><Shirt className="absolute size-full" fill="currentColor" strokeWidth={1.2} /><span className="relative z-10 max-w-32 text-center text-lg font-black tracking-tight text-white">{shirtText}</span></div></div><div className="space-y-4"><label className="block text-sm font-semibold">Base color<input type="color" value={shirtColor} onChange={(e) => setShirtColor(e.target.value)} className="mt-2 h-11 w-full rounded-lg border border-border bg-surface" /></label><label className="block text-sm font-semibold">Text<input value={shirtText} onChange={(e) => setShirtText(e.target.value.slice(0, 30))} className="mt-2 h-11 w-full rounded-lg border border-border bg-surface px-3" /></label><div className="rounded-xl bg-warn-soft p-4 text-sm text-warn">Child-created designs are drafts. A parent must approve a purchase before anything is sent to fulfillment.</div><Button className="w-full" onClick={onSave}><Check className="size-4" />Save design draft</Button></div></div></Card>;
}

function PortfolioPanel() {
  return <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"><ToolCard icon={Trophy} title="Skill milestones" text="Creative, reading, logic, STEM and design milestones can accumulate into a personal learning portfolio." /><ToolCard icon={Zap} title="Daily studio streak" text="Short creative sessions can build a streak without turning the experience into a pressure loop." /><ToolCard icon={Lightbulb} title="Project ideas" text="Use prompts, templates, remix challenges and reflection cards to keep the studio fresh." /><ToolCard icon={Gamepad2} title="Arcade progress" text="Puzzle and logic practice can track completion and personal improvement." /><ToolCard icon={Music2} title="Media lab" text="Music, motion and visual storytelling provide more ways to create than drawing alone." /><ToolCard icon={Sparkles} title="Showcase" text="Parent-approved work can later be submitted to the moderated community gallery." /></div>;
}

function ToolCard({ icon: Icon, title, text }: { icon: typeof Brush; title: string; text: string }) {
  return <Card className="p-4"><div className="flex size-10 items-center justify-center rounded-xl bg-accent-soft text-accent"><Icon className="size-5" /></div><h3 className="mt-3 font-semibold">{title}</h3><p className="mt-1 text-sm text-muted">{text}</p></Card>;
}
