import { cn } from "@/lib/utils";

/** PillarPath brand mark: three pillars + a forward path. */
export function LedgerMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" aria-hidden="true" className={cn("size-8", className)}>
      <rect x="2" y="2" width="36" height="36" rx="11" fill="currentColor" className="text-accent" />
      <path d="M10 29V13h5v16h-5Zm7.5 0V10h5v19h-5Zm7.5 0V16h5v13h-5Z" fill="currentColor" className="text-bg" />
      <path d="M10 31h20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className="text-bg" opacity=".55" />
      <path d="m25 8 5 3-5 3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-bg" opacity=".9" />
    </svg>
  );
}
