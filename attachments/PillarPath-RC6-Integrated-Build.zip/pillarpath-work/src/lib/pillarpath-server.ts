import { createServerFn } from "@tanstack/react-start";
import { createHash, randomBytes } from "node:crypto";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { isWorkspacePreview } from "@/lib/env.server";
import { uid } from "@/lib/utils";

const FUTURE_PLANS = {
  sprout: { label: "Sprout", termDays: 30, bonusRate: 0.05, min: 10 },
  builder: { label: "Builder", termDays: 60, bonusRate: 0.1, min: 25 },
  pathfinder: { label: "Pathfinder", termDays: 90, bonusRate: 0.15, min: 50 },
  creator: { label: "Creator", termDays: 180, bonusRate: 0.25, min: 100 },
} as const;

type FuturePlanCode = keyof typeof FUTURE_PLANS;
type CorporateRole = "executive" | "finance" | "support" | "safety" | "school_admin" | "commerce_admin" | "system_admin";

async function ensureUserSeed(userId: string) {
  const sql = await getSql();
  const users = await sql<{ name: string | null }>`select name from "user" where id = ${userId} limit 1`;
  const displayName = (users[0]?.name ?? "").trim() || "PillarPath Parent";
  await sql`
    insert into profiles (user_id, display_name)
    values (${userId}, ${displayName})
    on conflict (user_id) do nothing
  `;
  // Never create demo children, balances, marketing records, or supplier data for a real customer.
}

async function requireCorporateRole(userId: string, allowed: CorporateRole[]) {
  const sql = await getSql();
  const rows = await sql<{ role: CorporateRole }>`
    select role from corporate_memberships
    where user_id = ${userId} and active = true and role = any(${allowed})
    limit 1
  `;
  if (!rows[0]) throw new Error("Corporate authorization required");
  return rows[0].role;
}

function hashChildGrant(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

async function requireChildGrant(userId: string, token: string, childId?: number) {
  if (!token || token.length < 32) throw new Error("Child access authorization required");
  const sql = await getSql();
  const rows = await sql<{ child_id: number }>`
    select child_id from child_access_grants
    where user_id=${userId} and token_hash=${hashChildGrant(token)} and revoked_at is null and expires_at > now()
      and (${childId ?? null}::bigint is null or child_id=${childId ?? null})
    limit 1
  `;
  if (!rows[0]) throw new Error("Child access session expired");
  return rows[0].child_id;
}

async function audit(userId: string, action: string, resourceType: string, resourceId?: string, metadata: Record<string, unknown> = {}) {
  const sql = await getSql();
  await sql`
    insert into audit_events (user_id, actor_user_id, action, resource_type, resource_id, metadata)
    values (${userId}, ${userId}, ${action}, ${resourceType}, ${resourceId ?? null}, ${JSON.stringify(metadata)}::jsonb)
  `;
}

export const getPillarPathData = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureUserSeed(context.userId);
    const [profiles, children, products, cartItems, orders, futurePlans] = await Promise.all([
      sql<{ display_name: string; phone: string | null; marketing_opt_in: boolean; currency: string; studio_plus: boolean }>`
        select display_name, phone, marketing_opt_in, currency, studio_plus from profiles where user_id = ${context.userId}`,
      sql<{ id: number; name: string; age: number | null; avatar: string; units: number; vault_units: number; frozen: boolean }>`
        select id, name, age, avatar, units, vault_units, frozen from children where user_id = ${context.userId} order by id`,
      sql<{ id: string; name: string; description: string; category: string; unit_price: number; retail_price_cents: number; inventory: number }>`
        select id, name, description, category, unit_price, retail_price_cents, inventory from store_products where active = true order by category, name`,
      sql<{ product_id: string; quantity: number }>`
        select ci.product_id, ci.quantity from cart_items ci join carts c on c.id = ci.cart_id where c.user_id = ${context.userId} and c.status = 'open'`,
      sql<{ id: number; status: string; total_cents: number; created_at: string; payment_provider: string; payment_reference: string | null }>`
        select id, status, total_cents, created_at, payment_provider, payment_reference from orders where user_id = ${context.userId} order by id desc limit 20`,
      sql<{ id: string; plan_code: FuturePlanCode; committed_units: number; bonus_units: number; maturity_at: string; status: string; funding_mode: string; created_at: string }>`
        select id, plan_code, committed_units, bonus_units, maturity_at, status, funding_mode, created_at from future_unit_plans where user_id = ${context.userId} order by created_at desc limit 20`,
    ]);
    return {
      profile: profiles[0] ?? { display_name: "PillarPath Parent", phone: null, marketing_opt_in: false, currency: "USD", studio_plus: false },
      children,
      products,
      cart: cartItems.map((item) => ({ productId: item.product_id, quantity: item.quantity })),
      orders,
      futurePlans,
    };
  });

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { displayName: string; phone: string; marketingOptIn: boolean }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const displayName = data.displayName.trim().slice(0, 80);
    const phone = data.phone.trim().slice(0, 40);
    await sql`
      insert into profiles (user_id, display_name, phone, marketing_opt_in, updated_at)
      values (${context.userId}, ${displayName || "PillarPath Parent"}, ${phone || null}, ${Boolean(data.marketingOptIn)}, now())
      on conflict (user_id) do update set display_name = excluded.display_name, phone = excluded.phone, marketing_opt_in = excluded.marketing_opt_in, updated_at = now()
    `;
    await audit(context.userId, "profile.updated", "profile");
    return { ok: true };
  });

export const createChild = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { name: string; age: number; avatar: string }) => input)
  .handler(async ({ context, data }) => {
    const name = data.name.trim().slice(0, 80);
    const age = Math.floor(Number(data.age));
    if (!name || !Number.isFinite(age) || age < 3 || age > 17) throw new Error("Enter a valid child profile.");
    const sql = await getSql();
    const rows = await sql<{ id: number }>`insert into children (user_id, name, age, avatar) values (${context.userId}, ${name}, ${age}, ${data.avatar.slice(0, 30)}) returning id`;
    await audit(context.userId, "child.created", "child", String(rows[0]?.id));
    return { id: rows[0]?.id };
  });

export const createFutureUnitPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { planCode: FuturePlanCode; committedUnits: number }) => input)
  .handler(async ({ context, data }) => {
    const plan = FUTURE_PLANS[data.planCode];
    if (!plan) throw new Error("Unknown Future Units plan");
    const units = Math.floor(Number(data.committedUnits));
    if (!Number.isFinite(units) || units < plan.min || units > 100000) throw new Error(`Choose between ${plan.min} and 100,000 Units.`);

    // Closed-loop family reward reserve: the parent moves existing Pillar Units into a time-locked plan.
    // Cash-funded trading, resale, yield, or securities remain disabled until a separate legal/compliance layer exists.
    const sql = await getSql();
    const bonus = Math.floor(units * plan.bonusRate);
    const maturity = new Date(Date.now() + plan.termDays * 86400000).toISOString();
    const child = (await sql<{ id: number; units: number }>`select id, units from children where user_id=${context.userId} order by id limit 1`)[0];
    if (!child) throw new Error("Create a child profile before reserving Future Units.");
    const updated = await sql<{ id: number }>`update children set units=units-${units}, future_reserved_units=future_reserved_units+${units} where id=${child.id} and user_id=${context.userId} and units>=${units} returning id`;
    if (!updated[0]) throw new Error("Not enough available Units for this plan.");
    const planId = uid("future");
    const rows = await sql<{ id: string }>`
      insert into future_unit_plans (id, user_id, child_id, plan_code, committed_units, bonus_units, maturity_at, status, funding_mode)
      values (${planId}, ${context.userId}, ${child.id}, ${data.planCode}, ${units}, ${bonus}, ${maturity}, 'active', 'units')
      returning id
    `;
    await sql`insert into unit_transactions (id, user_id, child_id, kind, amount, note, idempotency_key) values (${uid("txn")}, ${context.userId}, ${child.id}, 'transfer', ${units}, ${`Future Units reserve · ${data.planCode}`}, ${`future-${rows[0]?.id}`})`;
    await audit(context.userId, "future_units.plan_created", "future_unit_plan", rows[0]?.id, { planCode: data.planCode, units });
    return { id: rows[0]?.id, mode: "closed_loop" as const, maturityAt: maturity, bonusUnits: bonus };
  });

export const matureFutureUnitPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { planId: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string; child_id: number; committed_units: number; bonus_units: number; maturity_at: string; status: string }>`
      select id, child_id, committed_units, bonus_units, maturity_at, status from future_unit_plans where id = ${data.planId} and user_id = ${context.userId} limit 1
    `;
    const plan = rows[0];
    if (!plan) throw new Error("Future Units plan not found");
    if (plan.status !== "simulation" && plan.status !== "active") throw new Error("Plan is not active");
    if (new Date(plan.maturity_at).getTime() > Date.now()) throw new Error("Plan has not matured yet");
    const updated = await sql<{ id: number }>`
      with matured as (
        update future_unit_plans
        set status = 'matured'
        where id = ${data.planId} and user_id = ${context.userId} and status = 'active' and maturity_at <= now()
        returning child_id, committed_units, bonus_units
      )
      update children c
      set future_reserved_units = greatest(0, c.future_reserved_units - matured.committed_units),
          units = c.units + matured.committed_units + matured.bonus_units
      from matured
      where c.id = matured.child_id and c.user_id = ${context.userId}
      returning c.id
    `;
    if (!updated[0]) throw new Error("Plan was already matured, not ready, or the family profile no longer exists.");
    await sql`insert into unit_transactions (id, user_id, child_id, kind, amount, note, idempotency_key) values (${uid("txn")}, ${context.userId}, ${plan.child_id}, 'credit', ${plan.committed_units + plan.bonus_units}, 'Future Units plan matured', ${`future-mature-${data.planId}`}) on conflict (user_id,idempotency_key) do nothing`;
    await audit(context.userId, "future_units.plan_matured", "future_unit_plan", data.planId);
    return { ok: true, totalUnits: plan.committed_units + plan.bonus_units };
  });

export const saveStudioProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { childId?: number | null; title: string; category: string; ageBand: string; payload: Record<string, unknown> }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const payload = JSON.stringify(data.payload).slice(0, 150_000);
    const title = data.title.trim().slice(0, 100) || "Untitled project";
    const category = data.category.slice(0, 30);
    const ageBand = data.ageBand.slice(0, 20);
    if (!["drawing", "coloring", "craft", "story", "shirt", "music", "game", "puzzle"].includes(category)) throw new Error("Invalid studio category");
    if (!["sprout", "explorer", "pathfinder", "creator"].includes(ageBand)) throw new Error("Invalid age band");
    if (data.childId) {
      const child = await sql<{ id: number }>`select id from children where id = ${data.childId} and user_id = ${context.userId} limit 1`;
      if (!child[0]) throw new Error("Child profile not found");
    }
    const projectId = uid("studio");
    const rows = await sql<{ id: string }>`
      insert into studio_projects (id, user_id, child_id, title, category, age_band, payload)
      values (${projectId}, ${context.userId}, ${data.childId ?? null}, ${title}, ${category}, ${ageBand}, ${payload}::jsonb)
      returning id
    `;
    return { id: rows[0]?.id };
  });

export const recordLearningActivity = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { childId?: number | null; activityKey: string; ageBand: string; level: string; score: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    if (data.childId) {
      const child = await sql<{ id: number }>`select id from children where id = ${data.childId} and user_id = ${context.userId} limit 1`;
      if (!child[0]) throw new Error("Child profile not found");
    }
    const score = Math.max(0, Math.min(100, Math.floor(data.score)));
    await sql`
      insert into learning_progress (user_id, child_id, activity_key, age_band, level, score, completions, last_completed_at)
      values (${context.userId}, ${data.childId ?? null}, ${data.activityKey.slice(0, 80)}, ${data.ageBand.slice(0, 20)}, ${data.level.slice(0, 40)}, ${score}, 1, now())
      on conflict (user_id, child_id, activity_key)
      do update set age_band = excluded.age_band, level = excluded.level, score = greatest(learning_progress.score, excluded.score), completions = learning_progress.completions + 1, last_completed_at = now()
    `;
    return { ok: true };
  });

async function getOrCreateCart(userId: string) {
  const sql = await getSql();
  const existing = await sql<{ id: number }>`select id from carts where user_id = ${userId} and status = 'open' limit 1`;
  if (existing[0]) return existing[0].id;
  const created = await sql<{ id: number }>`insert into carts (user_id) values (${userId}) returning id`;
  return created[0].id;
}

export const addToCart = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { productId: string; quantity: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const quantity = Math.max(1, Math.min(25, Math.floor(data.quantity)));
    const product = await sql<{ id: string; inventory: number }>`select id, inventory from store_products where id = ${data.productId} and active = true limit 1`;
    if (!product[0]) throw new Error("Product unavailable");
    if (product[0].inventory < quantity) throw new Error("Not enough inventory");
    const cartId = await getOrCreateCart(context.userId);
    await sql`
      insert into cart_items (cart_id, product_id, quantity)
      values (${cartId}, ${data.productId}, ${quantity})
      on conflict (cart_id, product_id) do update set quantity = least(cart_items.quantity + excluded.quantity, 25)
    `;
    await sql`update carts set updated_at = now() where id = ${cartId}`;
    return { ok: true };
  });

export const setCartQuantity = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { productId: string; quantity: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const quantity = Math.floor(data.quantity);
    if (quantity <= 0) {
      await sql`delete from cart_items ci using carts c where ci.cart_id = c.id and c.user_id = ${context.userId} and c.status = 'open' and ci.product_id = ${data.productId}`;
    } else {
      await sql`update cart_items ci set quantity = least(${quantity}, 25) from carts c where ci.cart_id = c.id and c.user_id = ${context.userId} and c.status = 'open' and ci.product_id = ${data.productId}`;
    }
    return { ok: true };
  });

export const createCheckout = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { email: string; shippingName: string; shippingAddress: { line1: string; city: string; state: string; postalCode: string } }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const items = await sql<{ product_id: string; quantity: number; name: string; retail_price_cents: number; supplier_name: string; supplier_sku: string }>`
      select ci.product_id, ci.quantity, p.name, p.retail_price_cents, p.supplier_name, p.supplier_sku
      from cart_items ci join carts c on c.id = ci.cart_id join store_products p on p.id = ci.product_id
      where c.user_id = ${context.userId} and c.status = 'open' and p.active = true
    `;
    if (!items.length) throw new Error("Your basket is empty.");
    const subtotal = items.reduce((sum, item) => sum + item.retail_price_cents * item.quantity, 0);
    const shipping = subtotal >= 7500 ? 0 : 799;
    const total = subtotal + shipping;
    const addressJson = JSON.stringify({
      line1: data.shippingAddress.line1.slice(0, 120),
      city: data.shippingAddress.city.slice(0, 80),
      state: data.shippingAddress.state.slice(0, 40),
      postalCode: data.shippingAddress.postalCode.slice(0, 20),
    });
    const stripeKey = process.env.STRIPE_SECRET_KEY?.trim();
    if (!stripeKey && !isWorkspacePreview()) throw new Error("Payments are not configured for production yet.");
    const order = await sql<{ id: number }>`
      insert into orders (user_id, status, payment_provider, subtotal_cents, shipping_cents, total_cents, shipping_name, shipping_email, shipping_address)
      values (${context.userId}, 'pending_payment', 'stripe', ${subtotal}, ${shipping}, ${total}, ${data.shippingName.trim().slice(0, 100)}, ${data.email.trim().slice(0, 160)}, ${addressJson}::jsonb)
      returning id
    `;
    const orderId = order[0].id;
    for (const item of items) {
      await sql`
        insert into order_items (order_id, product_id, product_name, supplier_name, supplier_sku, quantity, unit_price_cents)
        values (${orderId}, ${item.product_id}, ${item.name}, ${item.supplier_name}, ${item.supplier_sku}, ${item.quantity}, ${item.retail_price_cents})
      `;
    }
    if (!stripeKey) {
      await sql`update orders set status = 'preview_payment' where id = ${orderId}`;
      await sql`update carts set status = 'checked_out', updated_at = now() where user_id = ${context.userId} and status = 'open'`;
      return { mode: "preview" as const, orderId, checkoutUrl: null };
    }
    const baseUrl = process.env.BETTER_AUTH_URL?.trim() || "http://localhost:8080";
    const form = new URLSearchParams();
    form.set("mode", "payment");
    form.set("success_url", `${baseUrl}/checkout/success?order=${orderId}`);
    form.set("cancel_url", `${baseUrl}/?checkout=cancelled`);
    form.set("customer_email", data.email.trim());
    form.set("shipping_address_collection[allowed_countries][0]", "US");
    if (shipping > 0) {
      form.set("shipping_options[0][shipping_rate_data][display_name]", "Standard shipping");
      form.set("shipping_options[0][shipping_rate_data][type]", "fixed_amount");
      form.set("shipping_options[0][shipping_rate_data][fixed_amount][amount]", String(shipping));
      form.set("shipping_options[0][shipping_rate_data][fixed_amount][currency]", "usd");
    }
    items.forEach((item, index) => {
      form.set(`line_items[${index}][quantity]`, String(item.quantity));
      form.set(`line_items[${index}][price_data][currency]`, "usd");
      form.set(`line_items[${index}][price_data][unit_amount]`, String(item.retail_price_cents));
      form.set(`line_items[${index}][price_data][product_data][name]`, item.name);
    });
    form.set("metadata[order_id]", String(orderId));
    const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: { Authorization: `Bearer ${stripeKey}`, "Content-Type": "application/x-www-form-urlencoded" },
      body: form,
    });
    if (!response.ok) throw new Error(`Payment setup failed: ${(await response.text()).slice(0, 220)}`);
    const session = (await response.json()) as { id: string; url: string };
    await sql`update orders set payment_reference = ${session.id} where id = ${orderId}`;
    return { mode: "stripe" as const, orderId, checkoutUrl: session.url };
  });

export const createStudioCheckout = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: Record<string, never>) => input)
  .handler(async ({ context }) => {
    const sql = await getSql();
    const configured = await sql<{ studio_plus: boolean }>`select studio_plus from profiles where user_id = ${context.userId}`;
    if (configured[0]?.studio_plus) return { mode: "active" as const, checkoutUrl: null };
    const price = Math.max(99, Number(process.env.STUDIO_PLUS_PRICE_CENTS ?? 499));
    const stripeKey = process.env.STRIPE_SECRET_KEY?.trim();
    if (!stripeKey && !isWorkspacePreview()) throw new Error("Studio payments are not configured for production yet.");
    if (!stripeKey) {
      await sql`update profiles set studio_plus = true, updated_at = now() where user_id = ${context.userId}`;
      return { mode: "preview" as const, checkoutUrl: null };
    }
    const baseUrl = process.env.BETTER_AUTH_URL?.trim() || "http://localhost:8080";
    const form = new URLSearchParams();
    form.set("mode", "payment");
    form.set("success_url", `${baseUrl}/?studio=activated`);
    form.set("cancel_url", `${baseUrl}/?studio=cancelled`);
    form.set("line_items[0][quantity]", "1");
    form.set("line_items[0][price_data][currency]", "usd");
    form.set("line_items[0][price_data][unit_amount]", String(price));
    form.set("line_items[0][price_data][product_data][name]", "PillarPath Creative Studio Plus");
    form.set("metadata[studio_plus]", "1");
    form.set("metadata[user_id]", context.userId);
    const response = await fetch("https://api.stripe.com/v1/checkout/sessions", { method: "POST", headers: { Authorization: `Bearer ${stripeKey}`, "Content-Type": "application/x-www-form-urlencoded" }, body: form });
    if (!response.ok) throw new Error(`Studio checkout setup failed: ${(await response.text()).slice(0, 220)}`);
    const session = (await response.json()) as { url: string };
    return { mode: "stripe" as const, checkoutUrl: session.url };
  });

export const getCorporateOperations = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const role = await requireCorporateRole(context.userId, ["executive", "finance", "support", "safety", "school_admin", "commerce_admin", "system_admin"]);
    const sql = await getSql();
    const [partners, campaigns, fulfillments] = await Promise.all([
      sql`select id, name, status, supplier_name from store_products order by name limit 100`,
      sql`select id, name, channel, status, budget_cents, clicks, conversions from marketing_campaigns order by id desc limit 100`,
      sql`select id, order_id, supplier_name, status, tracking_number from fulfillments order by id desc limit 100`,
    ]);
    return { role, partners, campaigns, fulfillments };
  });

export const createCorporateCampaign = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { name: string; channel: string; budgetCents: number }) => input)
  .handler(async ({ context, data }) => {
    await requireCorporateRole(context.userId, ["executive", "commerce_admin"]);
    const sql = await getSql();
    await sql`insert into marketing_campaigns (user_id, name, channel, budget_cents) values (${context.userId}, ${data.name.trim().slice(0, 100)}, ${data.channel.slice(0, 40)}, ${Math.max(0, Math.min(10_000_000, Math.floor(data.budgetCents)))})`;
    await audit(context.userId, "corporate.campaign_created", "marketing_campaign");
    return { ok: true };
  });

// Legacy corporate-only actions kept for the internal operations workspace.
export const createCampaign = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { name: string; channel: string; budgetCents: number }) => input)
  .handler(async ({ context, data }) => {
    await requireCorporateRole(context.userId, ["executive", "commerce_admin"]);
    const sql = await getSql();
    await sql`insert into marketing_campaigns (user_id, name, channel, budget_cents) values (${context.userId}, ${data.name.trim().slice(0, 100)}, ${data.channel.slice(0, 40)}, ${Math.max(0, Math.min(10_000_000, Math.floor(data.budgetCents)))})`;
    await audit(context.userId, "corporate.campaign_created", "marketing_campaign");
    return { ok: true };
  });

export const createPromoCode = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { code: string; discountPercent: number }) => input)
  .handler(async ({ context, data }) => {
    await requireCorporateRole(context.userId, ["executive", "commerce_admin"]);
    const sql = await getSql();
    const code = data.code.trim().toUpperCase().slice(0, 40);
    const discount = Math.min(90, Math.max(1, Math.floor(data.discountPercent)));
    if (!code) throw new Error("Promo code is required");
    await sql`insert into promo_codes (user_id, code, discount_percent) values (${context.userId}, ${code}, ${discount}) on conflict (user_id, code) do update set discount_percent = excluded.discount_percent, active = true`;
    await audit(context.userId, "corporate.promo_created", "promo_code", code);
    return { ok: true };
  });

export const createChildAccessGrant = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { childId: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const child = (await sql<{ id: number }>`select id from children where id=${data.childId} and user_id=${context.userId} limit 1`)[0];
    if (!child) throw new Error("Child profile not found");
    const token = randomBytes(32).toString("base64url");
    const grantId = uid("child-session");
    await sql`update child_access_grants set revoked_at=now() where user_id=${context.userId} and child_id=${child.id} and revoked_at is null`;
    await sql`insert into child_access_grants (id, user_id, child_id, token_hash, expires_at) values (${grantId}, ${context.userId}, ${child.id}, ${hashChildGrant(token)}, now()+interval '8 hours')`;
    return { token, childId: child.id, expiresInSeconds: 8 * 60 * 60 };
  });

export const revokeChildAccessGrant = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { token: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update child_access_grants set revoked_at=now() where user_id=${context.userId} and token_hash=${hashChildGrant(data.token)}`;
    return { ok: true };
  });

export const getFamilyLedger = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const [profile, children] = await Promise.all([
      sql<{ parent_consent_verified: boolean }>`select parent_consent_verified from profiles where user_id = ${context.userId} limit 1`,
      sql<{ id: number; name: string; age: number | null; units: number; vault_units: number; frozen: boolean; vault_goal: string; match_rate: number; vault_maturity_at: string | null }>`select id, name, age, units, vault_units, frozen, vault_goal, match_rate, vault_maturity_at from children where user_id = ${context.userId} order by id limit 1`,
    ]);
    const child = children[0];
    if (!child) return { consent: Boolean(profile[0]?.parent_consent_verified), child: null, history: [], pendingPurchases: [], pendingChores: [], completedChoreIds: [] };
    const [history, pendingPurchases, pendingChores, completedChores] = await Promise.all([
      sql<{ id: string; kind: string; amount: number; note: string; created_at: string }>`select id, kind, amount, note, created_at from unit_transactions where user_id = ${context.userId} and child_id = ${child.id} order by created_at desc limit 80`,
      sql<{ id: string; product_id: string; requested_units: number; status: string }>`select id, product_id, requested_units, status from child_purchase_requests where user_id = ${context.userId} and child_id = ${child.id} and status = 'pending' order by created_at desc`,
      sql<{ id: string; chore_id: string; amount: number; status: string }>`select id, chore_id, amount, status from child_chore_requests where user_id = ${context.userId} and child_id = ${child.id} and status = 'pending' order by created_at desc`,
      sql<{ chore_id: string }>`select distinct chore_id from child_chore_requests where user_id = ${context.userId} and child_id = ${child.id} and status = 'approved' order by chore_id`,
    ]);
    return { consent: Boolean(profile[0]?.parent_consent_verified), child, history, pendingPurchases, pendingChores, completedChoreIds: completedChores.map((c) => c.chore_id) };
  });

export const verifyParentConsent = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: Record<string, never>) => input)
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`update profiles set parent_consent_verified = true, updated_at = now() where user_id = ${context.userId}`;
    await audit(context.userId, "parent.consent_verified", "profile");
    return { ok: true };
  });

export const toggleChildFreeze = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { childId?: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: number; frozen: boolean }>`select id, frozen from children where user_id = ${context.userId} and (${data.childId ?? null}::bigint is null or id = ${data.childId ?? null}) order by id limit 1`;
    const child = rows[0];
    if (!child) throw new Error("Create a child profile first");
    const next = !child.frozen;
    await sql`update children set frozen = ${next} where id = ${child.id} and user_id = ${context.userId}`;
    await audit(context.userId, next ? "child.frozen" : "child.unfrozen", "child", String(child.id));
    return { frozen: next };
  });

export const loadChildUnits = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { amount: number; childId?: number; idempotencyKey: string; childToken: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const amount = Math.floor(Number(data.amount));
    if (!Number.isFinite(amount) || amount < 1 || amount > 10000) throw new Error("Units must be between 1 and 10,000.");
    const childRows = await sql<{ id: number }>`select id from children where user_id = ${context.userId} and (${data.childId ?? null}::bigint is null or id = ${data.childId ?? null}) order by id limit 1`;
    const child = childRows[0];
    if (!child) throw new Error("Create a child profile first");
    const existing = await sql<{ id: string }>`select id from unit_transactions where user_id = ${context.userId} and idempotency_key = ${data.idempotencyKey.slice(0, 120)} limit 1`;
    if (existing[0]) return { ok: true, duplicate: true };
    await sql`update children set units = units + ${amount} where id = ${child.id} and user_id = ${context.userId}`;
    await sql`insert into unit_transactions (id, user_id, child_id, kind, amount, note, idempotency_key) values (${uid("txn")}, ${context.userId}, ${child.id}, 'credit', ${amount}, 'Parent loaded Units', ${data.idempotencyKey.slice(0, 120)})`;
    await audit(context.userId, "units.loaded", "child", String(child.id), { amount });
    return { ok: true, duplicate: false };
  });

export const awardChildUnits = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { amount: number; reason: string; childId?: number; idempotencyKey: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const amount = Math.floor(Number(data.amount));
    if (!Number.isFinite(amount) || amount < 1 || amount > 1000) throw new Error("Award must be between 1 and 1,000 Units.");
    const childRows = await sql<{ id: number }>`select id from children where user_id = ${context.userId} and (${data.childId ?? null}::bigint is null or id = ${data.childId ?? null}) order by id limit 1`;
    const child = childRows[0];
    if (!child) throw new Error("Create a child profile first");
    const key = data.idempotencyKey.slice(0, 120);
    const existing = await sql<{ id: string }>`select id from unit_transactions where user_id = ${context.userId} and idempotency_key = ${key} limit 1`;
    if (existing[0]) return { ok: true, duplicate: true };
    await sql`update children set units = units + ${amount} where id = ${child.id} and user_id = ${context.userId}`;
    await sql`insert into unit_transactions (id, user_id, child_id, kind, amount, note, idempotency_key) values (${uid("txn")}, ${context.userId}, ${child.id}, 'credit', ${amount}, ${`Awarded · ${data.reason.trim().slice(0, 100)}`}, ${key})`;
    return { ok: true, duplicate: false };
  });

export const requestChildPurchase = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { productId: string; childId?: number; childToken: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const grantedChildId = await requireChildGrant(context.userId, data.childToken, data.childId);
    const child = (await sql<{ id: number; units: number; frozen: boolean }>`select id, units, frozen from children where user_id = ${context.userId} and (id = ${grantedChildId}) order by id limit 1`)[0];
    if (!child) throw new Error("Create a child profile first");
    if (child.frozen) throw new Error("Child access is frozen");
    const product = (await sql<{ id: string; name: string; unit_price: number }>`select id, name, unit_price from store_products where id = ${data.productId} and active = true limit 1`)[0];
    if (!product) throw new Error("Item not found");
    const reserved = await sql<{ total: number }>`select coalesce(sum(requested_units),0)::int as total from child_purchase_requests where user_id = ${context.userId} and child_id = ${child.id} and status = 'pending'`;
    if (product.unit_price > child.units - (reserved[0]?.total ?? 0)) throw new Error("Not enough available Units");
    const duplicate = await sql<{ id: string }>`select id from child_purchase_requests where user_id = ${context.userId} and child_id = ${child.id} and product_id = ${product.id} and status = 'pending' limit 1`;
    if (duplicate[0]) return { id: duplicate[0].id, duplicate: true };
    const requestId = uid("buy");
    const rows = await sql<{ id: string }>`insert into child_purchase_requests (id, user_id, child_id, product_id, requested_units) values (${requestId}, ${context.userId}, ${child.id}, ${product.id}, ${product.unit_price}) returning id`;
    return { id: rows[0]?.id, duplicate: false };
  });

export const resolveChildPurchase = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { requestId: string; approve: boolean; idempotencyKey: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const request = (await sql<{ id: string; child_id: number; product_id: string; requested_units: number; status: string }>`select id, child_id, product_id, requested_units, status from child_purchase_requests where id = ${data.requestId} and user_id = ${context.userId} limit 1`)[0];
    if (!request) throw new Error("Purchase request not found");
    if (request.status !== "pending") return { ok: true, duplicate: true };
    if (!data.approve) {
      await sql`update child_purchase_requests set status='denied', resolved_at=now() where id=${request.id} and user_id=${context.userId} and status='pending'`;
      return { ok: true, duplicate: false };
    }
    const updated = await sql<{ id: number }>`update children set units = units - ${request.requested_units} where id = ${request.child_id} and user_id = ${context.userId} and units >= ${request.requested_units} returning id`;
    if (!updated[0]) throw new Error("Insufficient Units");
    await sql`update child_purchase_requests set status='approved', resolved_at=now() where id=${request.id} and user_id=${context.userId} and status='pending'`;
    await sql`insert into unit_transactions (id, user_id, child_id, kind, amount, note, idempotency_key) values (${uid("txn")}, ${context.userId}, ${request.child_id}, 'debit', ${request.requested_units}, ${`Marketplace purchase · ${request.product_id}`}, ${data.idempotencyKey.slice(0,120)}) on conflict (user_id,idempotency_key) do nothing`;
    return { ok: true, duplicate: false };
  });

export const requestChildChore = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { choreId: string; amount: number; childId?: number; childToken: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const grantedChildId = await requireChildGrant(context.userId, data.childToken, data.childId);
    const amount = Math.floor(Number(data.amount));
    if (amount < 1 || amount > 100) throw new Error("Invalid reward amount");
    const child = (await sql<{ id: number; frozen: boolean }>`select id, frozen from children where user_id=${context.userId} and (id=${grantedChildId}) order by id limit 1`)[0];
    if (!child) throw new Error("Create a child profile first");
    if (child.frozen) throw new Error("Child access is frozen");
    const existing = await sql<{ id: string }>`select id from child_chore_requests where user_id=${context.userId} and child_id=${child.id} and chore_id=${data.choreId.slice(0,60)} and status='pending' limit 1`;
    if (existing[0]) return { id: existing[0].id, duplicate: true };
    const requestId = uid("chore");
    const rows = await sql<{ id: string }>`insert into child_chore_requests (id, user_id, child_id, chore_id, amount) values (${requestId}, ${context.userId}, ${child.id}, ${data.choreId.slice(0,60)}, ${amount}) returning id`;
    return { id: rows[0]?.id, duplicate: false };
  });

export const resolveChildChore = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { requestId: string; approve: boolean; idempotencyKey: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const request = (await sql<{ id: string; child_id: number; amount: number; status: string }>`select id, child_id, amount, status from child_chore_requests where id=${data.requestId} and user_id=${context.userId} limit 1`)[0];
    if (!request) throw new Error("Chore request not found");
    if (request.status !== "pending") return { ok: true, duplicate: true };
    await sql`update child_chore_requests set status=${data.approve ? "approved" : "denied"}, resolved_at=now() where id=${request.id} and user_id=${context.userId} and status='pending'`;
    if (data.approve) {
      const key = data.idempotencyKey.slice(0,120);
      const existing = await sql<{ id: string }>`select id from unit_transactions where user_id=${context.userId} and idempotency_key=${key} limit 1`;
      if (!existing[0]) {
        await sql`update children set units=units+${request.amount} where id=${request.child_id} and user_id=${context.userId}`;
        await sql`insert into unit_transactions (id, user_id, child_id, kind, amount, note, idempotency_key) values (${uid("txn")}, ${context.userId}, ${request.child_id}, 'credit', ${request.amount}, 'Chore approved', ${key})`;
      }
    }
    return { ok: true, duplicate: false };
  });

export const lockChildUnits = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { amount: number; childId?: number; idempotencyKey: string; childToken: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const grantedChildId = await requireChildGrant(context.userId, data.childToken, data.childId);
    const amount = Math.floor(Number(data.amount));
    if (amount < 1 || amount > 10000) throw new Error("Invalid Unit amount");
    const child = (await sql<{ id: number; units: number; frozen: boolean; match_rate: number }>`select id, units, frozen, match_rate from children where user_id=${context.userId} and (id=${grantedChildId}) order by id limit 1`)[0];
    if (!child) throw new Error("Create a child profile first");
    if (child.frozen) throw new Error("Child access is frozen");
    const updated = await sql<{ id: number }>`update children set units=units-${amount}, vault_units=vault_units+${amount}+floor(${amount}*match_rate), vault_maturity_at=coalesce(vault_maturity_at, now()+interval '28 days') where id=${child.id} and user_id=${context.userId} and units>=${amount} returning id`;
    if (!updated[0]) throw new Error("Not enough Units");
    const key = data.idempotencyKey.slice(0,120);
    await sql`insert into unit_transactions (id, user_id, child_id, kind, amount, note, idempotency_key) values (${uid("txn")}, ${context.userId}, ${child.id}, 'transfer', ${amount}, 'Locked in Vault', ${key}) on conflict (user_id,idempotency_key) do nothing`;
    return { ok: true };
  });

export const setChildMatchRate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { rate: number; childId?: number }) => input)
  .handler(async ({ context, data }) => {
    const rate = Math.max(0, Math.min(1, Number(data.rate)));
    const sql = await getSql();
    await sql`update children set match_rate=${rate} where user_id=${context.userId} and (${data.childId ?? null}::bigint is null or id=${data.childId ?? null})`;
    return { ok: true, rate };
  });
