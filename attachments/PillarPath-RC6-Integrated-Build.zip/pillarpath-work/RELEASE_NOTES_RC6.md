# PillarPath RC6 — Integrated Feature Build

RC6 uses the verified RC5 production candidate as its base and integrates the features represented by the latest PillarPath demo screens.

## Included customer/family features
- Parent overview dashboard
- Child experience with supervised Units ledger
- Expanded Creative Campus / Studio
- Family profiles and Units ledger
- Parent-only Future Units closed-loop reserve plans
- Parent Unit Market activity analytics clearly labeled as non-financial simulation
- Curated PillarPath Store
- Basket and checkout flow
- Order history

## Included internal corporate features
- Server-authorized Corporate Operations workspace
- Marketing campaigns and promotion tools
- Partner connector catalog
- Supplier/dropship fulfillment center
- Corporate role boundary enforced by the existing server authorization layer
- Supplier/affiliate credentials remain server-side and are not exposed to parent or child views

## Mobile build support
- Added root-level `codemagic.yaml` for a cloud Android debug APK build.
- The workflow installs the web dependencies, installs Capacitor Android tooling, builds the web app, generates/syncs Android, and produces `app-debug.apk`.
- No production signing keys or payment secrets are included.

## Validation
- Source-level TypeScript/JSX parse checks were run on the modified app and commerce components.
- Full dependency-backed typecheck/build was not completed in this environment because dependency installation timed out.
- Do not treat RC6 as a store-release artifact until the cloud build, device QA, production configuration, and security/legal release checklist are completed.
